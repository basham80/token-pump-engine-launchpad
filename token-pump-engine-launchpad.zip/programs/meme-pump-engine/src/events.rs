use anchor_lang::prelude::*;

#[event]
pub struct TokenLaunched {
    pub index: u64,
    pub mint: Pubkey,
    pub creator: Pubkey,
    pub name: String,
    pub symbol: String,
    pub uri: String,
    pub virtual_sol_reserves: u64,
    pub virtual_token_reserves: u64,
    pub real_token_reserves: u64,
    pub token_total_supply: u64,
    pub timestamp: i64,
}

#[event]
pub struct TradeEvent {
    pub mint: Pubkey,
    pub trader: Pubkey,
    pub is_buy: bool,
    /// SOL that entered (buy) or left (sell, before fee) the curve
    pub sol_amount: u64,
    pub token_amount: u64,
    pub fee: u64,
    pub virtual_sol_reserves: u64,
    pub virtual_token_reserves: u64,
    pub real_sol_reserves: u64,
    pub real_token_reserves: u64,
    pub timestamp: i64,
}

#[event]
pub struct CurveCompleted {
    pub mint: Pubkey,
    pub real_sol_reserves: u64,
    pub timestamp: i64,
}

#[event]
pub struct MigrationWithdrawn {
    pub mint: Pubkey,
    pub to: Pubkey,
    pub sol_amount: u64,
    pub token_amount: u64,
    pub timestamp: i64,
}

#[event]
pub struct MigrationPoolRecorded {
    pub mint: Pubkey,
    pub pool: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct GlobalUpdated {
    pub authority: Pubkey,
    pub fee_recipient: Pubkey,
    pub migration_authority: Pubkey,
    pub fee_bps: u16,
    pub paused: bool,
}
