pub const GLOBAL_SEED: &[u8] = b"global";
pub const CURVE_SEED: &[u8] = b"curve";
pub const LAUNCH_SEED: &[u8] = b"launch";

pub const BPS_DENOMINATOR: u128 = 10_000;
/// Hard cap on the platform fee: 5% per trade.
pub const MAX_FEE_BPS: u16 = 500;
pub const TOKEN_DECIMALS: u8 = 6;

pub const MAX_NAME_LEN: usize = 32;
pub const MAX_SYMBOL_LEN: usize = 10;
pub const MAX_URI_LEN: usize = 200;
