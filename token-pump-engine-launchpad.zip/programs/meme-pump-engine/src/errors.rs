use anchor_lang::prelude::*;

#[error_code]
pub enum PumpError {
    #[msg("This curve has sold out and is closed to trading")]
    CurveCompleted,
    #[msg("This curve has not sold out yet")]
    CurveNotCompleted,
    #[msg("Funds for this curve were already withdrawn for migration")]
    AlreadyMigrated,
    #[msg("Funds for this curve have not been withdrawn for migration yet")]
    NotMigrated,
    #[msg("Math overflow or division by zero")]
    MathOverflow,
    #[msg("Price moved beyond your slippage limit")]
    SlippageExceeded,
    #[msg("Amount must be greater than zero")]
    ZeroAmount,
    #[msg("Platform fee exceeds the 5% cap")]
    FeeTooHigh,
    #[msg("Signer is not allowed to do this")]
    Unauthorized,
    #[msg("Curve does not hold enough reserves for this trade")]
    InsufficientReserves,
    #[msg("Launches and buys are paused by the platform")]
    Paused,
    #[msg("Invalid bonding-curve parameters")]
    InvalidCurveParams,
    #[msg("Token name, symbol or metadata URI is empty or too long")]
    InvalidMetadata,
}
