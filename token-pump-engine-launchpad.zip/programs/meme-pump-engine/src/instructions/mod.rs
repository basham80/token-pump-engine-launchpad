pub mod admin;
pub mod launch;
pub mod migration;
pub mod trade;

pub use admin::*;
pub use launch::*;
pub use migration::*;
pub use trade::*;

use anchor_lang::prelude::*;
use crate::errors::PumpError;

/// Move lamports out of an account this program owns. Only call after all CPIs in the instruction.
pub(crate) fn move_lamports(from: &AccountInfo, to: &AccountInfo, amount: u64) -> Result<()> {
    if amount == 0 {
        return Ok(());
    }
    let from_balance = from.lamports();
    **from.try_borrow_mut_lamports()? = from_balance.checked_sub(amount).ok_or(PumpError::InsufficientReserves)?;
    let to_balance = to.lamports();
    **to.try_borrow_mut_lamports()? = to_balance.checked_add(amount).ok_or(PumpError::MathOverflow)?;
    Ok(())
}
