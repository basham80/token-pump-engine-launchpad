use anchor_lang::prelude::*;
use anchor_lang::system_program::{self, Transfer as SolTransfer};
use anchor_spl::{
    associated_token::AssociatedToken,
    token::{self, Mint, Token, TokenAccount},
};
use crate::constants::*;
use crate::errors::PumpError;
use crate::events::{CurveCompleted, TradeEvent};
use crate::math::{quote_buy, quote_sell};
use crate::state::{CurveState, Global};
use super::move_lamports;

#[derive(Accounts)]
pub struct Buy<'info> {
    #[account(mut)]
    pub buyer: Signer<'info>,

    #[account(seeds = [GLOBAL_SEED], bump = global.bump, has_one = fee_recipient @ PumpError::Unauthorized)]
    pub global: Box<Account<'info, Global>>,

    /// CHECK: must equal global.fee_recipient (enforced by has_one)
    #[account(mut)]
    pub fee_recipient: UncheckedAccount<'info>,

    pub mint: Box<Account<'info, Mint>>,

    #[account(mut, seeds = [CURVE_SEED, mint.key().as_ref()], bump = curve_state.bump)]
    pub curve_state: Box<Account<'info, CurveState>>,

    #[account(mut, associated_token::mint = mint, associated_token::authority = curve_state)]
    pub token_vault: Box<Account<'info, TokenAccount>>,

    #[account(init_if_needed, payer = buyer, associated_token::mint = mint, associated_token::authority = buyer)]
    pub buyer_token_account: Box<Account<'info, TokenAccount>>,

    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Sell<'info> {
    #[account(mut)]
    pub seller: Signer<'info>,

    #[account(seeds = [GLOBAL_SEED], bump = global.bump, has_one = fee_recipient @ PumpError::Unauthorized)]
    pub global: Box<Account<'info, Global>>,

    /// CHECK: must equal global.fee_recipient (enforced by has_one)
    #[account(mut)]
    pub fee_recipient: UncheckedAccount<'info>,

    pub mint: Box<Account<'info, Mint>>,

    #[account(mut, seeds = [CURVE_SEED, mint.key().as_ref()], bump = curve_state.bump)]
    pub curve_state: Box<Account<'info, CurveState>>,

    #[account(mut, associated_token::mint = mint, associated_token::authority = curve_state)]
    pub token_vault: Box<Account<'info, TokenAccount>>,

    #[account(mut, associated_token::mint = mint, associated_token::authority = seller)]
    pub seller_token_account: Box<Account<'info, TokenAccount>>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

/// Buy with at most `max_sol_in` going into the curve; the platform fee is charged on top.
pub fn buy(ctx: Context<Buy>, max_sol_in: u64, min_tokens_out: u64) -> Result<()> {
    require!(!ctx.accounts.global.paused, PumpError::Paused);
    let (v_sol, v_tok, real_sol, real_tok, complete, bump) = {
        let c = &ctx.accounts.curve_state;
        (c.virtual_sol_reserves, c.virtual_token_reserves, c.real_sol_reserves, c.real_token_reserves, c.complete, c.bump)
    };
    require!(!complete, PumpError::CurveCompleted);

    let q = quote_buy(v_sol, v_tok, real_tok, ctx.accounts.global.fee_bps, max_sol_in)?;
    require!(q.tokens_out >= min_tokens_out, PumpError::SlippageExceeded);

    system_program::transfer(
        CpiContext::new(
            ctx.accounts.system_program.to_account_info(),
            SolTransfer {
                from: ctx.accounts.buyer.to_account_info(),
                to: ctx.accounts.curve_state.to_account_info(),
            },
        ),
        q.sol_in,
    )?;
    if q.fee > 0 {
        system_program::transfer(
            CpiContext::new(
                ctx.accounts.system_program.to_account_info(),
                SolTransfer {
                    from: ctx.accounts.buyer.to_account_info(),
                    to: ctx.accounts.fee_recipient.to_account_info(),
                },
            ),
            q.fee,
        )?;
    }

    let mint_key = ctx.accounts.mint.key();
    let bump_bytes = [bump];
    let signer_seeds: &[&[&[u8]]] = &[&[CURVE_SEED, mint_key.as_ref(), &bump_bytes]];
    token::transfer(
        CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            token::Transfer {
                from: ctx.accounts.token_vault.to_account_info(),
                to: ctx.accounts.buyer_token_account.to_account_info(),
                authority: ctx.accounts.curve_state.to_account_info(),
            },
            signer_seeds,
        ),
        q.tokens_out,
    )?;

    let now = Clock::get()?.unix_timestamp;
    let c = &mut ctx.accounts.curve_state;
    c.virtual_sol_reserves = q.new_virtual_sol;
    c.virtual_token_reserves = q.new_virtual_token;
    c.real_sol_reserves = real_sol.checked_add(q.sol_in).ok_or(PumpError::MathOverflow)?;
    c.real_token_reserves = real_tok.checked_sub(q.tokens_out).ok_or(PumpError::MathOverflow)?;
    c.volume_lamports = c.volume_lamports.checked_add(q.sol_in).ok_or(PumpError::MathOverflow)?;
    c.fees_lamports = c.fees_lamports.checked_add(q.fee).ok_or(PumpError::MathOverflow)?;
    c.trade_count = c.trade_count.checked_add(1).ok_or(PumpError::MathOverflow)?;
    if q.completes {
        c.complete = true;
    }

    emit!(TradeEvent {
        mint: mint_key,
        trader: ctx.accounts.buyer.key(),
        is_buy: true,
        sol_amount: q.sol_in,
        token_amount: q.tokens_out,
        fee: q.fee,
        virtual_sol_reserves: c.virtual_sol_reserves,
        virtual_token_reserves: c.virtual_token_reserves,
        real_sol_reserves: c.real_sol_reserves,
        real_token_reserves: c.real_token_reserves,
        timestamp: now,
    });
    if q.completes {
        emit!(CurveCompleted { mint: mint_key, real_sol_reserves: c.real_sol_reserves, timestamp: now });
    }
    Ok(())
}

/// Sell `token_amount` back to the curve. Not affected by the platform pause.
pub fn sell(ctx: Context<Sell>, token_amount: u64, min_sol_out: u64) -> Result<()> {
    let (v_sol, v_tok, real_sol, real_tok, complete) = {
        let c = &ctx.accounts.curve_state;
        (c.virtual_sol_reserves, c.virtual_token_reserves, c.real_sol_reserves, c.real_token_reserves, c.complete)
    };
    require!(!complete, PumpError::CurveCompleted);

    let q = quote_sell(v_sol, v_tok, real_sol, ctx.accounts.global.fee_bps, token_amount)?;
    require!(q.sol_out_net >= min_sol_out, PumpError::SlippageExceeded);

    token::transfer(
        CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            token::Transfer {
                from: ctx.accounts.seller_token_account.to_account_info(),
                to: ctx.accounts.token_vault.to_account_info(),
                authority: ctx.accounts.seller.to_account_info(),
            },
        ),
        token_amount,
    )?;

    // No CPIs after this point: SOL leaves the curve account directly.
    let curve_info = ctx.accounts.curve_state.to_account_info();
    move_lamports(&curve_info, &ctx.accounts.seller.to_account_info(), q.sol_out_net)?;
    move_lamports(&curve_info, &ctx.accounts.fee_recipient.to_account_info(), q.fee)?;

    let now = Clock::get()?.unix_timestamp;
    let mint_key = ctx.accounts.mint.key();
    let c = &mut ctx.accounts.curve_state;
    c.virtual_sol_reserves = q.new_virtual_sol;
    c.virtual_token_reserves = q.new_virtual_token;
    c.real_sol_reserves = real_sol.checked_sub(q.sol_out_gross).ok_or(PumpError::MathOverflow)?;
    c.real_token_reserves = real_tok.checked_add(token_amount).ok_or(PumpError::MathOverflow)?;
    c.volume_lamports = c.volume_lamports.checked_add(q.sol_out_gross).ok_or(PumpError::MathOverflow)?;
    c.fees_lamports = c.fees_lamports.checked_add(q.fee).ok_or(PumpError::MathOverflow)?;
    c.trade_count = c.trade_count.checked_add(1).ok_or(PumpError::MathOverflow)?;

    emit!(TradeEvent {
        mint: mint_key,
        trader: ctx.accounts.seller.key(),
        is_buy: false,
        sol_amount: q.sol_out_gross,
        token_amount,
        fee: q.fee,
        virtual_sol_reserves: c.virtual_sol_reserves,
        virtual_token_reserves: c.virtual_token_reserves,
        real_sol_reserves: c.real_sol_reserves,
        real_token_reserves: c.real_token_reserves,
        timestamp: now,
    });
    Ok(())
}
