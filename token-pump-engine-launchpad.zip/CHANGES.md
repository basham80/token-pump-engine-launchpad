# Launchpad: live on-chain (latest)

The **Launchpad** screen (now the app's home screen) runs on your own Anchor program. Creators launch
fixed-supply tokens on a bonding curve, people buy and sell with their own wallets, and every trade pays your
platform fee on-chain. Deployment steps are in `DEPLOY.md`.

## Program: `programs/meme-pump-engine` (rebuilt, v0.2)

| Problem in the previous version | Now |
|---|---|
| When a curve sold out, its SOL could never leave: the Raydium migration took liquidity from the caller's wallet instead | `withdraw_for_migration` moves the SOL and reserved tokens to the migration wallet, and `record_migration_pool` stores the DEX pool on-chain |
| Anyone could call `initialize_global` first and make themselves the fee recipient | Only the program's upgrade authority can initialize |
| Tokens had no metadata, so wallets showed "Unknown token" | Metaplex metadata (name, symbol, URI), made immutable |
| The curve kept mint authority | Mint authority is revoked after minting, and freeze authority is never set |
| One large buy could take the tokens reserved for the DEX pool | Buys are capped at the sale supply, and only the SOL actually needed is charged |
| Creators could pick any curve numbers | The platform sets the curve parameters |
| Rounding favoured traders | Rounding favours the curve, so its SOL can never be overdrawn |
| No way to change the fee or pause | `update_global` (fee capped at 5%). Pause stops launches and buys, but sells stay open |
| No on-chain totals | Per-token fee, volume and trade counters, plus an on-chain launch registry |

Tests: `cargo test -p meme-pump-engine --features test-mode` runs 7 math unit tests and 4 integration tests on a
local Solana runtime.

## App

| File | Change |
|---|---|
| `src/components/launchpad/LaunchpadView.tsx` | **New.** Tokens (live list plus buy/sell), Launch a token, and Platform (settings, fee earnings, graduation queue) |
| `src/lib/launchpad/client.ts` | **New.** Instructions, account decoding and curve math, checked byte-for-byte against the program |
| `src/lib/launchpad/wallet.ts` | **New.** Phantom signing, then relay through the server |
| `src/server/launchpadService.ts` | **New.** Reads chain state, relays signed transactions (launchpad program only), optional IPFS upload |
| `server.ts` | `/api/launchpad/*` routes; 4 MB body limit for metadata uploads |
| `src/App.tsx`, `src/components/idx/IdxSidebar.tsx` | Launchpad added to the sidebar and set as the home screen; the old balances panel is hidden on it |
| `scripts/launchpad-admin.ts` | **New.** One-time initialize, and hands the admin role to your Phantom wallet |
| `scripts/launchpad-client.test.ts` | **New.** Checks the client against vectors written by the Rust tests |
| `scripts/deploy.sh`, `Anchor.toml`, `Cargo.toml` (new workspace), `Cargo.lock` | Build, test and deploy setup |
| Removed | `tests/meme-pump-engine.ts` and both old IDL copies, which described the old program. `anchor build` writes a fresh IDL. |

Not changed: the older pages (Anchor Pump Engine, Create Token Pro, Volume Bot, Holders Maker, Reaction Booster
and the rest) are untouched and still simulated. The old Anchor Pump Engine page targets the previous program
interface, so use the Launchpad screen for real launches.

---

# Manage Liquidity: live on-chain data

The Manage Liquidity screen now reads only live data. Each tracked pool is checked on Solana mainnet (does the
account exist, and which program owns it?), its stats come from Raydium's API, and your position is your
wallet's real LP balance. If a source can't be reached, the screen says so and shows nothing for that pool. It
never falls back to stored numbers.

## Files

| File | Change |
|---|---|
| `src/server/livePoolService.ts` | **New.** On-chain check, Raydium stats, and wallet LP balance, with a 30s cache |
| `server.ts` | New route `GET /api/raydium/pools/live?ids=…&wallet=…`. Add/remove/burn/lock/harvest routes now return 501 instead of fake signatures |
| `src/components/idx/ManageLiquidityView.tsx` | Rewritten to use live data. Actions open Raydium so your wallet signs a real transaction |
| `src/server/aiOrchestratorService.ts` | Responses include `fallback: true` when no model answered, so the pool audit can hide the canned text |
| `src/types.ts` | Adds the `LivePool*` types |
| `src/App.tsx` | Passes `walletAddress` to Manage Liquidity |
| `.gitignore` | Ignores keypair files |

To apply this in AI Studio, replace those files with the versions in this zip and add `livePoolService.ts`.
`deploy-keypair.json` and `target/deploy/meme_pump_engine-keypair.json` aren't in this zip because they're private
keys. Keep your originals.

## What each pool shows

- **Live on-chain**: reserves, TVL, price, LP burned %, 24h volume and fees, plus your LP balance, share and value.
- **Watch-only**: the pool is live, but your wallet holds 0 of its LP tokens.
- **Not on-chain**: no account exists at that pool ID. This applies to pools made by *Create Liquidity Pool*,
  which still makes simulated pools with made-up IDs.
- **Not a pool**: the address exists but isn't owned by a Raydium pool program (for example, a wallet).

## Optional settings

- `SOLANA_MAINNET_RPC`: your own RPC URL (Helius, QuickNode). The default publicnode RPC blocks full token-account
  scans, so the panel then checks only your wallet's standard LP token account.
- `RAYDIUM_API_BASE`: defaults to `https://api-v3.raydium.io`.

## Not changed

Bot Dashboard, Volume Bot and Exchange still read the stored pool numbers. Create Liquidity Pool, Volume Bot,
Holders Maker and the other simulated tools are untouched.
