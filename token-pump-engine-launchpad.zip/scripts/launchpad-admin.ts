/**
 * Launchpad setup from the deployer keypair (the program's upgrade authority).
 *
 *   npx tsx scripts/launchpad-admin.ts status --cluster devnet
 *   npx tsx scripts/launchpad-admin.ts init --cluster devnet --keypair ~/.config/solana/id.json \
 *       --admin <PHANTOM_ADDRESS> --fee-wallet <ADDRESS> --migration-wallet <ADDRESS> [--fee-bps 100]
 *
 * `init` creates the Global settings account and, in the same transaction, hands the admin role
 * to --admin, so day-to-day settings are then managed from the app with Phantom.
 * Options: --rpc <url>  --program-id <id>
 */
import { readFileSync } from 'fs';
import os from 'os';
import { Connection, Keypair, PublicKey, Transaction } from '@solana/web3.js';
import * as L from '../src/lib/launchpad/client';

const [, , command = 'status', ...rest] = process.argv;
const args: Record<string, string> = {};
for (let i = 0; i < rest.length; i += 2) args[rest[i].replace(/^--/, '')] = rest[i + 1];

const cluster = args.cluster === 'mainnet-beta' ? 'mainnet-beta' : 'devnet';
const rpc = args.rpc || (cluster === 'mainnet-beta' ? 'https://api.mainnet-beta.solana.com' : 'https://api.devnet.solana.com');
const programId = args['program-id'] || L.DEFAULT_PROGRAM_ID;
const conn = new Connection(rpc, 'confirmed');
const P = L.launchpadPdas(programId);
const I = L.launchpadInstructions(programId);
const solscan = (kind: string, id: string) => `https://solscan.io/${kind}/${id}${cluster === 'devnet' ? '?cluster=devnet' : ''}`;

function key(name: string, fallback?: PublicKey): PublicKey {
  const v = args[name];
  if (!v && fallback) return fallback;
  if (!v) throw new Error(`--${name} is required`);
  return new PublicKey(v);
}

async function sendAndPoll(tx: Transaction, signer: Keypair) {
  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash('confirmed');
  tx.recentBlockhash = blockhash;
  tx.lastValidBlockHeight = lastValidBlockHeight;
  tx.feePayer = signer.publicKey;
  tx.sign(signer);
  const sig = await conn.sendRawTransaction(tx.serialize(), { preflightCommitment: 'confirmed' });
  for (let i = 0; i < 40; i++) {
    const st = (await conn.getSignatureStatuses([sig])).value[0];
    if (st?.err) throw new Error(`Transaction ${sig} failed: ${L.describeProgramError(JSON.stringify(st.err))}`);
    if (st?.confirmationStatus === 'confirmed' || st?.confirmationStatus === 'finalized') return sig;
    await new Promise((r) => setTimeout(r, 1500));
  }
  throw new Error(`Transaction ${sig} not confirmed after 60s; check ${solscan('tx', sig)}`);
}

async function status() {
  const [program, programData, global] = await conn.getMultipleAccountsInfo([P.programId, P.programData, P.global]);
  console.log(`Cluster:  ${cluster} (${rpc})`);
  console.log(`Program:  ${programId} ${program?.executable ? 'deployed' : 'NOT deployed'}`);
  if (programData && programData.data.length >= 45 && programData.data[12] === 1) {
    console.log(`Upgrade authority: ${new PublicKey(programData.data.subarray(13, 45)).toBase58()}`);
  }
  if (!global) return console.log('Global:   not initialized');
  const g = L.decodeGlobal(global.data);
  console.log(`Admin:            ${g.authority}`);
  console.log(`Fee wallet:       ${g.feeRecipient}`);
  console.log(`Migration wallet: ${g.migrationAuthority}`);
  console.log(`Fee:              ${g.feeBps / 100}%   Paused: ${g.paused}   Launches: ${g.launchCount}`);
}

async function init() {
  const path = (args.keypair || '~/.config/solana/id.json').replace(/^~/, os.homedir());
  const deployer = Keypair.fromSecretKey(Uint8Array.from(JSON.parse(readFileSync(path, 'utf8'))));
  const admin = key('admin', deployer.publicKey);
  const feeWallet = key('fee-wallet');
  const migrationWallet = key('migration-wallet');
  const feeBps = Number(args['fee-bps'] ?? 100);
  if (!Number.isInteger(feeBps) || feeBps < 0 || feeBps > L.MAX_FEE_BPS) throw new Error('--fee-bps must be 0-500');

  const [program, programData, global, feeAcc] = await conn.getMultipleAccountsInfo([P.programId, P.programData, P.global, feeWallet]);
  if (!program?.executable) throw new Error(`Program ${programId} is not deployed on ${cluster}.`);
  const upgradeAuthority = programData && programData.data[12] === 1 ? new PublicKey(programData.data.subarray(13, 45)) : null;
  if (!upgradeAuthority?.equals(deployer.publicKey)) {
    throw new Error(`Only the upgrade authority (${upgradeAuthority?.toBase58() ?? 'none'}) can initialize; keypair is ${deployer.publicKey.toBase58()}.`);
  }
  if (global) throw new Error('Already initialized. Run "status" to see the settings.');
  if (!feeAcc || feeAcc.lamports < 1_000_000) {
    console.warn('Warning: the fee wallet holds under 0.001 SOL. Fund it so it can receive small fees.');
  }

  const tx = new Transaction().add(
    I.initializeGlobal(deployer.publicKey, { feeRecipient: feeWallet, migrationAuthority: migrationWallet, feeBps, ...L.DEFAULT_CURVE })
  );
  if (!admin.equals(deployer.publicKey)) tx.add(I.updateGlobal(deployer.publicKey, { newAuthority: admin }));
  const sig = await sendAndPoll(tx, deployer);
  console.log(`Initialized: ${solscan('tx', sig)}`);
  await status();
}

(command === 'init' ? init() : status()).catch((e) => {
  console.error(e.message || e);
  process.exit(1);
});
