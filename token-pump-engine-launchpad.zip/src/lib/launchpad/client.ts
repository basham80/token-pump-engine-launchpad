/**
 * Client for the meme_pump_engine launchpad program (v0.2).
 *
 * Instruction bytes, account lists, account layouts and curve math here are checked
 * byte-for-byte against the Rust program by scripts/launchpad-client.test.ts.
 * Shared by the browser (React views) and the Express server.
 */
import { Buffer } from 'buffer';
import { PublicKey, SystemProgram, SYSVAR_RENT_PUBKEY, TransactionInstruction } from '@solana/web3.js';
import { ASSOCIATED_TOKEN_PROGRAM_ID, TOKEN_PROGRAM_ID, getAssociatedTokenAddressSync } from '@solana/spl-token';

export const DEFAULT_PROGRAM_ID = 'J7yRzjdTL9HPaEikZ3vzcU7z6BFqcYKTBkYPqKEbvyrh';
export const TOKEN_METADATA_PROGRAM_ID = new PublicKey('metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s');
export const BPF_LOADER_UPGRADEABLE_ID = new PublicKey('BPFLoaderUpgradeab1e11111111111111111111111');

export const TOKEN_DECIMALS = 6;
export const MAX_FEE_BPS = 500;
export const MAX_NAME_LEN = 32;
export const MAX_SYMBOL_LEN = 10;
export const MAX_URI_LEN = 200;

/** pump.fun-style defaults: ~85 SOL sells out the curve, 20.69% of supply is reserved for the DEX pool. */
export const DEFAULT_CURVE = {
  initialVirtualSolReserves: 30_000_000_000n,
  initialVirtualTokenReserves: 1_073_000_000_000_000n,
  initialRealTokenReserves: 793_100_000_000_000n,
  tokenTotalSupply: 1_000_000_000_000_000n,
};

// Anchor discriminators: sha256("global:<ix>")[..8] and sha256("account:<Name>")[..8]
const IX = {
  initializeGlobal: '2fe10f705633bee7',
  updateGlobal: '5a98f015c7264814',
  launchToken: '0a8056ab0389a1f4',
  buy: '66063d1201daebea',
  sell: '33e685a4017f83ad',
  withdrawForMigration: 'e51e52683efb4b45',
  recordMigrationPool: '50b0cd64c4a4f919',
} as const;
const ACCOUNT_DISC = {
  Global: 'a7e8e8b1c86c727f',
  CurveState: 'c69830ff5b040ac5',
  LaunchRecord: '92f0c5cc0606574b',
} as const;

export const PROGRAM_ERRORS: Record<number, string> = {
  6000: 'This curve has sold out and is closed to trading',
  6001: 'This curve has not sold out yet',
  6002: 'Funds for this curve were already withdrawn for migration',
  6003: 'Funds for this curve have not been withdrawn for migration yet',
  6004: 'Math overflow',
  6005: 'Price moved beyond your slippage limit',
  6006: 'Amount must be greater than zero',
  6007: 'Platform fee exceeds the 5% cap',
  6008: 'Signer is not allowed to do this',
  6009: 'Curve does not hold enough reserves for this trade',
  6010: 'Launches and buys are paused by the platform',
  6011: 'Invalid bonding-curve parameters',
  6012: 'Token name, symbol or metadata URI is empty or too long',
};

// -------------------------------------------------------------
// PDAs
// -------------------------------------------------------------

const enc = new TextEncoder();
const pk = (k: PublicKey | string) => (typeof k === 'string' ? new PublicKey(k) : k);

export function launchpadPdas(programId: PublicKey | string = DEFAULT_PROGRAM_ID) {
  const pid = pk(programId);
  const find = (seeds: Uint8Array[], owner = pid) => PublicKey.findProgramAddressSync(seeds, owner)[0];
  return {
    programId: pid,
    global: find([enc.encode('global')]),
    mintAuthority: find([enc.encode('mint_authority')]),
    programData: find([pid.toBytes()], BPF_LOADER_UPGRADEABLE_ID),
    curve: (mint: PublicKey | string) => find([enc.encode('curve'), pk(mint).toBytes()]),
    launchRecord: (index: bigint | number) => find([enc.encode('launch'), u64(BigInt(index))]),
    metadata: (mint: PublicKey | string) =>
      find([enc.encode('metadata'), TOKEN_METADATA_PROGRAM_ID.toBytes(), pk(mint).toBytes()], TOKEN_METADATA_PROGRAM_ID),
    vault: (mint: PublicKey | string) => getAssociatedTokenAddressSync(pk(mint), find([enc.encode('curve'), pk(mint).toBytes()]), true),
    ata: (owner: PublicKey | string, mint: PublicKey | string) => getAssociatedTokenAddressSync(pk(mint), pk(owner), true),
  };
}

// -------------------------------------------------------------
// Borsh encoding
// -------------------------------------------------------------

const U64_MAX = (1n << 64n) - 1n;

function u64(v: bigint): Uint8Array {
  if (v < 0n || v > U64_MAX) throw new Error(`u64 out of range: ${v}`);
  const b = new Uint8Array(8);
  new DataView(b.buffer).setBigUint64(0, v, true);
  return b;
}
function u16(v: number): Uint8Array {
  if (!Number.isInteger(v) || v < 0 || v > 0xffff) throw new Error(`u16 out of range: ${v}`);
  const b = new Uint8Array(2);
  new DataView(b.buffer).setUint16(0, v, true);
  return b;
}
function str(v: string): Uint8Array {
  const bytes = enc.encode(v);
  const len = new Uint8Array(4);
  new DataView(len.buffer).setUint32(0, bytes.length, true);
  return concat([len, bytes]);
}
function opt<T>(v: T | undefined | null, f: (x: T) => Uint8Array): Uint8Array {
  return v === undefined || v === null ? Uint8Array.of(0) : concat([Uint8Array.of(1), f(v)]);
}
function hexBytes(h: string): Uint8Array {
  return Uint8Array.from(h.match(/../g)!.map((x) => parseInt(x, 16)));
}
function concat(parts: Uint8Array[]): Uint8Array {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}
const data = (disc: string, ...parts: Uint8Array[]) => Buffer.from(concat([hexBytes(disc), ...parts]));
const meta = (pubkey: PublicKey, isSigner: boolean, isWritable: boolean) => ({ pubkey, isSigner, isWritable });

// -------------------------------------------------------------
// Instructions
// -------------------------------------------------------------

export interface GlobalParams {
  feeRecipient: PublicKey | string;
  migrationAuthority: PublicKey | string;
  feeBps: number;
  initialVirtualSolReserves: bigint;
  initialVirtualTokenReserves: bigint;
  initialRealTokenReserves: bigint;
  tokenTotalSupply: bigint;
}

export interface UpdateGlobalParams {
  newAuthority?: PublicKey | string;
  feeRecipient?: PublicKey | string;
  migrationAuthority?: PublicKey | string;
  feeBps?: number;
  paused?: boolean;
  initialVirtualSolReserves?: bigint;
  initialVirtualTokenReserves?: bigint;
  initialRealTokenReserves?: bigint;
  tokenTotalSupply?: bigint;
}

export function launchpadInstructions(programId: PublicKey | string = DEFAULT_PROGRAM_ID) {
  const p = launchpadPdas(programId);
  const ix = (keys: ReturnType<typeof meta>[], d: Buffer) => new TransactionInstruction({ programId: p.programId, keys, data: d });

  return {
    /** One-time setup. Must be signed by the program's upgrade authority (the wallet that deployed it). */
    initializeGlobal(authority: PublicKey | string, params: GlobalParams) {
      return ix(
        [
          meta(pk(authority), true, true),
          meta(p.global, false, true),
          meta(p.programId, false, false),
          meta(p.programData, false, false),
          meta(SystemProgram.programId, false, false),
        ],
        data(
          IX.initializeGlobal,
          pk(params.feeRecipient).toBytes(),
          pk(params.migrationAuthority).toBytes(),
          u16(params.feeBps),
          u64(params.initialVirtualSolReserves),
          u64(params.initialVirtualTokenReserves),
          u64(params.initialRealTokenReserves),
          u64(params.tokenTotalSupply)
        )
      );
    },

    updateGlobal(authority: PublicKey | string, params: UpdateGlobalParams) {
      const key = (k: PublicKey | string) => pk(k).toBytes();
      return ix(
        [meta(pk(authority), true, false), meta(p.global, false, true)],
        data(
          IX.updateGlobal,
          opt(params.newAuthority, key),
          opt(params.feeRecipient, key),
          opt(params.migrationAuthority, key),
          opt(params.feeBps, u16),
          opt(params.paused, (b) => Uint8Array.of(b ? 1 : 0)),
          opt(params.initialVirtualSolReserves, u64),
          opt(params.initialVirtualTokenReserves, u64),
          opt(params.initialRealTokenReserves, u64),
          opt(params.tokenTotalSupply, u64)
        )
      );
    },

    /** `mint` is a fresh keypair that must also sign. `launchIndex` = Global.launchCount right now. */
    launchToken(creator: PublicKey | string, mint: PublicKey | string, launchIndex: bigint | number, name: string, symbol: string, uri: string) {
      return ix(
        [
          meta(pk(creator), true, true),
          meta(p.global, false, true),
          meta(p.mintAuthority, false, false),
          meta(pk(mint), true, true),
          meta(p.curve(mint), false, true),
          meta(p.vault(mint), false, true),
          meta(p.launchRecord(launchIndex), false, true),
          meta(TOKEN_METADATA_PROGRAM_ID, false, false),
          meta(p.metadata(mint), false, true),
          meta(TOKEN_PROGRAM_ID, false, false),
          meta(ASSOCIATED_TOKEN_PROGRAM_ID, false, false),
          meta(SystemProgram.programId, false, false),
          meta(SYSVAR_RENT_PUBKEY, false, false),
        ],
        data(IX.launchToken, str(name), str(symbol), str(uri))
      );
    },

    /** Puts at most `maxSolIn` lamports into the curve; the platform fee is charged on top. */
    buy(buyer: PublicKey | string, feeRecipient: PublicKey | string, mint: PublicKey | string, maxSolIn: bigint, minTokensOut: bigint) {
      return ix(
        [
          meta(pk(buyer), true, true),
          meta(p.global, false, false),
          meta(pk(feeRecipient), false, true),
          meta(pk(mint), false, false),
          meta(p.curve(mint), false, true),
          meta(p.vault(mint), false, true),
          meta(p.ata(buyer, mint), false, true),
          meta(TOKEN_PROGRAM_ID, false, false),
          meta(ASSOCIATED_TOKEN_PROGRAM_ID, false, false),
          meta(SystemProgram.programId, false, false),
        ],
        data(IX.buy, u64(maxSolIn), u64(minTokensOut))
      );
    },

    sell(seller: PublicKey | string, feeRecipient: PublicKey | string, mint: PublicKey | string, tokenAmount: bigint, minSolOut: bigint) {
      return ix(
        [
          meta(pk(seller), true, true),
          meta(p.global, false, false),
          meta(pk(feeRecipient), false, true),
          meta(pk(mint), false, false),
          meta(p.curve(mint), false, true),
          meta(p.vault(mint), false, true),
          meta(p.ata(seller, mint), false, true),
          meta(TOKEN_PROGRAM_ID, false, false),
          meta(SystemProgram.programId, false, false),
        ],
        data(IX.sell, u64(tokenAmount), u64(minSolOut))
      );
    },

    withdrawForMigration(migrationAuthority: PublicKey | string, mint: PublicKey | string) {
      return ix(
        [
          meta(pk(migrationAuthority), true, true),
          meta(p.global, false, false),
          meta(pk(mint), false, false),
          meta(p.curve(mint), false, true),
          meta(p.vault(mint), false, true),
          meta(p.ata(migrationAuthority, mint), false, true),
          meta(TOKEN_PROGRAM_ID, false, false),
          meta(ASSOCIATED_TOKEN_PROGRAM_ID, false, false),
          meta(SystemProgram.programId, false, false),
        ],
        data(IX.withdrawForMigration)
      );
    },

    recordMigrationPool(migrationAuthority: PublicKey | string, mint: PublicKey | string, pool: PublicKey | string) {
      return ix(
        [meta(pk(migrationAuthority), true, false), meta(p.global, false, false), meta(p.curve(mint), false, true)],
        data(IX.recordMigrationPool, pk(pool).toBytes())
      );
    },
  };
}

// -------------------------------------------------------------
// Account decoding
// -------------------------------------------------------------

export interface GlobalAccount {
  authority: string;
  feeRecipient: string;
  migrationAuthority: string;
  feeBps: number;
  paused: boolean;
  initialVirtualSolReserves: bigint;
  initialVirtualTokenReserves: bigint;
  initialRealTokenReserves: bigint;
  tokenTotalSupply: bigint;
  launchCount: bigint;
  bump: number;
}

export interface CurveAccount {
  mint: string;
  creator: string;
  launchIndex: bigint;
  createdAt: bigint;
  virtualSolReserves: bigint;
  virtualTokenReserves: bigint;
  realSolReserves: bigint;
  realTokenReserves: bigint;
  initialRealTokenReserves: bigint;
  tokenTotalSupply: bigint;
  volumeLamports: bigint;
  feesLamports: bigint;
  tradeCount: bigint;
  complete: boolean;
  migrated: boolean;
  migrationSol: bigint;
  migrationTokens: bigint;
  migrationPool: string | null;
  bump: number;
}

export interface LaunchRecordAccount {
  index: bigint;
  mint: string;
  creator: string;
  createdAt: bigint;
  bump: number;
}

class Reader {
  private o = 8;
  private v: DataView;
  constructor(private b: Uint8Array, disc: string, name: string) {
    const head = Array.from(b.slice(0, 8), (x) => x.toString(16).padStart(2, '0')).join('');
    if (head !== disc) throw new Error(`Not a ${name} account`);
    this.v = new DataView(b.buffer, b.byteOffset, b.byteLength);
  }
  key() {
    const k = new PublicKey(this.b.slice(this.o, this.o + 32)).toBase58();
    this.o += 32;
    return k;
  }
  u64() {
    const x = this.v.getBigUint64(this.o, true);
    this.o += 8;
    return x;
  }
  i64() {
    const x = this.v.getBigInt64(this.o, true);
    this.o += 8;
    return x;
  }
  u16() {
    const x = this.v.getUint16(this.o, true);
    this.o += 2;
    return x;
  }
  u8() {
    return this.b[this.o++];
  }
  bool() {
    return this.u8() === 1;
  }
}

const DEFAULT_KEY = '11111111111111111111111111111111';

export function decodeGlobal(b: Uint8Array): GlobalAccount {
  const r = new Reader(b, ACCOUNT_DISC.Global, 'Global');
  return {
    authority: r.key(),
    feeRecipient: r.key(),
    migrationAuthority: r.key(),
    feeBps: r.u16(),
    paused: r.bool(),
    initialVirtualSolReserves: r.u64(),
    initialVirtualTokenReserves: r.u64(),
    initialRealTokenReserves: r.u64(),
    tokenTotalSupply: r.u64(),
    launchCount: r.u64(),
    bump: r.u8(),
  };
}

export function decodeCurve(b: Uint8Array): CurveAccount {
  const r = new Reader(b, ACCOUNT_DISC.CurveState, 'CurveState');
  const c = {
    mint: r.key(),
    creator: r.key(),
    launchIndex: r.u64(),
    createdAt: r.i64(),
    virtualSolReserves: r.u64(),
    virtualTokenReserves: r.u64(),
    realSolReserves: r.u64(),
    realTokenReserves: r.u64(),
    initialRealTokenReserves: r.u64(),
    tokenTotalSupply: r.u64(),
    volumeLamports: r.u64(),
    feesLamports: r.u64(),
    tradeCount: r.u64(),
    complete: r.bool(),
    migrated: r.bool(),
    migrationSol: r.u64(),
    migrationTokens: r.u64(),
    migrationPool: r.key() as string | null,
    bump: r.u8(),
  };
  if (c.migrationPool === DEFAULT_KEY) c.migrationPool = null;
  return c;
}

export function decodeLaunchRecord(b: Uint8Array): LaunchRecordAccount {
  const r = new Reader(b, ACCOUNT_DISC.LaunchRecord, 'LaunchRecord');
  return { index: r.u64(), mint: r.key(), creator: r.key(), createdAt: r.i64(), bump: r.u8() };
}

/** Name / symbol / URI from a Metaplex metadata account. */
export function decodeMetadataBasics(b: Uint8Array): { name: string; symbol: string; uri: string } {
  const v = new DataView(b.buffer, b.byteOffset, b.byteLength);
  let o = 1 + 32 + 32;
  const s = () => {
    const len = v.getUint32(o, true);
    o += 4;
    const out = new TextDecoder().decode(b.slice(o, o + len)).replace(/\0/g, '').trim();
    o += len;
    return out;
  };
  return { name: s(), symbol: s(), uri: s() };
}

// -------------------------------------------------------------
// Curve math (mirrors programs/meme-pump-engine/src/math.rs)
// -------------------------------------------------------------

export class CurveMathError extends Error {
  constructor(public code: 'ZeroAmount' | 'CurveCompleted' | 'MathOverflow' | 'InsufficientReserves' | 'InvalidCurveParams') {
    super(code);
  }
}

const BPS = 10_000n;
const ceilDiv = (a: bigint, b: bigint) => {
  if (b <= 0n) throw new CurveMathError('MathOverflow');
  return (a + b - 1n) / b;
};
const toU64 = (v: bigint) => {
  if (v < 0n || v > U64_MAX) throw new CurveMathError('MathOverflow');
  return v;
};

export function feeOn(amount: bigint, feeBps: number): bigint {
  return toU64(ceilDiv(amount * BigInt(feeBps), BPS));
}

export interface BuyQuote {
  solIn: bigint;
  fee: bigint;
  tokensOut: bigint;
  newVirtualSol: bigint;
  newVirtualToken: bigint;
  completes: boolean;
}

export function quoteBuy(virtualSol: bigint, virtualToken: bigint, realToken: bigint, feeBps: number, maxSolIn: bigint): BuyQuote {
  if (maxSolIn <= 0n) throw new CurveMathError('ZeroAmount');
  if (realToken <= 0n) throw new CurveMathError('CurveCompleted');
  const k = virtualSol * virtualToken;
  const uncappedVSol = virtualSol + maxSolIn;
  const uncappedVTok = ceilDiv(k, uncappedVSol);
  const uncappedOut = virtualToken - uncappedVTok;
  if (uncappedOut < 0n) throw new CurveMathError('MathOverflow');

  let solIn: bigint, tokensOut: bigint, newVSol: bigint, newVTok: bigint, completes: boolean;
  if (uncappedOut >= realToken) {
    tokensOut = realToken;
    newVTok = virtualToken - tokensOut;
    if (newVTok <= 0n) throw new CurveMathError('InvalidCurveParams');
    newVSol = ceilDiv(k, newVTok);
    solIn = newVSol - virtualSol;
    completes = true;
  } else {
    [solIn, tokensOut, newVSol, newVTok, completes] = [maxSolIn, uncappedOut, uncappedVSol, uncappedVTok, false];
  }
  if (tokensOut <= 0n) throw new CurveMathError('ZeroAmount');
  if (solIn <= 0n || solIn > maxSolIn) throw new CurveMathError('MathOverflow');
  return {
    solIn: toU64(solIn),
    fee: feeOn(solIn, feeBps),
    tokensOut: toU64(tokensOut),
    newVirtualSol: toU64(newVSol),
    newVirtualToken: toU64(newVTok),
    completes,
  };
}

export interface SellQuote {
  solOutGross: bigint;
  fee: bigint;
  solOutNet: bigint;
  newVirtualSol: bigint;
  newVirtualToken: bigint;
}

export function quoteSell(virtualSol: bigint, virtualToken: bigint, realSol: bigint, feeBps: number, tokenAmount: bigint): SellQuote {
  if (tokenAmount <= 0n) throw new CurveMathError('ZeroAmount');
  const k = virtualSol * virtualToken;
  const newVTok = virtualToken + tokenAmount;
  const newVSol = ceilDiv(k, newVTok);
  const gross = virtualSol - newVSol;
  if (gross <= 0n) throw new CurveMathError('ZeroAmount');
  if (gross > realSol) throw new CurveMathError('InsufficientReserves');
  const fee = feeOn(gross, feeBps);
  const net = gross - fee;
  if (net <= 0n) throw new CurveMathError('ZeroAmount');
  return { solOutGross: toU64(gross), fee, solOutNet: net, newVirtualSol: toU64(newVSol), newVirtualToken: toU64(newVTok) };
}

/** Largest amount that can go into the curve when the wallet wants to spend `totalLamports` including the fee. */
export function solInForBudget(totalLamports: bigint, feeBps: number): bigint {
  if (totalLamports <= 0n) return 0n;
  let solIn = (totalLamports * BPS) / (BPS + BigInt(feeBps));
  while (solIn > 0n && solIn + feeOn(solIn, feeBps) > totalLamports) solIn -= 1n;
  return solIn;
}

/** Applies a slippage tolerance (in basis points) to an expected output. */
export function withSlippage(expected: bigint, slippageBps: number): bigint {
  return (expected * BigInt(10_000 - slippageBps)) / 10_000n;
}

/** Spot price in SOL per whole token. */
export function spotPriceSol(c: Pick<CurveAccount, 'virtualSolReserves' | 'virtualTokenReserves'>): number {
  return Number(c.virtualSolReserves) / 1e9 / (Number(c.virtualTokenReserves) / 10 ** TOKEN_DECIMALS);
}

/** Share of the sale supply already sold, 0–100. */
export function progressPct(c: Pick<CurveAccount, 'realTokenReserves' | 'initialRealTokenReserves'>): number {
  if (c.initialRealTokenReserves === 0n) return 0;
  return Number(((c.initialRealTokenReserves - c.realTokenReserves) * 10_000n) / c.initialRealTokenReserves) / 100;
}

/** SOL still needed to sell out the curve (excluding fees). */
export function solToComplete(c: Pick<CurveAccount, 'virtualSolReserves' | 'virtualTokenReserves' | 'realTokenReserves'>): bigint {
  if (c.realTokenReserves === 0n) return 0n;
  const k = c.virtualSolReserves * c.virtualTokenReserves;
  return ceilDiv(k, c.virtualTokenReserves - c.realTokenReserves) - c.virtualSolReserves;
}

export function describeProgramError(message: string): string {
  const m = message.match(/custom program error: 0x([0-9a-f]+)/i) || message.match(/"Custom":\s*(\d+)/);
  if (!m) return message;
  const code = m[0].includes('0x') ? parseInt(m[1], 16) : Number(m[1]);
  return PROGRAM_ERRORS[code] ? `${PROGRAM_ERRORS[code]} (error ${code})` : message;
}
