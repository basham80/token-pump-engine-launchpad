import { PublicKey, type Connection, type ParsedAccountData } from '@solana/web3.js';
import { getAssociatedTokenAddressSync, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { getConnection, rotateMainnetConnection } from './solanaWeb3Service';
import type { LivePoolInfo, LivePoolKind, LivePoolsResponse, LivePoolToken } from '../types';

/**
 * Live pool reader.
 *
 * Every figure returned here comes from one of two places, fetched at request time:
 *   1. Solana mainnet RPC  – does the pool account exist, and which program owns it?
 *   2. Raydium API v3      – reserves, TVL, price, 24h volume/fees, LP supply, LP burn %.
 * The connected wallet's LP balance is read from its token accounts on-chain.
 *
 * There is no fallback to stored, simulated or estimated numbers: if a source can't be
 * reached, the field stays null and the reason is reported in `errors`.
 */

const RAYDIUM_API_BASE = (process.env.RAYDIUM_API_BASE || 'https://api-v3.raydium.io').replace(/\/+$/, '');
const MAX_POOLS_PER_REQUEST = 25;
const CACHE_TTL_MS = 30_000;
const HTTP_TIMEOUT_MS = 10_000;
const RPC_TIMEOUT_MS = 12_000;

const RAYDIUM_POOL_PROGRAMS: Record<string, { label: string; kind: LivePoolKind }> = {
  '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8': { label: 'Raydium AMM v4', kind: 'AMM_V4' },
  CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C: { label: 'Raydium CPMM', kind: 'CPMM' },
  CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK: { label: 'Raydium CLMM', kind: 'CLMM' },
};

const OTHER_PROGRAM_LABELS: Record<string, string> = {
  '11111111111111111111111111111111': 'System Program (a wallet, not a pool)',
  TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA: 'SPL Token Program',
  TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb: 'Token-2022 Program',
};

const cache = new Map<string, { at: number; data: LivePoolsResponse }>();
const inflight = new Map<string, Promise<LivePoolsResponse>>();

const errMsg = (e: unknown) => (e instanceof Error ? e.message : String(e));
const shortAddr = (a: string) => (a.length > 12 ? `${a.slice(0, 4)}…${a.slice(-4)}` : a);

function num(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

/** Runs an RPC call on the current mainnet connection, retrying once on the next configured RPC. */
async function rpc<T>(label: string, run: (conn: Connection) => Promise<T>): Promise<T> {
  try {
    return await withTimeout(run(getConnection('mainnet-beta')), RPC_TIMEOUT_MS, label);
  } catch {
    return await withTimeout(run(rotateMainnetConnection()), RPC_TIMEOUT_MS, label);
  }
}

async function fetchJson(url: string): Promise<any> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), HTTP_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal, headers: { accept: 'application/json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (e) {
    if (controller.signal.aborted) throw new Error(`timed out after ${HTTP_TIMEOUT_MS / 1000}s`);
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

/** Raydium API v3 pool stats, keyed by pool id. Unknown ids come back as null entries and are skipped. */
async function fetchRaydiumPools(ids: string[]): Promise<Map<string, any>> {
  const byId = new Map<string, any>();
  for (let i = 0; i < ids.length; i += 20) {
    const chunk = ids.slice(i, i + 20);
    const json = await fetchJson(`${RAYDIUM_API_BASE}/pools/info/ids?ids=${chunk.join(',')}`);
    if (!json || json.success !== true || !Array.isArray(json.data)) {
      throw new Error('unexpected response from Raydium API');
    }
    // The API does not guarantee input order, so match on each entry's own id.
    for (const entry of json.data) {
      if (entry && typeof entry.id === 'string') byId.set(entry.id, entry);
    }
  }
  return byId;
}

function tokenFromApi(m: any): LivePoolToken | null {
  if (!m || typeof m.address !== 'string') return null;
  return {
    mint: m.address,
    symbol: typeof m.symbol === 'string' && m.symbol.trim() ? m.symbol.trim() : shortAddr(m.address),
    decimals: num(m.decimals) ?? 0,
    logo: typeof m.logoURI === 'string' && m.logoURI ? m.logoURI : undefined,
  };
}

function kindFromApi(entry: any): LivePoolKind {
  const program = String(entry?.programId || '');
  if (RAYDIUM_POOL_PROGRAMS[program]) return RAYDIUM_POOL_PROGRAMS[program].kind;
  if (entry?.type === 'Concentrated') return 'CLMM';
  return 'OTHER';
}

function emptyInfo(poolId: string, wallet: string | null, fetchedAt: number): LivePoolInfo {
  return {
    poolId,
    status: 'UNVERIFIED',
    statusDetail: '',
    accountExists: null,
    ownerProgram: null,
    ownerProgramLabel: null,
    poolKind: null,
    mintA: null,
    mintB: null,
    reserveA: null,
    reserveB: null,
    price: null,
    tvlUsd: null,
    feeRate: null,
    volume24hUsd: null,
    fees24hUsd: null,
    lpMint: null,
    lpSupply: null,
    lpBurnPct: null,
    wallet,
    walletLpBalance: null,
    walletLpCheck: 'NOT_CHECKED',
    walletSharePct: null,
    walletValueUsd: null,
    walletAmountA: null,
    walletAmountB: null,
    sources: [],
    fetchedAt,
    errors: [],
  };
}

function applyRaydiumStats(info: LivePoolInfo, entry: any) {
  info.poolKind = kindFromApi(entry);
  info.mintA = tokenFromApi(entry.mintA);
  info.mintB = tokenFromApi(entry.mintB);
  info.reserveA = num(entry.mintAmountA);
  info.reserveB = num(entry.mintAmountB);
  info.price = num(entry.price);
  info.tvlUsd = num(entry.tvl);
  info.feeRate = num(entry.feeRate);
  info.volume24hUsd = num(entry.day?.volume);
  info.fees24hUsd = num(entry.day?.volumeFee);
  info.lpMint = typeof entry.lpMint?.address === 'string' ? entry.lpMint.address : null;
  info.lpSupply = num(entry.lpAmount);
  info.lpBurnPct = num(entry.burnPercent);
  if (!info.ownerProgramLabel && RAYDIUM_POOL_PROGRAMS[String(entry.programId)]) {
    info.ownerProgram = String(entry.programId);
    info.ownerProgramLabel = RAYDIUM_POOL_PROGRAMS[info.ownerProgram].label;
  }
  info.sources.push('raydium-api');
}

/**
 * Sums the wallet's balance of each LP mint.
 * Prefers a full scan of the wallet's token accounts; some public RPCs block that method,
 * in which case it reads the wallet's associated token account for each LP mint instead.
 */
async function getWalletLpBalances(
  owner: PublicKey,
  lps: { mint: string; programId: string }[]
): Promise<{ balances: Map<string, number>; method: LivePoolInfo['walletLpCheck'] }> {
  const unique = Array.from(new Map(lps.map((l) => [l.mint, l])).values());
  const wanted = new Set(unique.map((l) => l.mint));
  const balances = new Map<string, number>();

  try {
    const programs = Array.from(new Set(unique.map((l) => l.programId)));
    for (const program of programs) {
      const res = await withTimeout(
        getConnection('mainnet-beta').getParsedTokenAccountsByOwner(owner, { programId: new PublicKey(program) }),
        RPC_TIMEOUT_MS,
        'getTokenAccountsByOwner'
      );
      for (const { account } of res.value) {
        const parsedInfo = (account.data as ParsedAccountData)?.parsed?.info;
        const mint = parsedInfo?.mint;
        if (typeof mint !== 'string' || !wanted.has(mint)) continue;
        const amount = num(parsedInfo.tokenAmount?.uiAmountString) ?? 0;
        balances.set(mint, (balances.get(mint) || 0) + amount);
      }
    }
    for (const mint of wanted) if (!balances.has(mint)) balances.set(mint, 0);
    return { balances, method: 'ALL_TOKEN_ACCOUNTS' };
  } catch {
    balances.clear();
    const atas = unique.map((l) =>
      getAssociatedTokenAddressSync(new PublicKey(l.mint), owner, true, new PublicKey(l.programId))
    );
    const res = await rpc('getMultipleAccounts (LP token accounts)', (conn) => conn.getMultipleParsedAccounts(atas));
    res.value.forEach((account, idx) => {
      const parsedInfo = (account?.data as ParsedAccountData | undefined)?.parsed?.info;
      balances.set(unique[idx].mint, parsedInfo ? num(parsedInfo.tokenAmount?.uiAmountString) ?? 0 : 0);
    });
    return { balances, method: 'ASSOCIATED_ACCOUNT_ONLY' };
  }
}

async function buildLivePools(ids: string[], walletPk: PublicKey | null, inputErrors: string[]): Promise<LivePoolsResponse> {
  const fetchedAt = Date.now();
  const wallet = walletPk ? walletPk.toBase58() : null;
  const errors = [...inputErrors];

  const valid: { id: string; pk: PublicKey }[] = [];
  const invalid = new Set<string>();
  for (const id of ids) {
    try {
      valid.push({ id, pk: new PublicKey(id) });
    } catch {
      invalid.add(id);
    }
  }

  const [accountsResult, statsResult] = await Promise.allSettled([
    valid.length
      ? rpc('getMultipleAccounts', (conn) => conn.getMultipleAccountsInfo(valid.map((v) => v.pk)))
      : Promise.resolve([]),
    valid.length ? fetchRaydiumPools(valid.map((v) => v.id)) : Promise.resolve(new Map<string, any>()),
  ]);

  const accounts = accountsResult.status === 'fulfilled' ? accountsResult.value : null;
  if (accountsResult.status === 'rejected') errors.push(`Solana RPC unavailable: ${errMsg(accountsResult.reason)}`);
  const stats = statsResult.status === 'fulfilled' ? statsResult.value : null;
  if (statsResult.status === 'rejected') errors.push(`Raydium API unavailable: ${errMsg(statsResult.reason)}`);

  const accountById = new Map<string, (typeof valid)[number] & { account: any }>();
  if (accounts) valid.forEach((v, idx) => accountById.set(v.id, { ...v, account: accounts[idx] }));

  const lpProgramByPool = new Map<string, string>();

  const pools: LivePoolInfo[] = ids.map((id) => {
    const info = emptyInfo(id, wallet, fetchedAt);

    if (invalid.has(id)) {
      info.status = 'INVALID_ID';
      info.statusDetail = 'Not a valid Solana address.';
      return info;
    }

    // 1. On-chain truth first: does the account exist, and who owns it?
    if (accounts) {
      const account = accountById.get(id)?.account ?? null;
      info.accountExists = Boolean(account);
      info.sources.push('solana-rpc');
      if (!account) {
        info.status = 'NOT_FOUND';
        info.statusDetail =
          'No account exists at this address on Solana mainnet. This pool was never created on-chain — it only exists in this app\'s records, so it has no reserves, fees or LP tokens.';
        return info;
      }
      info.ownerProgram = account.owner.toBase58();
      const raydium = RAYDIUM_POOL_PROGRAMS[info.ownerProgram];
      info.ownerProgramLabel = raydium?.label || OTHER_PROGRAM_LABELS[info.ownerProgram] || info.ownerProgram;
      if (!raydium) {
        info.status = 'NOT_A_POOL';
        info.statusDetail = `This address is owned by ${info.ownerProgramLabel}, not a Raydium pool program.`;
        return info;
      }
    }

    // 2. Live stats from Raydium.
    const entry = stats?.get(id);
    if (entry) {
      applyRaydiumStats(info, entry);
      const lpProgram = entry.lpMint?.programId;
      lpProgramByPool.set(id, typeof lpProgram === 'string' && lpProgram ? lpProgram : TOKEN_PROGRAM_ID.toBase58());
      info.status = 'LIVE';
      info.statusDetail = accounts
        ? `Pool account verified on Solana mainnet (owned by ${info.ownerProgramLabel}); stats from Raydium.`
        : 'Stats from Raydium; the Solana RPC check could not run.';
      return info;
    }

    if (accounts) {
      info.status = 'ONCHAIN_NO_STATS';
      info.poolKind = RAYDIUM_POOL_PROGRAMS[info.ownerProgram!]?.kind ?? null;
      info.statusDetail = stats
        ? `The account exists on-chain (owned by ${info.ownerProgramLabel}), but Raydium's API has no stats for it.`
        : `The account exists on-chain (owned by ${info.ownerProgramLabel}); Raydium's API could not be reached for stats.`;
      return info;
    }

    info.status = 'UNVERIFIED';
    info.statusDetail = "Couldn't reach Solana RPC or Raydium's API, so nothing is shown for this pool.";
    return info;
  });

  // 3. The wallet's real LP position in each live pool.
  if (walletPk) {
    const targets = pools.filter((p) => p.status === 'LIVE' && p.lpMint && p.poolKind !== 'CLMM');
    if (targets.length) {
      try {
        const { balances, method } = await getWalletLpBalances(
          walletPk,
          targets.map((p) => ({ mint: p.lpMint!, programId: lpProgramByPool.get(p.poolId)! }))
        );
        for (const p of targets) {
          const lp = balances.get(p.lpMint!) ?? 0;
          p.walletLpBalance = lp;
          p.walletLpCheck = method;
          if (lp === 0) {
            p.walletSharePct = 0;
            p.walletValueUsd = 0;
            p.walletAmountA = 0;
            p.walletAmountB = 0;
          } else if (p.lpSupply && p.lpSupply > 0) {
            const share = Math.min(1, lp / p.lpSupply);
            p.walletSharePct = share * 100;
            p.walletValueUsd = p.tvlUsd !== null ? share * p.tvlUsd : null;
            p.walletAmountA = p.reserveA !== null ? share * p.reserveA : null;
            p.walletAmountB = p.reserveB !== null ? share * p.reserveB : null;
          }
        }
      } catch (e) {
        errors.push(`Couldn't read the wallet's LP balances: ${errMsg(e)}`);
      }
    }
  }

  const data: LivePoolsResponse = { ok: true, wallet, pools, fetchedAt, errors };
  // Only cache complete answers, so a temporary outage is retried on the next request.
  if (accounts && stats && errors.length === inputErrors.length) {
    cache.set(cacheKeyFor(ids, wallet), { at: fetchedAt, data });
    if (cache.size > 100) cache.delete(cache.keys().next().value as string);
  }
  return data;
}

function cacheKeyFor(ids: string[], wallet: string | null) {
  return `${[...ids].sort().join(',')}|${wallet || ''}`;
}

export const livePoolService = {
  async getLivePools(rawIds: string[], rawWallet?: string | null): Promise<LivePoolsResponse> {
    const ids = Array.from(new Set(rawIds.map((s) => String(s || '').trim()).filter(Boolean))).slice(
      0,
      MAX_POOLS_PER_REQUEST
    );
    const inputErrors: string[] = [];
    if (rawIds.filter(Boolean).length > MAX_POOLS_PER_REQUEST) {
      inputErrors.push(`Only the first ${MAX_POOLS_PER_REQUEST} pools were checked.`);
    }

    let walletPk: PublicKey | null = null;
    if (rawWallet) {
      try {
        walletPk = new PublicKey(rawWallet);
      } catch {
        inputErrors.push(`"${rawWallet}" is not a valid wallet address, so LP positions were not checked.`);
      }
    }

    const key = cacheKeyFor(ids, walletPk ? walletPk.toBase58() : null);
    const cached = cache.get(key);
    if (cached && Date.now() - cached.at < CACHE_TTL_MS) return cached.data;

    const pending = inflight.get(key);
    if (pending) return pending;

    const request = buildLivePools(ids, walletPk, inputErrors).finally(() => inflight.delete(key));
    inflight.set(key, request);
    return request;
  },
};
