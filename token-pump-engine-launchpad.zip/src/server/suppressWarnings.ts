// Suppress benign native binding warnings from third-party libraries (e.g. bigint-buffer in @solana/spl-token)
const originalWarn = console.warn.bind(console);
console.warn = (...args: unknown[]) => {
  const msg = typeof args[0] === 'string' ? args[0] : '';
  if (msg.includes('bigint: Failed to load bindings') || msg.includes('pure JS will be used')) {
    return;
  }
  originalWarn(...args);
};

const stderrAny = process.stderr as unknown as {
  write: (chunk: unknown, encoding?: unknown, cb?: unknown) => boolean;
};
const originalStderrWrite = stderrAny.write.bind(process.stderr);

// Intercept direct stderr writes as well
stderrAny.write = (chunk: unknown, encoding?: unknown, cb?: unknown): boolean => {
  const str = typeof chunk === 'string' ? chunk : Buffer.isBuffer(chunk) ? chunk.toString() : '';
  if (str.includes('bigint: Failed to load bindings') || str.includes('pure JS will be used')) {
    if (typeof encoding === 'function') (encoding as () => void)();
    else if (typeof cb === 'function') (cb as () => void)();
    return true;
  }
  return originalStderrWrite(chunk, encoding, cb);
};

export {};
