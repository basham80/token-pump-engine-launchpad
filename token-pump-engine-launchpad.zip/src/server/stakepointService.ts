import fs from 'fs';
import path from 'path';
import type { StakingPool, UserStakePosition, TokenLockItem } from '../types';

const PERSISTED_STAKING_PATH = path.resolve(process.cwd(), 'src/server/data/persisted_staking.json');
const PERSISTED_LOCKS_PATH = path.resolve(process.cwd(), 'src/server/data/persisted_locks.json');

const DEFAULT_POOLS: StakingPool[] = [
  {
    id: 'pool-bash-spt',
    name: 'BASHAM Staking Pool',
    symbol: 'BASH',
    mint: '6uUUpKjR7WqfR2pM4n1L8n7r5g7L1h4E1K8n1K2jxrm7',
    logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    badge: '★ Most Popular',
    badgeType: 'popular',
    priceUsd: 0.000185,
    change24hPct: 14.2,
    aprPct: 21.68,
    baseAprPct: 21.68,
    lockDays: 0,
    poolType: 'FLEXIBLE',
    totalStakedTokens: 1_240_000_000,
    totalStakedUsd: 229_400,
    rewardTokenSymbol: 'BASH',
    rewardTokenMint: '6uUUpKjR7WqfR2pM4n1L8n7r5g7L1h4E1K8n1K2jxrm7',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    stakersCount: 1428,
    vaultPda: 'BashVault111111111111111111111111111111111111',
    rewardVaultPda: 'BashReward11111111111111111111111111111111111',
    isVerified: true,
    isFeatured: true,
    minStakeAmount: 1000,
    status: 'ACTIVE',
    description: 'Stake $BASH with flexible lock or tiered multipliers to earn high yield and protocol fee reflections.',
    solscanUrl: 'https://solscan.io/account/BashVault111111111111111111111111111111111111',
  },
  {
    id: 'pool-antminer',
    name: 'AntMiner',
    symbol: 'ANT',
    mint: 'AntM1nerPuMpSoL99999999999999999999999999999',
    logo: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=128&q=80',
    badge: '🆕 Newest Pool',
    badgeType: 'new',
    priceUsd: 0.001639,
    change24hPct: 180.0,
    aprPct: 14.10,
    baseAprPct: 14.10,
    lockDays: 80,
    poolType: 'LOCKED',
    totalStakedTokens: 58_800_000,
    totalStakedUsd: 96_400,
    rewardTokenSymbol: 'ANT',
    rewardTokenMint: 'AntM1nerPuMpSoL99999999999999999999999999999',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=128&q=80',
    stakersCount: 342,
    vaultPda: 'AntVault1111111111111111111111111111111111111',
    rewardVaultPda: 'AntReward11111111111111111111111111111111111',
    isVerified: true,
    isFeatured: true,
    minStakeAmount: 500,
    status: 'ACTIVE',
    description: 'Hardware cloud hash-rate boosted pool with 80-day principal lock and daily auto-compounding rewards.',
    solscanUrl: 'https://solscan.io/account/AntVault1111111111111111111111111111111111111',
  },
  {
    id: 'pool-gcc',
    name: 'Global Cryptocurrency Community',
    symbol: 'GCC',
    mint: 'GCCSo1anaCommUn1ty99999999999999999999999999',
    logo: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=128&q=80',
    badge: '⚡ Active Now',
    badgeType: 'active',
    priceUsd: 0.00042,
    change24hPct: 40.4,
    aprPct: 40.42,
    baseAprPct: 40.42,
    lockDays: 30,
    poolType: 'LOCKED',
    totalStakedTokens: 742_000_000,
    totalStakedUsd: 311_640,
    rewardTokenSymbol: 'GCC',
    rewardTokenMint: 'GCCSo1anaCommUn1ty99999999999999999999999999',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&w=128&q=80',
    stakersCount: 876,
    vaultPda: 'GCCVault1111111111111111111111111111111111111',
    rewardVaultPda: 'GCCReward11111111111111111111111111111111111',
    isVerified: true,
    isFeatured: true,
    minStakeAmount: 10000,
    status: 'ACTIVE',
    description: 'Premier community ecosystem staking vault with direct token governance voting weights.',
    solscanUrl: 'https://solscan.io/account/GCCVault1111111111111111111111111111111111111',
  },
  {
    id: 'pool-paws',
    name: '$PAWS',
    symbol: 'PAWS',
    mint: 'PAWSSo1anaCatDogPuMp1111111111111111111111111',
    logo: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=128&q=80',
    priceUsd: 0.00000417,
    change24hPct: 3.8,
    aprPct: 28.50,
    baseAprPct: 28.50,
    lockDays: 40,
    poolType: 'LOCKED',
    totalStakedTokens: 15_400_000_000,
    totalStakedUsd: 64_218,
    rewardTokenSymbol: 'PAWS',
    rewardTokenMint: 'PAWSSo1anaCatDogPuMp1111111111111111111111111',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=128&q=80',
    stakersCount: 512,
    vaultPda: 'PawsVault11111111111111111111111111111111111',
    rewardVaultPda: 'PawsReward1111111111111111111111111111111111',
    isVerified: true,
    minStakeAmount: 100000,
    status: 'ACTIVE',
    description: 'Community meme asset vault with 40-day soft lock and continuous reward streaming.',
    solscanUrl: 'https://solscan.io/account/PawsVault11111111111111111111111111111111111',
  },
  {
    id: 'pool-asx',
    name: 'Asinax Apex',
    symbol: 'ASX',
    mint: 'ASXApexSo1anaDef11111111111111111111111111111',
    logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=128&q=80',
    priceUsd: 0.00006234,
    change24hPct: -1.2,
    aprPct: 34.20,
    baseAprPct: 34.20,
    lockDays: 65,
    poolType: 'LOCKED',
    totalStakedTokens: 785_000_000,
    totalStakedUsd: 48_936,
    rewardTokenSymbol: 'ASX',
    rewardTokenMint: 'ASXApexSo1anaDef11111111111111111111111111111',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&w=128&q=80',
    stakersCount: 289,
    vaultPda: 'AsxVault111111111111111111111111111111111111',
    rewardVaultPda: 'AsxReward11111111111111111111111111111111111',
    isVerified: true,
    minStakeAmount: 50000,
    status: 'ACTIVE',
    description: 'Algorithmic trading yield vault with 65-day structured lock for long-term holders.',
    solscanUrl: 'https://solscan.io/account/AsxVault111111111111111111111111111111111111',
  },
  {
    id: 'pool-rarinu',
    name: 'Ferrari Inu Supercar Pool',
    symbol: 'RARINU',
    mint: 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
    logo: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80',
    badge: '🔥 Highest Yield',
    badgeType: 'popular',
    priceUsd: 0.000084,
    change24hPct: 24.6,
    aprPct: 68.40,
    baseAprPct: 68.40,
    lockDays: 0,
    poolType: 'FLEXIBLE',
    totalStakedTokens: 2_920_000_000,
    totalStakedUsd: 245_280,
    rewardTokenSymbol: 'RARINU',
    rewardTokenMint: 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80',
    stakersCount: 1894,
    vaultPda: '9X2oGXZAhwdU5WKpWEquK8bXNmyX2yb7RFguo2UP5mjZ',
    rewardVaultPda: 'H2ZSmpZrqXF8Ei7mg1cVDH22awy555xr4EiU94hbpqKm',
    isVerified: true,
    isFeatured: true,
    minStakeAmount: 10000,
    status: 'ACTIVE',
    description: 'Real on-chain Ferrari Inu ($RARINU) staking pool. No lockup required, instant unstake, automated Raydium fee rewards.',
    solscanUrl: 'https://solscan.io/token/svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
  },
  {
    id: 'pool-blank',
    name: 'BLANK Network Alpaca Vault',
    symbol: 'BLANK',
    mint: '2XwiQC1QGyW5Zr8ZdFUUYDAUA3AAuu3suC9gneUY3caf',
    logo: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=128&q=80',
    priceUsd: 0.0001426,
    change24hPct: 8.4,
    aprPct: 32.50,
    baseAprPct: 32.50,
    lockDays: 30,
    poolType: 'LOCKED',
    totalStakedTokens: 1_000_000_000,
    totalStakedUsd: 142_600,
    rewardTokenSymbol: 'BLANK',
    rewardTokenMint: '2XwiQC1QGyW5Zr8ZdFUUYDAUA3AAuu3suC9gneUY3caf',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=128&q=80',
    stakersCount: 954,
    vaultPda: 'BlankVault1111111111111111111111111111111111',
    rewardVaultPda: 'BlankReward111111111111111111111111111111111',
    isVerified: true,
    minStakeAmount: 10000,
    status: 'ACTIVE',
    description: 'Meme liquidity flywheel staking pool with 30-day lock and deflationary buyback yield.',
    solscanUrl: 'https://solscan.io/token/2XwiQC1QGyW5Zr8ZdFUUYDAUA3AAuu3suC9gneUY3caf',
  },
  {
    id: 'pool-ant-zec-lp',
    name: 'ANT-ZEC Raydium LP',
    symbol: 'ANT-ZEC LP',
    mint: 'AntZecLpRayd1umPo0l1111111111111111111111111',
    logo: 'https://images.unsplash.com/photo-1622979135225-d2ba269bc1df?auto=format&fit=crop&w=128&q=80',
    badge: '💎 381.2% APR',
    badgeType: 'popular',
    priceUsd: 1.45,
    change24hPct: 5.2,
    aprPct: 381.20,
    baseAprPct: 381.20,
    lockDays: 14,
    poolType: 'LP',
    totalStakedTokens: 289_600,
    totalStakedUsd: 419_920,
    rewardTokenSymbol: 'ANT',
    rewardTokenMint: 'AntM1nerPuMpSoL99999999999999999999999999999',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=128&q=80',
    stakersCount: 215,
    vaultPda: 'AntZecVault111111111111111111111111111111111',
    rewardVaultPda: 'AntZecReward11111111111111111111111111111111',
    isVerified: true,
    isFeatured: true,
    minStakeAmount: 1,
    status: 'ACTIVE',
    description: 'High-yield DEX liquidity provider staking farm with combined swap fees and farm emissions.',
    solscanUrl: 'https://solscan.io/account/AntZecVault111111111111111111111111111111111',
  },
  {
    id: 'pool-bash-wsol-lp',
    name: 'BASH-WSOL Raydium LP',
    symbol: 'BASH-WSOL LP',
    mint: 'BashWso1LpRayd1umPo0l111111111111111111111111',
    logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    badge: '🔥 197.4% APR',
    badgeType: 'popular',
    priceUsd: 3.25,
    change24hPct: 9.8,
    aprPct: 197.40,
    baseAprPct: 197.40,
    lockDays: 30,
    poolType: 'LP',
    totalStakedTokens: 178_400,
    totalStakedUsd: 579_800,
    rewardTokenSymbol: 'BASH',
    rewardTokenMint: '6uUUpKjR7WqfR2pM4n1L8n7r5g7L1h4E1K8n1K2jxrm7',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    stakersCount: 489,
    vaultPda: 'BashWsolVault1111111111111111111111111111111',
    rewardVaultPda: 'BashWsolReward111111111111111111111111111111',
    isVerified: true,
    isFeatured: true,
    minStakeAmount: 0.5,
    status: 'ACTIVE',
    description: 'Official BASH / WSOL LP farming vault. Stake Raydium CPMM LP tokens and earn automated buyback tokens.',
    solscanUrl: 'https://solscan.io/account/BashWsolVault1111111111111111111111111111111',
  },
  {
    id: 'pool-titcoin',
    name: 'Titcoin',
    symbol: 'TIT',
    mint: 'T1tCo1nSo1anaDef1999999999999999999999999999',
    logo: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=128&q=80',
    priceUsd: 0.00089,
    change24hPct: 1.5,
    aprPct: 9.70,
    baseAprPct: 9.70,
    lockDays: 0,
    poolType: 'FLEXIBLE',
    totalStakedTokens: 39_500_000,
    totalStakedUsd: 35_155,
    rewardTokenSymbol: 'TIT',
    rewardTokenMint: 'T1tCo1nSo1anaDef1999999999999999999999999999',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=128&q=80',
    stakersCount: 180,
    vaultPda: 'TitVault111111111111111111111111111111111111',
    rewardVaultPda: 'TitReward11111111111111111111111111111111111',
    isVerified: true,
    minStakeAmount: 1000,
    status: 'ACTIVE',
    description: 'Flexible staking pool with instant deposit and withdrawal freedom.',
    solscanUrl: 'https://solscan.io/account/TitVault111111111111111111111111111111111111',
  },
];

let poolsList: StakingPool[] = [...DEFAULT_POOLS];
let userStakesList: UserStakePosition[] = [
  {
    id: 'stake-rarinu-01',
    poolId: 'pool-rarinu',
    poolSymbol: 'RARINU',
    poolName: 'Ferrari Inu Supercar Pool',
    tokenMint: 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3',
    tokenLogo: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80',
    amountStaked: 100_000_000,
    amountStakedUsd: 8_400,
    stakedAt: Date.now() - 4 * 86400 * 1000,
    unlockAt: Date.now(),
    lockDays: 0,
    aprPct: 68.40,
    accruedRewards: 749_589.04,
    accruedRewardsUsd: 62.96,
    rewardTokenSymbol: 'RARINU',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80',
    status: 'STAKED',
    txSignature: '41jsQTVd1rXHabsdCmnfUoMKXigguWeVkp861yk3Jud7KuYuQTGEQDdTsQSRWSgNuVkEnaS8xvc8XjMJG7dSiBYV',
  },
  {
    id: 'stake-bash-02',
    poolId: 'pool-bash-spt',
    poolSymbol: 'BASH',
    poolName: 'BASHAM Staking Pool',
    tokenMint: '6uUUpKjR7WqfR2pM4n1L8n7r5g7L1h4E1K8n1K2jxrm7',
    tokenLogo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    amountStaked: 50_000_000,
    amountStakedUsd: 9_250,
    stakedAt: Date.now() - 2 * 86400 * 1000,
    unlockAt: Date.now() + 28 * 86400 * 1000,
    lockDays: 30,
    aprPct: 26.01,
    accruedRewards: 71_260.27,
    accruedRewardsUsd: 13.18,
    rewardTokenSymbol: 'BASH',
    rewardTokenLogo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
    status: 'STAKED',
    txSignature: '3gFNtRqfR34paWBaZtQ2Hw9bV8L1j4K7n1M8vE4sK6j8H2n1B9zX4cV7mD2',
  },
];

let tokenLocksList: TokenLockItem[] = [
  {
    id: 'lock-blank-01',
    tokenName: 'BLANK Network Liquidity LP',
    tokenSymbol: 'BLANK-SOL LP',
    tokenMint: 'RayBLANKNetWorkMemeCo1nLpPo0l111111111111111',
    tokenLogo: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=128&q=80',
    amount: 500,
    amountUsd: 142600,
    lockedAt: Date.now() - 15 * 86400 * 1000,
    unlockAt: Date.now() + 350 * 86400 * 1000,
    lockDays: 365,
    ownerAddress: 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i',
    vaultPda: 'LockVault11111111111111111111111111111111111',
    isLp: true,
    txSignature: '5LockB1ankLpRayd1um365Days999999999999999999',
  },
];

export const stakepointService = {
  loadFromDisk() {
    try {
      if (fs.existsSync(PERSISTED_STAKING_PATH)) {
        const content = fs.readFileSync(PERSISTED_STAKING_PATH, 'utf-8');
        const parsed = JSON.parse(content);
        if (parsed.pools && Array.isArray(parsed.pools)) {
          poolsList = parsed.pools;
        }
        if (parsed.userStakes && Array.isArray(parsed.userStakes)) {
          userStakesList = parsed.userStakes;
        }
      }
      if (fs.existsSync(PERSISTED_LOCKS_PATH)) {
        const content = fs.readFileSync(PERSISTED_LOCKS_PATH, 'utf-8');
        const parsed = JSON.parse(content);
        if (Array.isArray(parsed)) {
          tokenLocksList = parsed;
        }
      }
    } catch (e) {
      console.warn('[stakepointService] Failed loading from disk:', e);
    }
  },

  saveToDisk() {
    try {
      const dir = path.dirname(PERSISTED_STAKING_PATH);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(PERSISTED_STAKING_PATH, JSON.stringify({ pools: poolsList, userStakes: userStakesList }, null, 2), 'utf-8');
      fs.writeFileSync(PERSISTED_LOCKS_PATH, JSON.stringify(tokenLocksList, null, 2), 'utf-8');
    } catch (e) {
      console.warn('[stakepointService] Failed saving to disk:', e);
    }
  },

  getPools(): StakingPool[] {
    // Continuously accrue rewards for userStakes
    this.updateAccruedRewards();
    return poolsList.map((p) => {
      const userStake = userStakesList.filter((s) => s.poolId === p.id && s.status === 'STAKED');
      const totalUserStaked = userStake.reduce((acc, curr) => acc + curr.amountStaked, 0);
      const totalUserRewards = userStake.reduce((acc, curr) => acc + curr.accruedRewards, 0);
      return {
        ...p,
        userStakedAmount: totalUserStaked,
        userClaimableRewards: totalUserRewards,
      };
    });
  },

  getPoolById(id: string): StakingPool | undefined {
    return this.getPools().find((p) => p.id === id);
  },

  getUserStakes(address?: string): UserStakePosition[] {
    this.updateAccruedRewards();
    return userStakesList;
  },

  updateAccruedRewards() {
    const now = Date.now();
    userStakesList.forEach((s) => {
      if (s.status === 'STAKED') {
        const daysPassed = (now - s.stakedAt) / (86400 * 1000);
        const dailyRate = s.aprPct / 100 / 365;
        const totalEarned = s.amountStaked * dailyRate * daysPassed;
        s.accruedRewards = parseFloat(totalEarned.toFixed(4));
        const pool = poolsList.find((p) => p.id === s.poolId);
        const price = pool ? pool.priceUsd : 0.000185;
        s.accruedRewardsUsd = parseFloat((s.accruedRewards * price).toFixed(2));
      }
    });
  },

  createPool(params: {
    name: string;
    symbol: string;
    mint: string;
    logo?: string;
    priceUsd?: number;
    aprPct: number;
    lockDays?: number;
    poolType?: 'FLEXIBLE' | 'LOCKED' | 'LP' | 'TOKEN_2022';
    rewardTokenSymbol?: string;
    rewardTokenMint?: string;
    rewardTokenLogo?: string;
    initialVaultFundingTokens?: number;
    description?: string;
  }): { ok: boolean; pool?: StakingPool; txSignature?: string; error?: string } {
    const {
      name,
      symbol,
      mint,
      logo = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
      priceUsd = 0.0001,
      aprPct,
      lockDays = 0,
      poolType = 'FLEXIBLE',
      rewardTokenSymbol = symbol,
      rewardTokenMint = mint,
      rewardTokenLogo = logo,
      initialVaultFundingTokens = 1000000,
      description,
    } = params;

    if (!name || !symbol || !mint) {
      return { ok: false, error: 'Name, symbol, and mint address are required.' };
    }

    const id = `pool-${symbol.toLowerCase()}-${Date.now()}`;
    const pdaRand = Math.random().toString(36).substring(2, 8);
    const vaultPda = `StakeVault${pdaRand}${mint.slice(0, 12)}PDA`;
    const rewardVaultPda = `RewardVault${pdaRand}${rewardTokenMint.slice(0, 12)}PDA`;
    const txSignature = `5StakePoolCreate...${Math.random().toString(36).substring(2, 10)}${Date.now()}`;

    const newPool: StakingPool = {
      id,
      name,
      symbol,
      mint,
      logo,
      priceUsd,
      change24hPct: 0,
      aprPct: Number(aprPct),
      baseAprPct: Number(aprPct),
      lockDays: Number(lockDays),
      poolType,
      totalStakedTokens: Number(initialVaultFundingTokens),
      totalStakedUsd: Number(initialVaultFundingTokens) * priceUsd,
      rewardTokenSymbol,
      rewardTokenMint,
      rewardTokenLogo,
      stakersCount: 1,
      vaultPda,
      rewardVaultPda,
      isVerified: true,
      minStakeAmount: 10,
      status: 'ACTIVE',
      description: description || `Decentralized staking pool for ${name} ($${symbol}) with ${aprPct}% APR on Solana.`,
      solscanUrl: `https://solscan.io/account/${vaultPda}`,
    };

    poolsList.unshift(newPool);
    this.saveToDisk();

    return { ok: true, pool: newPool, txSignature };
  },

  stake(params: {
    poolId: string;
    amount: number;
    lockDays?: number;
    ownerAddress: string;
  }): { ok: boolean; stake?: UserStakePosition; txSignature?: string; error?: string } {
    const { poolId, amount, lockDays = 0, ownerAddress } = params;
    const pool = poolsList.find((p) => p.id === poolId);
    if (!pool) return { ok: false, error: 'Staking pool not found.' };
    if (amount <= 0) return { ok: false, error: 'Stake amount must be greater than zero.' };

    // Calculate lock duration multiplier
    let multiplier = 1.0;
    if (lockDays >= 365) multiplier = 3.0;
    else if (lockDays >= 180) multiplier = 2.2;
    else if (lockDays >= 90) multiplier = 1.8;
    else if (lockDays >= 60) multiplier = 1.5;
    else if (lockDays >= 30) multiplier = 1.2;

    const effectiveApr = parseFloat((pool.baseAprPct * multiplier).toFixed(2));
    const now = Date.now();
    const unlockAt = lockDays > 0 ? now + lockDays * 86400 * 1000 : now;
    const txSignature = `4StakeDeposit...${Math.random().toString(36).substring(2, 12)}${Date.now()}`;

    const newStake: UserStakePosition = {
      id: `stake-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      poolId: pool.id,
      poolSymbol: pool.symbol,
      poolName: pool.name,
      tokenMint: pool.mint,
      tokenLogo: pool.logo,
      amountStaked: amount,
      amountStakedUsd: parseFloat((amount * pool.priceUsd).toFixed(2)),
      stakedAt: now,
      unlockAt,
      lockDays,
      aprPct: effectiveApr,
      accruedRewards: 0,
      accruedRewardsUsd: 0,
      rewardTokenSymbol: pool.rewardTokenSymbol,
      rewardTokenLogo: pool.rewardTokenLogo,
      status: 'STAKED',
      txSignature,
    };

    userStakesList.unshift(newStake);
    pool.totalStakedTokens += amount;
    pool.totalStakedUsd = parseFloat((pool.totalStakedTokens * pool.priceUsd).toFixed(2));
    pool.stakersCount += 1;

    this.saveToDisk();
    return { ok: true, stake: newStake, txSignature };
  },

  claim(stakeId: string): { ok: boolean; amountClaimed?: number; symbol?: string; txSignature?: string; error?: string } {
    this.updateAccruedRewards();
    const stake = userStakesList.find((s) => s.id === stakeId);
    if (!stake) return { ok: false, error: 'Stake position not found.' };

    const claimed = stake.accruedRewards;
    if (claimed <= 0) return { ok: false, error: 'No claimable rewards accrued yet.' };

    const txSignature = `5RewardClaim...${Math.random().toString(36).substring(2, 12)}${Date.now()}`;
    stake.stakedAt = Date.now();
    stake.accruedRewards = 0;
    stake.accruedRewardsUsd = 0;

    this.saveToDisk();
    return { ok: true, amountClaimed: claimed, symbol: stake.rewardTokenSymbol, txSignature };
  },

  claimAll(ownerAddress?: string): { ok: boolean; totalClaimed?: number; results?: any[]; error?: string } {
    this.updateAccruedRewards();
    const activeStakes = userStakesList.filter((s) => s.status === 'STAKED' && s.accruedRewards > 0);
    if (activeStakes.length === 0) {
      return { ok: false, error: 'No claimable rewards available across active pools.' };
    }

    let totalClaimed = 0;
    const results: any[] = [];
    const now = Date.now();

    activeStakes.forEach((s) => {
      const amt = s.accruedRewards;
      totalClaimed += amt;
      const txSig = `5BatchClaim...${s.poolSymbol}...${Math.random().toString(36).substring(2, 8)}`;
      results.push({ poolSymbol: s.poolSymbol, amount: amt, txSignature: txSig });
      s.stakedAt = now;
      s.accruedRewards = 0;
      s.accruedRewardsUsd = 0;
    });

    this.saveToDisk();
    return { ok: true, totalClaimed: parseFloat(totalClaimed.toFixed(4)), results };
  },

  unstake(stakeId: string): { ok: boolean; amountUnstaked?: number; rewardsClaimed?: number; txSignature?: string; error?: string } {
    this.updateAccruedRewards();
    const stake = userStakesList.find((s) => s.id === stakeId);
    if (!stake) return { ok: false, error: 'Stake position not found.' };

    const now = Date.now();
    if (stake.unlockAt > now) {
      const remainingDays = Math.ceil((stake.unlockAt - now) / (86400 * 1000));
      return { ok: false, error: `Stake is locked for ${remainingDays} more day(s). Emergency unstake incurs a 15% lock penalty.` };
    }

    const unStakedAmt = stake.amountStaked;
    const rewards = stake.accruedRewards;
    stake.status = 'UNLOCKED';
    stake.accruedRewards = 0;

    const pool = poolsList.find((p) => p.id === stake.poolId);
    if (pool) {
      pool.totalStakedTokens = Math.max(0, pool.totalStakedTokens - unStakedAmt);
      pool.totalStakedUsd = parseFloat((pool.totalStakedTokens * pool.priceUsd).toFixed(2));
    }

    const txSignature = `3UnstakeWithdraw...${Math.random().toString(36).substring(2, 12)}${now}`;
    this.saveToDisk();

    return { ok: true, amountUnstaked: unStakedAmt, rewardsClaimed: rewards, txSignature };
  },

  getTokenLocks(): TokenLockItem[] {
    return tokenLocksList;
  },

  createTokenLock(params: {
    tokenName: string;
    tokenSymbol: string;
    tokenMint: string;
    amount: number;
    lockDays: number;
    ownerAddress: string;
    isLp?: boolean;
  }): { ok: boolean; lock?: TokenLockItem; txSignature?: string; error?: string } {
    const { tokenName, tokenSymbol, tokenMint, amount, lockDays, ownerAddress, isLp = false } = params;
    if (!tokenMint || amount <= 0 || lockDays <= 0) {
      return { ok: false, error: 'Invalid lock parameters.' };
    }

    const now = Date.now();
    const unlockAt = now + lockDays * 86400 * 1000;
    const vaultPda = `LockVault${Math.random().toString(36).substring(2, 8)}${tokenMint.slice(0, 10)}PDA`;
    const txSignature = `5LockDeposit...${Math.random().toString(36).substring(2, 12)}${now}`;

    const newLock: TokenLockItem = {
      id: `lock-${Date.now()}`,
      tokenName,
      tokenSymbol,
      tokenMint,
      tokenLogo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=128&q=80',
      amount,
      amountUsd: amount * 0.05,
      lockedAt: now,
      unlockAt,
      lockDays,
      ownerAddress,
      vaultPda,
      isLp,
      txSignature,
    };

    tokenLocksList.unshift(newLock);
    this.saveToDisk();

    return { ok: true, lock: newLock, txSignature };
  },
};

// Initialize disk state
try {
  stakepointService.loadFromDisk();
} catch (e) {
  console.warn('[stakepointService] Initialization notice:', e);
}
