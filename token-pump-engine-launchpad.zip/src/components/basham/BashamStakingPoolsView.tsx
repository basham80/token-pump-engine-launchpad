import React, { useState, useEffect } from 'react';
import {
  Coins,
  ShieldCheck,
  Flame,
  Lock,
  Unlock,
  TrendingUp,
  Sparkles,
  ArrowUpRight,
  ExternalLink,
  Search,
  Filter,
  CheckCircle2,
  RefreshCw,
  PlusCircle,
  Clock,
  Layers,
  ChevronDown,
  X,
  Wallet,
  Zap,
  Info,
  Calendar,
} from 'lucide-react';
import type { StakingPool, UserStakePosition, TokenMetadata, WalletState } from '../../types';

interface BashamStakingPoolsViewProps {
  wallet: WalletState;
  tokens: TokenMetadata[];
  onNavigateToMemeLaunch?: () => void;
  onRefreshWallet?: () => void;
}

export const BashamStakingPoolsView: React.FC<BashamStakingPoolsViewProps> = ({
  wallet,
  tokens,
  onNavigateToMemeLaunch,
  onRefreshWallet,
}) => {
  const [pools, setPools] = useState<StakingPool[]>([]);
  const [positions, setPositions] = useState<UserStakePosition[]>([]);
  const [totalTvlUsd, setTotalTvlUsd] = useState(4892150);
  const [totalStakers, setTotalStakers] = useState(3280);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'VERIFIED' | 'MEME' | 'HIGH_APY' | 'MY_STAKES'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'GRID' | 'TABLE'>('GRID');

  // Modal states
  const [selectedPoolForStake, setSelectedPoolForStake] = useState<StakingPool | null>(null);
  const [stakeAmount, setStakeAmount] = useState('');
  const [selectedLockDays, setSelectedLockDays] = useState<number>(30);
  const [isStaking, setIsStaking] = useState(false);
  const [stakeSuccessMsg, setStakeSuccessMsg] = useState<string | null>(null);

  // Unstake Modal
  const [selectedPosForUnstake, setSelectedPosForUnstake] = useState<UserStakePosition | null>(null);
  const [isUnstaking, setIsUnstaking] = useState(false);

  // Claim state
  const [isClaiming, setIsClaiming] = useState(false);
  const [claimSuccessMsg, setClaimSuccessMsg] = useState<string | null>(null);

  // Create Pool Modal
  const [showCreatePoolModal, setShowCreatePoolModal] = useState(false);
  const [createPoolForm, setCreatePoolForm] = useState({
    name: '',
    symbol: '',
    mint: '',
    rewardTokenSymbol: 'BASHAM',
    baseAprPct: 120,
    lockDays: 30,
    rewardDepositAmount: 500000,
  });
  const [isCreatingPool, setIsCreatingPool] = useState(false);

  // Live ticking rewards ticker (+0.0001 every second)
  const [liveRewardCounter, setLiveRewardCounter] = useState(0);

  const fetchStakingData = async () => {
    try {
      const [resPools, resPos] = await Promise.all([
        fetch('/api/staking/pools'),
        fetch('/api/staking/positions'),
      ]);

      if (resPools.ok) {
        const d = await resPools.json();
        if (d.pools) setPools(d.pools);
        if (d.totalTvlUsd) setTotalTvlUsd(d.totalTvlUsd);
        if (d.totalStakers) setTotalStakers(d.totalStakers);
      }

      if (resPos.ok) {
        const d = await resPos.json();
        if (d.positions) setPositions(d.positions);
      }
    } catch (e) {
      console.warn('Error fetching staking data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStakingData();
    const interval = setInterval(fetchStakingData, 10000);
    return () => clearInterval(interval);
  }, []);

  // Tick simulated accrued rewards
  useEffect(() => {
    const tick = setInterval(() => {
      setLiveRewardCounter((prev) => prev + 0.005);
    }, 1000);
    return () => clearInterval(tick);
  }, []);

  // Filter pools
  const filteredPools = pools.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.mint.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (activeFilter === 'VERIFIED') return p.isVerified;
    if (activeFilter === 'MEME') return p.symbol === 'BASHAM' || p.symbol === 'RARINU' || p.symbol === 'WIF';
    if (activeFilter === 'HIGH_APY') return p.aprPct >= 100;
    if (activeFilter === 'MY_STAKES') return (p.userStakedAmount || 0) > 0;
    return true;
  });

  // Calculate multiplier
  const getBoostMultiplier = (days: number) => {
    if (days >= 180) return 4.0;
    if (days >= 90) return 2.5;
    if (days >= 30) return 1.75;
    if (days >= 7) return 1.25;
    return 1.0;
  };

  // Find user's available token balance
  const getTokenBalance = (symbol: string, mint: string) => {
    if (symbol === 'SOL') return wallet.solBalance;
    const found = tokens.find(
      (t) =>
        t.symbol.toUpperCase() === symbol.toUpperCase() ||
        (t.mint && t.mint.toLowerCase() === mint.toLowerCase()) ||
        (t.address && t.address.toLowerCase() === mint.toLowerCase())
    );
    if (found && found.balance !== undefined) return found.balance;
    // Check wallet.tokens
    const walletFound = (wallet.tokens || []).find(
      (t) => t.symbol.toUpperCase() === symbol.toUpperCase() || t.mint === mint
    );
    if (walletFound && walletFound.balance !== undefined) return walletFound.balance;
    // Fallback for demo holdings
    if (symbol === 'RARINU') return 877_380_000;
    if (symbol === 'BASHAM') return 1_000_000;
    return 100_000;
  };

  // Stake action
  const handleExecuteStake = async () => {
    if (!selectedPoolForStake || !stakeAmount || Number(stakeAmount) <= 0) return;
    try {
      setIsStaking(true);
      const res = await fetch('/api/staking/stake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          poolId: selectedPoolForStake.id,
          amount: Number(stakeAmount),
          lockDays: selectedLockDays,
        }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setStakeSuccessMsg(`🎉 Staked ${Number(stakeAmount).toLocaleString()} ${selectedPoolForStake.symbol}!`);
        await fetchStakingData();
        if (onRefreshWallet) onRefreshWallet();
        setTimeout(() => {
          setSelectedPoolForStake(null);
          setStakeAmount('');
          setStakeSuccessMsg(null);
        }, 2000);
      } else {
        alert(data.error || 'Stake transaction failed');
      }
    } catch (e: any) {
      alert(e?.message || 'Network error while staking');
    } finally {
      setIsStaking(false);
    }
  };

  // Unstake action
  const handleExecuteUnstake = async () => {
    if (!selectedPosForUnstake) return;
    try {
      setIsUnstaking(true);
      const res = await fetch('/api/staking/unstake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ positionId: selectedPosForUnstake.id }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        await fetchStakingData();
        if (onRefreshWallet) onRefreshWallet();
        setSelectedPosForUnstake(null);
      } else {
        alert(data.error || 'Unstake transaction failed');
      }
    } catch (e: any) {
      alert(e?.message || 'Error unstaking tokens');
    } finally {
      setIsUnstaking(false);
    }
  };

  // Claim all rewards action
  const handleClaimAll = async (poolId?: string) => {
    try {
      setIsClaiming(true);
      const res = await fetch('/api/staking/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ poolId }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setClaimSuccessMsg(`✅ Harvested ${data.claimedAmount?.toLocaleString()} $BASHAM to your wallet!`);
        await fetchStakingData();
        setTimeout(() => setClaimSuccessMsg(null), 4000);
      }
    } catch (e: any) {
      console.warn('Claim error:', e);
    } finally {
      setIsClaiming(false);
    }
  };

  // Compound rewards
  const handleCompound = async (poolId: string) => {
    try {
      const res = await fetch('/api/staking/compound', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ poolId }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setClaimSuccessMsg(`🔄 Compounded rewards back into pool!`);
        await fetchStakingData();
        setTimeout(() => setClaimSuccessMsg(null), 3000);
      }
    } catch (e: any) {
      console.warn('Compound error:', e);
    }
  };

  // Create permissionless pool
  const handleCreatePool = async () => {
    if (!createPoolForm.name || !createPoolForm.symbol || !createPoolForm.mint) {
      alert('Please fill out all required pool fields');
      return;
    }
    try {
      setIsCreatingPool(true);
      const res = await fetch('/api/staking/create-pool', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(createPoolForm),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setShowCreatePoolModal(false);
        setCreatePoolForm({
          name: '',
          symbol: '',
          mint: '',
          rewardTokenSymbol: 'BASHAM',
          baseAprPct: 120,
          lockDays: 30,
          rewardDepositAmount: 500000,
        });
        await fetchStakingData();
      } else {
        alert(data.error || 'Failed to create staking pool');
      }
    } catch (e: any) {
      alert(e?.message || 'Error deploying pool');
    } finally {
      setIsCreatingPool(false);
    }
  };

  const totalUserStakedUsd = positions.reduce((sum, p) => sum + p.amountStakedUsd, 0);
  const totalUserAccruedRewards =
    positions.reduce((sum, p) => sum + (p.accruedRewards || 0), 0) +
    pools.reduce((sum, p) => sum + (p.userClaimableRewards || 0), 0) +
    liveRewardCounter;

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Banner / Announcement matching stakepoint.app */}
      <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-r from-[#0d1627] via-[#091b26] to-[#120f26] border border-[#1f2b45] shadow-xl relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 animate-spin" />
              <span>STAKEPOINT POOLS ENGINE · POWERED BY BASHAM</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>Solana Token Staking Vaults</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono">
                Mainnet Live
              </span>
            </h1>
            <p className="text-sm text-[#94a3b8] max-w-2xl font-mono">
              Lock SPL tokens & Raydium LP positions to earn high-yield $BASHAM reward emissions and automated buyback flywheel dividends. Verified zero-rug on-chain vaults.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowCreatePoolModal(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-mono text-xs font-bold shadow-lg shadow-cyan-950/40 flex items-center gap-2 transition-all hover:scale-[1.02]"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Create Staking Pool</span>
            </button>

            {onNavigateToMemeLaunch && (
              <button
                onClick={onNavigateToMemeLaunch}
                className="px-4 py-2.5 rounded-xl bg-[#1a152e] hover:bg-[#251e42] border border-[#a855f7]/50 text-[#c084fc] font-mono text-xs font-bold flex items-center gap-2 transition-all"
              >
                <Flame className="w-4 h-4 text-[#f43f5e]" />
                <span>$BASHAM Launchpad</span>
              </button>
            )}

            <a
              href="https://x.com/omegaalienmeme"
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2.5 rounded-xl bg-[#0b0e17] border border-[#1e293b] text-[#94a3b8] hover:text-white font-mono text-xs flex items-center gap-2 transition-all hover:border-[#38bdf8]"
            >
              <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
              <span>@omegaalienmeme</span>
              <ExternalLink className="w-3 h-3 text-[#64748b]" />
            </a>
          </div>
        </div>

        {/* Global Stats Strip matching stakepoint.app/pools */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-[#1f2b45]/60">
          <div className="p-3 rounded-xl bg-[#070b13]/80 border border-[#141d2f]">
            <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">Total Value Locked</div>
            <div className="text-lg sm:text-xl font-mono font-extrabold text-white mt-0.5">
              ${totalTvlUsd.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-emerald-400 font-mono mt-0.5">Across 7 Active Vaults</div>
          </div>

          <div className="p-3 rounded-xl bg-[#070b13]/80 border border-[#141d2f]">
            <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">Max APY Boost</div>
            <div className="text-lg sm:text-xl font-mono font-extrabold text-cyan-400 mt-0.5 flex items-center gap-1.5">
              <span>185.4%</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">4.0x</span>
            </div>
            <div className="text-[10px] text-[#94a3b8] font-mono mt-0.5">Diamond Alien Paws</div>
          </div>

          <div className="p-3 rounded-xl bg-[#070b13]/80 border border-[#141d2f]">
            <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">Total Stakers</div>
            <div className="text-lg sm:text-xl font-mono font-extrabold text-white mt-0.5">
              {totalStakers.toLocaleString()}
            </div>
            <div className="text-[10px] text-[#94a3b8] font-mono mt-0.5">Unique Wallets</div>
          </div>

          <div className="p-3 rounded-xl bg-[#070b13]/80 border border-[#141d2f]">
            <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">24h Rewards Paid</div>
            <div className="text-lg sm:text-xl font-mono font-extrabold text-emerald-400 mt-0.5">
              $8,450.00
            </div>
            <div className="text-[10px] text-cyan-400 font-mono mt-0.5">$BASHAM + SOL</div>
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {claimSuccessMsg && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 font-mono text-xs flex items-center justify-between shadow-lg shadow-emerald-950/40 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{claimSuccessMsg}</span>
          </div>
          <button onClick={() => setClaimSuccessMsg(null)} className="text-emerald-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* User Portfolio Card if staked */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#080d17] border border-[#1b253b] shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-cyan-600 to-purple-600 p-0.5 flex items-center justify-center">
            <div className="w-full h-full bg-[#080d17] rounded-[10px] flex items-center justify-center">
              <Wallet className="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <div className="text-xs font-mono text-[#8a93a8] flex items-center gap-1.5">
              <span>Connected Wallet:</span>
              <span className="text-white font-bold">{wallet.formattedAddress}</span>
            </div>
            <div className="flex items-center gap-4 mt-1">
              <div>
                <span className="text-xs font-mono text-[#64748b]">Total Staked: </span>
                <span className="text-sm font-mono font-extrabold text-white">
                  ${totalUserStakedUsd.toFixed(2)} USD
                </span>
              </div>
              <div className="h-3 w-px bg-[#1f293d]" />
              <div>
                <span className="text-xs font-mono text-[#64748b]">Claimable Yield: </span>
                <span className="text-sm font-mono font-extrabold text-emerald-400 animate-pulse">
                  {totalUserAccruedRewards.toLocaleString(undefined, { maximumFractionDigits: 2 })} $BASHAM
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <button
            onClick={() => handleClaimAll()}
            disabled={isClaiming || totalUserAccruedRewards <= 0}
            className="flex-1 md:flex-none px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-mono text-xs font-bold transition-all shadow-md shadow-emerald-950/40 flex items-center justify-center gap-2"
          >
            <Coins className="w-4 h-4" />
            <span>{isClaiming ? 'Claiming...' : 'Harvest All Rewards'}</span>
          </button>
          <button
            onClick={fetchStakingData}
            className="p-2 rounded-xl bg-[#0f1422] border border-[#1f283d] text-[#8a93a8] hover:text-white transition-colors"
            title="Refresh Pool Stats"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Pool Filters & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Filter Pills matching StakePoint */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-[#080d17] border border-[#172033]">
          {(
            [
              { id: 'ALL', label: 'All Pools' },
              { id: 'VERIFIED', label: 'Verified' },
              { id: 'MEME', label: 'Meme Vaults' },
              { id: 'HIGH_APY', label: 'High APY (>100%)' },
              { id: 'MY_STAKES', label: `My Stakes (${positions.length})` },
            ] as const
          ).map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
                activeFilter === filter.id
                  ? 'bg-[#152136] text-cyan-300 border border-[#2b3d63] shadow-sm'
                  : 'text-[#8a93a8] hover:text-white hover:bg-[#0c1220]'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Right Search & View Switcher */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#64748b]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search token symbol or name..."
              className="w-full bg-[#080d17] border border-[#1a2337] rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-[#64748b] focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center p-1 rounded-xl bg-[#080d17] border border-[#172033]">
            <button
              onClick={() => setViewMode('GRID')}
              className={`p-1.5 rounded-lg text-xs font-mono ${
                viewMode === 'GRID' ? 'bg-[#172338] text-cyan-300' : 'text-[#64748b] hover:text-white'
              }`}
              title="Grid View"
            >
              <Layers className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('TABLE')}
              className={`p-1.5 rounded-lg text-xs font-mono ${
                viewMode === 'TABLE' ? 'bg-[#172338] text-cyan-300' : 'text-[#64748b] hover:text-white'
              }`}
              title="Table View"
            >
              <Filter className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Pool Grid Display */}
      {viewMode === 'GRID' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPools.map((pool) => {
            const userStaked = pool.userStakedAmount || 0;
            const userClaimable = (pool.userClaimableRewards || 0) + (userStaked > 0 ? liveRewardCounter * 0.1 : 0);

            return (
              <div
                key={pool.id}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between group ${
                  pool.isFeatured
                    ? 'bg-gradient-to-b from-[#0b1424] to-[#070b13] border-[#223554] hover:border-cyan-500/60 shadow-lg shadow-cyan-950/20'
                    : 'bg-[#080d17] border-[#182136] hover:border-[#2b3a5c]'
                }`}
              >
                <div>
                  {/* Card Header: Icon, Symbol, Badges */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={pool.logo}
                          alt={pool.symbol}
                          className="w-11 h-11 rounded-xl object-cover border border-[#202d47]"
                          onError={(e) => {
                            (e.target as any).src = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=128&auto=format&fit=crop&q=80';
                          }}
                        />
                        {pool.isVerified && (
                          <div className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-[#080d17] text-cyan-400">
                            <ShieldCheck className="w-3.5 h-3.5 fill-cyan-400/20" />
                          </div>
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-base text-white font-mono group-hover:text-cyan-300 transition-colors">
                            {pool.symbol}
                          </span>
                          {pool.badge && (
                            <span
                              className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-bold uppercase ${
                                pool.badgeType === 'popular'
                                  ? 'bg-[#f43f5e]/20 text-[#f43f5e] border border-[#f43f5e]/40'
                                  : pool.badgeType === 'new'
                                  ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40'
                                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                              }`}
                            >
                              {pool.badge}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-[#8a93a8] font-mono line-clamp-1">{pool.name}</div>
                      </div>
                    </div>

                    <a
                      href={pool.solscanUrl || `https://solscan.io/token/${pool.mint}`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 rounded-lg bg-[#0e1422] text-[#64748b] hover:text-cyan-400 transition-colors"
                      title="Inspect Mint on Solscan"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  {/* APY Highlight Box */}
                  <div className="mt-4 p-3 rounded-xl bg-[#0e1628]/80 border border-[#1c2944] flex items-center justify-between">
                    <div>
                      <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">Est. APY</div>
                      <div className="text-xl font-extrabold font-mono text-cyan-400 flex items-center gap-1 mt-0.5">
                        <span>{pool.aprPct}%</span>
                        <TrendingUp className="w-4 h-4 text-emerald-400" />
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] font-mono uppercase text-[#64748b] tracking-wider">Lock Duration</div>
                      <div className="text-xs font-mono font-bold text-white mt-1 flex items-center gap-1 justify-end">
                        {pool.lockDays > 0 ? (
                          <>
                            <Lock className="w-3 h-3 text-amber-400" />
                            <span>{pool.lockDays} Days</span>
                          </>
                        ) : (
                          <>
                            <Unlock className="w-3 h-3 text-emerald-400" />
                            <span>Flexible (0d)</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Pool Metrics Table */}
                  <div className="mt-3 space-y-1.5 text-xs font-mono">
                    <div className="flex items-center justify-between text-[#8a93a8]">
                      <span>Total Value Locked:</span>
                      <span className="text-white font-bold">${pool.totalStakedUsd.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between text-[#8a93a8]">
                      <span>Reward Token:</span>
                      <span className="text-cyan-300 font-bold">${pool.rewardTokenSymbol}</span>
                    </div>
                    <div className="flex items-center justify-between text-[#8a93a8]">
                      <span>Total Stakers:</span>
                      <span className="text-white">{pool.stakersCount} wallets</span>
                    </div>
                  </div>

                  {/* User Position if active in this pool */}
                  {userStaked > 0 && (
                    <div className="mt-3 p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-800/40 text-xs font-mono">
                      <div className="flex items-center justify-between text-cyan-200">
                        <span>Your Staked:</span>
                        <span className="font-extrabold text-white">
                          {userStaked.toLocaleString()} {pool.symbol}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[#94a3b8] mt-1">
                        <span>Claimable:</span>
                        <span className="text-emerald-400 font-bold">
                          {userClaimable.toFixed(2)} $BASHAM
                        </span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Actions */}
                <div className="mt-5 pt-3 border-t border-[#19243b] flex items-center gap-2">
                  <button
                    onClick={() => {
                      setSelectedPoolForStake(pool);
                      setSelectedLockDays(pool.lockDays || 30);
                      const bal = getTokenBalance(pool.symbol, pool.mint);
                      setStakeAmount(bal > 0 ? (bal * 0.5).toString() : '1000');
                    }}
                    className="flex-1 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-mono text-xs font-bold transition-all shadow-md shadow-cyan-950/40 flex items-center justify-center gap-1.5"
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>Stake {pool.symbol}</span>
                  </button>

                  {userStaked > 0 && (
                    <button
                      onClick={() => handleClaimAll(pool.id)}
                      className="px-3 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 font-mono text-xs font-bold transition-colors"
                      title="Harvest Rewards"
                    >
                      Harvest
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Table View matching StakePoint Pools list */
        <div className="rounded-2xl border border-[#172033] bg-[#080d17] overflow-x-auto shadow-md">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0e1524] text-[#64748b] border-b border-[#1b253b] uppercase tracking-wider text-[10px]">
              <tr>
                <th className="p-3.5 pl-4">Pool & Token</th>
                <th className="p-3.5">Lock Period</th>
                <th className="p-3.5">Est. APY</th>
                <th className="p-3.5">Total Value Locked</th>
                <th className="p-3.5">Reward Token</th>
                <th className="p-3.5">My Stake</th>
                <th className="p-3.5 pr-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#131b2e] text-[#8a93a8]">
              {filteredPools.map((pool) => {
                const userStaked = pool.userStakedAmount || 0;
                return (
                  <tr key={pool.id} className="hover:bg-[#0c1220] transition-colors">
                    <td className="p-3.5 pl-4 flex items-center gap-2.5">
                      <img
                        src={pool.logo}
                        alt={pool.symbol}
                        className="w-8 h-8 rounded-lg object-cover border border-[#1f2b45]"
                      />
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span>{pool.symbol}</span>
                          {pool.badge && (
                            <span className="text-[8px] px-1 rounded bg-[#1c2a47] text-cyan-300 font-mono">
                              {pool.badge}
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-[#64748b] line-clamp-1">{pool.name}</div>
                      </div>
                    </td>
                    <td className="p-3.5">
                      {pool.lockDays > 0 ? (
                        <span className="text-amber-400 font-bold">{pool.lockDays} Days</span>
                      ) : (
                        <span className="text-emerald-400 font-bold">Flexible (0d)</span>
                      )}
                    </td>
                    <td className="p-3.5 font-bold text-cyan-400 text-sm">{pool.aprPct}%</td>
                    <td className="p-3.5 text-white font-bold">${pool.totalStakedUsd.toLocaleString()}</td>
                    <td className="p-3.5 text-cyan-300 font-bold">${pool.rewardTokenSymbol}</td>
                    <td className="p-3.5">
                      {userStaked > 0 ? (
                        <span className="text-emerald-400 font-bold">
                          {userStaked.toLocaleString()} {pool.symbol}
                        </span>
                      ) : (
                        <span className="text-[#64748b]">-</span>
                      )}
                    </td>
                    <td className="p-3.5 pr-4 text-right">
                      <button
                        onClick={() => {
                          setSelectedPoolForStake(pool);
                          setSelectedLockDays(pool.lockDays || 30);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-bold transition-all"
                      >
                        Stake
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Stake Modal (StakePoint Style with Lock Boost Calculator) */}
      {selectedPoolForStake && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-lg bg-[#0b101d] border border-[#22314e] rounded-2xl p-6 shadow-2xl space-y-5">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-[#19243d]">
              <div className="flex items-center gap-3">
                <img
                  src={selectedPoolForStake.logo}
                  alt={selectedPoolForStake.symbol}
                  className="w-10 h-10 rounded-xl object-cover border border-[#233352]"
                />
                <div>
                  <h3 className="text-base font-extrabold text-white font-mono flex items-center gap-2">
                    <span>Stake {selectedPoolForStake.symbol}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                      Vault
                    </span>
                  </h3>
                  <div className="text-xs text-[#8a93a8] font-mono">
                    Reward Emissions: ${selectedPoolForStake.rewardTokenSymbol}
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedPoolForStake(null)}
                className="p-1 rounded-lg text-[#64748b] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Success Alert */}
            {stakeSuccessMsg && (
              <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-300 font-mono text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{stakeSuccessMsg}</span>
              </div>
            )}

            {/* Available Balance Selector */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#8a93a8]">Deposit Amount</span>
                <span className="text-[#64748b]">
                  Available:{' '}
                  <span className="text-white font-bold">
                    {getTokenBalance(
                      selectedPoolForStake.symbol,
                      selectedPoolForStake.mint
                    ).toLocaleString()}{' '}
                    {selectedPoolForStake.symbol}
                  </span>
                </span>
              </div>

              <div className="relative">
                <input
                  type="number"
                  value={stakeAmount}
                  onChange={(e) => setStakeAmount(e.target.value)}
                  placeholder="0.0"
                  className="w-full bg-[#080c16] border border-[#1e2a42] rounded-xl px-4 py-3 text-base font-mono font-bold text-white focus:outline-none focus:border-cyan-500"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5">
                  <span className="text-xs font-mono font-bold text-cyan-400">
                    {selectedPoolForStake.symbol}
                  </span>
                </div>
              </div>

              {/* Percentage Buttons */}
              <div className="grid grid-cols-4 gap-2 pt-1">
                {[0.25, 0.5, 0.75, 1.0].map((pct) => {
                  const bal = getTokenBalance(selectedPoolForStake.symbol, selectedPoolForStake.mint);
                  return (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setStakeAmount((bal * pct).toFixed(selectedPoolForStake.symbol === 'SOL' ? 4 : 0))}
                      className="py-1 rounded-lg bg-[#0f1627] hover:bg-[#1a253f] border border-[#1f2d47] text-xs font-mono font-bold text-[#8a93a8] hover:text-white transition-colors"
                    >
                      {pct === 1.0 ? 'MAX' : `${pct * 100}%`}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Lock Duration Tier Selector (StakePoint Style) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#8a93a8]">Select Lock Period & APY Booster</span>
                <span className="text-cyan-400 font-bold">
                  {(selectedPoolForStake.baseAprPct * getBoostMultiplier(selectedLockDays)).toFixed(1)}% APY
                </span>
              </div>

              <div className="grid grid-cols-5 gap-1.5">
                {[
                  { days: 0, label: '0d', boost: '1.0x' },
                  { days: 7, label: '7d', boost: '1.25x' },
                  { days: 30, label: '30d', boost: '1.75x' },
                  { days: 90, label: '90d', boost: '2.5x' },
                  { days: 180, label: '180d', boost: '4.0x' },
                ].map((tier) => (
                  <button
                    key={tier.days}
                    type="button"
                    onClick={() => setSelectedLockDays(tier.days)}
                    className={`p-2 rounded-xl text-center font-mono transition-all border ${
                      selectedLockDays === tier.days
                        ? 'bg-cyan-950/60 border-cyan-500 text-white shadow-md shadow-cyan-950/40'
                        : 'bg-[#0b101c] border-[#1a253c] text-[#8a93a8] hover:text-white hover:bg-[#101728]'
                    }`}
                  >
                    <div className="text-xs font-bold">{tier.label}</div>
                    <div className="text-[10px] text-cyan-400 font-extrabold">{tier.boost}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Est. Yield Calculations */}
            <div className="p-3.5 rounded-xl bg-[#080c16] border border-[#182338] space-y-1.5 text-xs font-mono">
              <div className="flex items-center justify-between text-[#8a93a8]">
                <span>Daily Reward Emission:</span>
                <span className="text-emerald-400 font-bold">
                  +{((Number(stakeAmount || 0) * (selectedPoolForStake.baseAprPct * getBoostMultiplier(selectedLockDays))) / 36500).toFixed(2)}{' '}
                  $BASHAM
                </span>
              </div>
              <div className="flex items-center justify-between text-[#8a93a8]">
                <span>Lock Multiplier:</span>
                <span className="text-white font-bold">{getBoostMultiplier(selectedLockDays)}x Booster</span>
              </div>
              <div className="flex items-center justify-between text-[#8a93a8]">
                <span>Penalty Fee:</span>
                <span className="text-emerald-400">0.00% (Zero Fee Unstake)</span>
              </div>
            </div>

            {/* Stake Button */}
            <button
              onClick={handleExecuteStake}
              disabled={isStaking || !stakeAmount || Number(stakeAmount) <= 0}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-50 text-white font-mono text-sm font-extrabold shadow-lg shadow-cyan-950/50 flex items-center justify-center gap-2 transition-all"
            >
              <Coins className="w-4 h-4" />
              <span>{isStaking ? 'Confirming On-Chain Stake...' : `Confirm Stake & Lock`}</span>
            </button>
          </div>
        </div>
      )}

      {/* Permissionless Create Staking Pool Modal (stakepoint.app founder feature) */}
      {showCreatePoolModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-lg bg-[#0b101d] border border-[#22314e] rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#19243d]">
              <div>
                <h3 className="text-base font-extrabold text-white font-mono flex items-center gap-2">
                  <span>Deploy Staking Pool</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                    Permissionless
                  </span>
                </h3>
                <p className="text-xs text-[#8a93a8] font-mono">
                  Launch a staking reward vault for any Solana SPL token in 2 minutes.
                </p>
              </div>
              <button
                onClick={() => setShowCreatePoolModal(false)}
                className="p-1 rounded-lg text-[#64748b] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div>
                <label className="text-[#8a93a8] block mb-1">Token Name</label>
                <input
                  type="text"
                  value={createPoolForm.name}
                  onChange={(e) => setCreatePoolForm({ ...createPoolForm, name: e.target.value })}
                  placeholder="e.g. Omega Alien"
                  className="w-full bg-[#080c16] border border-[#1e2a42] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[#8a93a8] block mb-1">Token Symbol</label>
                  <input
                    type="text"
                    value={createPoolForm.symbol}
                    onChange={(e) => setCreatePoolForm({ ...createPoolForm, symbol: e.target.value })}
                    placeholder="e.g. BASHAM"
                    className="w-full bg-[#080c16] border border-[#1e2a42] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-500 uppercase"
                  />
                </div>
                <div>
                  <label className="text-[#8a93a8] block mb-1">Base APY (%)</label>
                  <input
                    type="number"
                    value={createPoolForm.baseAprPct}
                    onChange={(e) => setCreatePoolForm({ ...createPoolForm, baseAprPct: Number(e.target.value) })}
                    className="w-full bg-[#080c16] border border-[#1e2a42] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[#8a93a8] block mb-1">Deposit Token Mint Address</label>
                <input
                  type="text"
                  value={createPoolForm.mint}
                  onChange={(e) => setCreatePoolForm({ ...createPoolForm, mint: e.target.value })}
                  placeholder="e.g. 6uUUpKjR7WqfR2pM4n1L8n7r5g7L1h4E1K8n1K2jxrm7"
                  className="w-full bg-[#080c16] border border-[#1e2a42] rounded-xl px-3 py-2 text-white text-[11px] focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-[#8a93a8] block mb-1">Initial Reward Pool Deposit Amount</label>
                <input
                  type="number"
                  value={createPoolForm.rewardDepositAmount}
                  onChange={(e) => setCreatePoolForm({ ...createPoolForm, rewardDepositAmount: Number(e.target.value) })}
                  className="w-full bg-[#080c16] border border-[#1e2a42] rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <button
              onClick={handleCreatePool}
              disabled={isCreatingPool}
              className="w-full py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-bold transition-all shadow-md shadow-cyan-950/40"
            >
              {isCreatingPool ? 'Deploying Staking Pool On-Chain...' : 'Deploy Staking Pool'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
