import React from 'react';

// High fidelity vector graphics and metadata for BLANK NETWORK MEME COIN ($BLANK)

export const BLANK_TOKEN_META = {
  name: 'BLANK NETWORK MEME COIN',
  symbol: 'BLANK',
  mint: 'BLANKNetWorkMemeCo1nPuMpSoL11111111111111111',
  decimals: 6,
  supply: 1_000_000_000,
  priceUsd: 0.0001426,
  priceSol: 0.00000096,
  marketCapUsd: 142_600,
  poolId: 'RayBLANKNetWorkMemeCo1nLpPo0l111111111111111',
  website: 'https://blanknetwork.vip',
  twitter: 'https://x.com/BlankNetworkSol',
  telegram: 'https://t.me/BlankNetworkSol',
  description:
    'BLANK NETWORK MEME COIN ($BLANK) - The cutest alpaca on Solana Mainnet-Beta. Autonomous liquidity flywheel, 100% fair launch, anti-MEV protection, and Raydium CPMM automated market maker.',
};

// SVG illustration of the cute BLANK Network Alpaca Mascot with Gold Chain and Coin
export const BlankAlpacaSvg = ({ className = 'w-10 h-10' }: { className?: string }) => (
  <svg
    viewBox="0 0 160 160"
    className={className}
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    {/* Background Glow */}
    <circle cx="80" cy="80" r="76" fill="#0d1424" stroke="#ffd60a" strokeWidth="3" />
    <circle cx="80" cy="80" r="70" fill="url(#blankGlow)" opacity="0.3" />

    {/* Sparkles */}
    <path d="M25 40L28 47L35 50L28 53L25 60L22 53L15 50L22 47Z" fill="#ffd60a" />
    <path d="M135 30L137 35L142 37L137 39L135 44L133 39L128 37L133 35Z" fill="#ffd60a" />
    <path d="M140 120L142 124L146 126L142 128L140 132L138 128L134 126L138 124Z" fill="#ffd60a" />

    {/* Alpaca Fluffy Head & Ears */}
    {/* Left Ear */}
    <ellipse cx="46" cy="52" rx="10" ry="20" fill="#FFF9F0" stroke="#1b2234" strokeWidth="2.5" transform="rotate(-20 46 52)" />
    <ellipse cx="46" cy="53" rx="5" ry="12" fill="#FFB6C1" transform="rotate(-20 46 53)" />

    {/* Right Ear */}
    <ellipse cx="114" cy="52" rx="10" ry="20" fill="#FFF9F0" stroke="#1b2234" strokeWidth="2.5" transform="rotate(20 114 52)" />
    <ellipse cx="114" cy="53" rx="5" ry="12" fill="#FFB6C1" transform="rotate(20 114 53)" />

    {/* Fluffy Head Cloud Tufts */}
    <circle cx="60" cy="52" r="14" fill="#FFF9F0" />
    <circle cx="80" cy="46" r="16" fill="#FFF9F0" />
    <circle cx="100" cy="52" r="14" fill="#FFF9F0" />

    {/* Alpaca Face */}
    <ellipse cx="80" cy="80" rx="36" ry="32" fill="#FFF9F0" stroke="#1b2234" strokeWidth="2.5" />

    {/* Big Anime Eyes */}
    <ellipse cx="65" cy="74" rx="7" ry="9" fill="#1b2234" />
    <circle cx="63" cy="71" r="3" fill="#FFFFFF" />
    <circle cx="67" cy="78" r="1.5" fill="#FFFFFF" />

    <ellipse cx="95" cy="74" rx="7" ry="9" fill="#1b2234" />
    <circle cx="93" cy="71" r="3" fill="#FFFFFF" />
    <circle cx="97" cy="78" r="1.5" fill="#FFFFFF" />

    {/* Cute Eyelashes */}
    <path d="M57 68L53 66" stroke="#1b2234" strokeWidth="2" strokeLinecap="round" />
    <path d="M103 68L107 66" stroke="#1b2234" strokeWidth="2" strokeLinecap="round" />

    {/* Pink Blush Cheeks */}
    <ellipse cx="55" cy="86" rx="6" ry="4" fill="#FF9EAA" opacity="0.8" />
    <ellipse cx="105" cy="86" rx="6" ry="4" fill="#FF9EAA" opacity="0.8" />

    {/* Snout & Smiling Mouth */}
    <ellipse cx="80" cy="88" rx="13" ry="10" fill="#FFF0E0" stroke="#1b2234" strokeWidth="2" />
    <path d="M77 84C77 82 83 82 83 84L80 87Z" fill="#1b2234" />
    <path d="M80 87V92" stroke="#1b2234" strokeWidth="2" strokeLinecap="round" />
    <path d="M75 92C78 95 82 95 85 92" stroke="#1b2234" strokeWidth="2" strokeLinecap="round" fill="#E63946" />

    {/* Fluffy Body */}
    <ellipse cx="80" cy="126" rx="32" ry="24" fill="#FFF9F0" stroke="#1b2234" strokeWidth="2.5" />

    {/* Gold Cuban Chain Necklace */}
    <path
      d="M58 106C68 116 92 116 102 106"
      stroke="#F59E0B"
      strokeWidth="6"
      strokeLinecap="round"
      strokeDasharray="4 3"
    />
    <path
      d="M58 106C68 116 92 116 102 106"
      stroke="#FCD34D"
      strokeWidth="3"
      strokeLinecap="round"
    />

    {/* Golden Alpaca Medallion */}
    <circle cx="80" cy="120" r="13" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
    <circle cx="80" cy="120" r="10" fill="#FCD34D" />
    {/* Cute face in medallion */}
    <circle cx="77" cy="119" r="1.5" fill="#78350F" />
    <circle cx="83" cy="119" r="1.5" fill="#78350F" />
    <path d="M78 122C79 123.5 81 123.5 82 122" stroke="#78350F" strokeWidth="1.2" strokeLinecap="round" />

    {/* Floating Gold Coin with rays */}
    <circle cx="128" cy="85" r="14" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
    <circle cx="128" cy="85" r="11" fill="#FCD34D" />
    <circle cx="125" cy="84" r="1.2" fill="#78350F" />
    <circle cx="131" cy="84" r="1.2" fill="#78350F" />
    <path d="M126 87C127 88.5 129 88.5 130 87" stroke="#78350F" strokeWidth="1" strokeLinecap="round" />

    {/* Gradients */}
    <defs>
      <radialGradient id="blankGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#ffd60a" stopOpacity="0.8" />
        <stop offset="100%" stopColor="#07090f" stopOpacity="0" />
      </radialGradient>
    </defs>
  </svg>
);
