import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Keypair, PublicKey } from '@solana/web3.js';
import {
  AlertCircle,
  CheckCircle2,
  Coins,
  ExternalLink,
  Flame,
  Lock,
  Pause,
  Play,
  RefreshCw,
  Rocket,
  Settings,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import * as L from '../../lib/launchpad/client';
import { connectWallet, explorerUrl, signAndRelay } from '../../lib/launchpad/wallet';

/**
 * Live launchpad on the meme_pump_engine program.
 * Every number comes from the chain (via /api/launchpad/state), every action is a transaction
 * the connected wallet signs. Nothing here is simulated.
 */

type Tab = 'tokens' | 'launch' | 'platform';
type Notice = { type: 'ok' | 'err'; text: string; sig?: string } | null;

interface LaunchItem {
  index: string;
  mint: string;
  creator: string;
  createdAt: string;
  name: string;
  symbol: string;
  uri: string;
  image: string | null;
  description: string | null;
  curve: Record<string, any> | null;
}

interface LpState {
  ok: boolean;
  error?: string;
  cluster: string;
  programId: string;
  fetchedAt: number;
  status: 'NOT_DEPLOYED' | 'NOT_INITIALIZED' | 'LIVE';
  upgradeAuthority: string | null;
  global: Record<string, any> | null;
  launches: LaunchItem[];
  totals: Record<string, any> | null;
}

// ---------- parsing & formatting ----------

const B = (v: unknown) => BigInt((v as any) ?? 0);

function toCurve(c: Record<string, any>): L.CurveAccount {
  return {
    mint: c.mint,
    creator: c.creator,
    launchIndex: B(c.launchIndex),
    createdAt: B(c.createdAt),
    virtualSolReserves: B(c.virtualSolReserves),
    virtualTokenReserves: B(c.virtualTokenReserves),
    realSolReserves: B(c.realSolReserves),
    realTokenReserves: B(c.realTokenReserves),
    initialRealTokenReserves: B(c.initialRealTokenReserves),
    tokenTotalSupply: B(c.tokenTotalSupply),
    volumeLamports: B(c.volumeLamports),
    feesLamports: B(c.feesLamports),
    tradeCount: B(c.tradeCount),
    complete: Boolean(c.complete),
    migrated: Boolean(c.migrated),
    migrationSol: B(c.migrationSol),
    migrationTokens: B(c.migrationTokens),
    migrationPool: c.migrationPool ?? null,
    bump: Number(c.bump),
  };
}

const short = (a?: string | null) => (a ? `${a.slice(0, 4)}…${a.slice(-4)}` : '—');

function fmtSol(lamports: unknown, digits = 4) {
  if (lamports === null || lamports === undefined) return '—';
  const n = Number(B(lamports)) / 1e9;
  if (n === 0) return '0 SOL';
  if (Math.abs(n) < 0.0001) return '<0.0001 SOL';
  return `${n.toLocaleString(undefined, { maximumFractionDigits: digits })} SOL`;
}

function fmtTokens(base: unknown) {
  const n = Number(B(base)) / 10 ** L.TOKEN_DECIMALS;
  if (n >= 1e9) return `${(n / 1e9).toLocaleString(undefined, { maximumFractionDigits: 2 })}B`;
  if (n >= 1e6) return `${(n / 1e6).toLocaleString(undefined, { maximumFractionDigits: 2 })}M`;
  return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

function fmtPrice(sol: number) {
  if (!Number.isFinite(sol) || sol <= 0) return '—';
  return sol < 0.000001 ? `${sol.toExponential(3)} SOL` : `${sol.toLocaleString(undefined, { maximumSignificantDigits: 4 })} SOL`;
}

/** "1.25" -> lamports / base units, or null if not a valid positive amount. */
function parseUnits(s: string, decimals: number): bigint | null {
  const t = s.trim();
  if (!/^\d*\.?\d*$/.test(t) || t === '' || t === '.') return null;
  const [whole, frac = ''] = t.split('.');
  if (frac.length > decimals) return null;
  const v = BigInt(whole || '0') * 10n ** BigInt(decimals) + BigInt((frac + '0'.repeat(decimals)).slice(0, decimals) || '0');
  return v > 0n ? v : null;
}

const utf8Len = (s: string) => new TextEncoder().encode(s).length;

// ---------- small UI pieces ----------

const Card: React.FC<{ className?: string; children: React.ReactNode }> = ({ className = '', children }) => (
  <div className={`rounded-xl border border-[#1b2436] bg-[#090d16] p-5 shadow-xl ${className}`}>{children}</div>
);

const Stat: React.FC<{ label: string; value: React.ReactNode; tone?: string; sub?: string }> = ({ label, value, tone = 'text-white', sub }) => (
  <div className="p-3.5 rounded-xl bg-[#060911] border border-[#162032] min-w-0">
    <div className="text-[10px] uppercase text-[#6b7c96] font-mono">{label}</div>
    <div className={`text-sm font-bold font-mono mt-1 truncate ${tone}`}>{value}</div>
    {sub && <div className="text-[10px] text-[#6b7c96] font-mono mt-0.5 truncate">{sub}</div>}
  </div>
);

const TokenLogo: React.FC<{ src?: string | null; symbol: string; size?: string }> = ({ src, symbol, size = 'w-10 h-10' }) => {
  const [broken, setBroken] = useState(false);
  if (!src || broken) {
    return (
      <div className={`${size} rounded-full bg-[#1b2436] border border-[#232c45] flex items-center justify-center text-xs font-bold text-[#8a93a8] shrink-0`}>
        {(symbol || '?').slice(0, 2).toUpperCase()}
      </div>
    );
  }
  return <img src={src} alt={symbol} onError={() => setBroken(true)} className={`${size} rounded-full object-cover border border-[#232c45] shrink-0`} />;
};

const inputCls =
  'w-full bg-[#060911] border border-[#1b263d] rounded-xl p-2.5 text-white text-sm font-mono focus:outline-none focus:border-cyan-400';
const btnPrimary =
  'px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#0284c7] to-[#0369a1] hover:from-[#38bdf8] hover:to-[#0284c7] text-white text-xs font-mono font-bold flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed';
const btnGhost =
  'px-3 py-2 rounded-lg bg-[#0e1422] border border-[#1b263d] text-[#a3b0c6] hover:text-white text-xs font-mono font-bold flex items-center gap-1.5 disabled:opacity-40';

// ---------- main view ----------

export const LaunchpadView: React.FC = () => {
  const [state, setState] = useState<LpState | null>(null);
  const [config, setConfig] = useState<{ pinataEnabled: boolean } | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [wallet, setWallet] = useState<PublicKey | null>(null);
  const [tab, setTab] = useState<Tab>('tokens');
  const [selectedMint, setSelectedMint] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<Notice>(null);

  const load = useCallback(async (fresh = false) => {
    try {
      const res = await fetch(`/api/launchpad/state${fresh ? '?fresh=1' : ''}`);
      const data = (await res.json()) as LpState;
      if (!data?.ok) throw new Error(data?.error || `HTTP ${res.status}`);
      setState(data);
      setLoadError(null);
    } catch (e: any) {
      setLoadError(e?.message || 'Could not read the launchpad from the chain.');
    }
  }, []);

  useEffect(() => {
    fetch('/api/launchpad/config').then((r) => r.json()).then(setConfig).catch(() => {});
    load();
    connectWallet(true).then((k) => k && setWallet(k)).catch(() => {});
    const timer = setInterval(() => load(), 10_000);
    return () => clearInterval(timer);
  }, [load]);

  const ensureWallet = async () => {
    if (wallet) return wallet;
    const k = await connectWallet();
    if (!k) throw new Error('Wallet did not connect.');
    setWallet(k);
    return k;
  };

  const run = async (label: string, fn: () => Promise<string>) => {
    setBusy(label);
    setNotice(null);
    try {
      const sig = await fn();
      setNotice({ type: 'ok', text: `${label} confirmed on ${state?.cluster ?? 'Solana'}.`, sig });
      await load(true);
    } catch (e: any) {
      setNotice({ type: 'err', text: e?.message || String(e), sig: e?.signature });
    } finally {
      setBusy(null);
    }
  };

  const cluster = state?.cluster ?? 'devnet';
  const g = state?.global ?? null;
  const t = state?.totals ?? null;
  const launches = state?.launches ?? [];
  const selected = launches.find((l) => l.mint === selectedMint) ?? launches[0] ?? null;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono mb-1">
            <span className="font-bold uppercase text-cyan-400">Launchpad · On-chain</span>
            <span className="text-slate-600">·</span>
            <span className={cluster === 'devnet' ? 'text-amber-300' : 'text-emerald-400'}>Solana {cluster}</span>
            <span className="text-slate-600">·</span>
            <a href={explorerUrl('account', state?.programId ?? L.DEFAULT_PROGRAM_ID, cluster)} target="_blank" rel="noreferrer" className="text-[#8a93a8] hover:text-white inline-flex items-center gap-1">
              program {short(state?.programId ?? L.DEFAULT_PROGRAM_ID)} <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Token Launchpad</h1>
          <p className="text-sm text-[#8a93a8] mt-1 max-w-3xl">
            Launch fixed-supply tokens on a bonding curve and trade them with your own wallet. Every trade pays the platform
            fee on-chain{g ? ` (${(Number(g.feeBps) / 100).toLocaleString()}%)` : ''}, and every figure here is read from Solana.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button type="button" onClick={() => load(true)} className={btnGhost}>
            <RefreshCw className="w-3.5 h-3.5" /> Refresh
          </button>
          {wallet ? (
            <span className="px-3 py-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5" /> {short(wallet.toBase58())}
            </span>
          ) : (
            <button type="button" onClick={() => ensureWallet().catch((e) => setNotice({ type: 'err', text: e.message }))} className={btnPrimary}>
              <Wallet className="w-4 h-4" /> Connect wallet
            </button>
          )}
        </div>
      </div>

      {cluster === 'devnet' && (
        <div className="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-200 text-xs font-mono">
          Running on devnet: tokens and SOL here have no value. In Phantom, turn on Settings → Developer Settings → Testnet
          Mode and pick Solana Devnet before signing.
        </div>
      )}
      {loadError && (
        <div className="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs font-mono flex gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" /> {loadError}
        </div>
      )}
      {notice && (
        <div
          className={`p-3 rounded-xl border text-xs font-mono flex items-start gap-2 ${
            notice.type === 'ok' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-rose-500/30 bg-rose-500/10 text-rose-200'
          }`}
        >
          {notice.type === 'ok' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
          <span className="break-all">
            {notice.text}{' '}
            {notice.sig && (
              <a href={explorerUrl('tx', notice.sig, cluster)} target="_blank" rel="noreferrer" className="underline">
                View transaction
              </a>
            )}
          </span>
        </div>
      )}

      {/* Platform totals (all from on-chain counters) */}
      {state?.status === 'LIVE' && t && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <Stat label="Launches" value={String(t.launches)} />
          <Stat label="Platform fees earned" value={fmtSol(t.platformFeesLamports)} tone="text-amber-300" sub="sum of curve fee counters" />
          <Stat label="Fee wallet balance" value={fmtSol(t.feeRecipientBalanceLamports)} sub={short(g?.feeRecipient)} />
          <Stat label="Volume" value={fmtSol(t.volumeLamports, 2)} />
          <Stat label="Trades" value={String(t.trades)} />
          <Stat label="Sold out" value={`${t.soldOut}`} sub={`${t.awaitingMigration} awaiting migration`} />
        </div>
      )}

      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'tokens' as Tab, label: 'Tokens', icon: TrendingUp },
          { id: 'launch' as Tab, label: 'Launch a token', icon: Rocket },
          { id: 'platform' as Tab, label: 'Platform', icon: Settings },
        ].map(({ id, label, icon: Icon }) => (
          <button
            type="button"
            key={id}
            onClick={() => setTab(id)}
            className={`px-3.5 py-2 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 ${
              tab === id ? 'bg-[#0284c7] text-white' : 'bg-[#0e1422] text-[#8a93a8] hover:text-white border border-[#1b263d]'
            }`}
          >
            <Icon className="w-3.5 h-3.5" /> {label}
          </button>
        ))}
      </div>

      {!state && !loadError && <Card><div className="text-xs font-mono text-[#8a93a8]">Reading the program from the chain…</div></Card>}

      {state && state.status !== 'LIVE' && tab !== 'platform' && (
        <Card>
          <div className="text-sm text-white font-bold mb-1">
            {state.status === 'NOT_DEPLOYED' ? `The program isn't deployed on ${cluster} yet` : 'The launchpad needs a one-time setup'}
          </div>
          <p className="text-xs font-mono text-[#8a93a8] leading-relaxed">
            {state.status === 'NOT_DEPLOYED'
              ? `Program ${state.programId} has no code on ${cluster}. Build and deploy it with the steps in DEPLOY.md, then come back here.`
              : 'The program is deployed. Open the Platform tab and initialize it with the wallet that deployed it.'}
          </p>
        </Card>
      )}

      {state?.status === 'LIVE' && tab === 'tokens' && (
        <TokensTab
          state={state}
          selected={selected}
          onSelect={setSelectedMint}
          wallet={wallet}
          busy={busy}
          ensureWallet={ensureWallet}
          run={run}
        />
      )}
      {state?.status === 'LIVE' && tab === 'launch' && (
        <LaunchTab
          state={state}
          pinataEnabled={Boolean(config?.pinataEnabled)}
          busy={busy}
          ensureWallet={ensureWallet}
          run={run}
          onLaunched={(mint) => {
            setSelectedMint(mint);
            setTab('tokens');
          }}
        />
      )}
      {state && tab === 'platform' && <PlatformTab state={state} wallet={wallet} busy={busy} ensureWallet={ensureWallet} run={run} />}
    </div>
  );
};

// ---------- Tokens + trading ----------

interface TabProps {
  state: LpState;
  busy: string | null;
  ensureWallet: () => Promise<PublicKey>;
  run: (label: string, fn: () => Promise<string>) => Promise<void>;
}

const TokensTab: React.FC<
  TabProps & { selected: LaunchItem | null; onSelect: (mint: string) => void; wallet: PublicKey | null }
> = ({ state, selected, onSelect, wallet, busy, ensureWallet, run }) => {
  if (state.launches.length === 0) {
    return (
      <Card>
        <div className="text-sm text-white font-bold">No tokens launched yet</div>
        <p className="text-xs font-mono text-[#8a93a8] mt-1">The first launch will appear here as soon as it confirms on-chain.</p>
      </Card>
    );
  }
  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-2 max-h-[720px] overflow-y-auto pr-1">
        {state.launches.map((l) => {
          const c = l.curve ? toCurve(l.curve) : null;
          const pct = c ? L.progressPct(c) : 0;
          const active = selected?.mint === l.mint;
          return (
            <button
              type="button"
              key={l.mint}
              onClick={() => onSelect(l.mint)}
              className={`w-full text-left p-3 rounded-xl border transition-all ${
                active ? 'border-amber-400 bg-[#10192b]' : 'border-[#1b2436] bg-[#090d16] hover:border-[#2a3a55]'
              }`}
            >
              <div className="flex items-center gap-3">
                <TokenLogo src={l.image} symbol={l.symbol} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white truncate">{l.name || short(l.mint)}</span>
                    <span className="text-[11px] font-mono text-cyan-300">${l.symbol}</span>
                  </div>
                  <div className="text-[11px] font-mono text-[#6b7c96]">
                    {c ? `${fmtSol(c.migrated ? c.migrationSol : c.realSolReserves, 3)} raised · ${c.tradeCount} trades` : 'curve unreadable'}
                  </div>
                </div>
                <span
                  className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                    !c ? 'border-slate-600 text-slate-400' : c.migrated ? 'border-cyan-500/40 text-cyan-300' : c.complete ? 'border-amber-500/40 text-amber-300' : 'border-emerald-500/40 text-emerald-300'
                  }`}
                >
                  {!c ? '?' : c.migrated ? 'MIGRATED' : c.complete ? 'SOLD OUT' : 'LIVE'}
                </span>
              </div>
              <div className="mt-2 h-1.5 rounded-full bg-[#162032] overflow-hidden">
                <div className="h-full bg-gradient-to-r from-emerald-500 to-amber-400" style={{ width: `${pct}%` }} />
              </div>
              <div className="text-[10px] font-mono text-[#6b7c96] mt-1">{pct.toFixed(2)}% of the sale supply sold</div>
            </button>
          );
        })}
      </div>
      <div className="lg:col-span-3">
        {selected && <TradePanel key={selected.mint} state={state} item={selected} wallet={wallet} busy={busy} ensureWallet={ensureWallet} run={run} />}
      </div>
    </div>
  );
};

const TradePanel: React.FC<TabProps & { item: LaunchItem; wallet: PublicKey | null }> = ({ state, item, wallet, busy, ensureWallet, run }) => {
  const g = state.global!;
  const feeBps = Number(g.feeBps);
  const c = item.curve ? toCurve(item.curve) : null;
  const [side, setSide] = useState<'buy' | 'sell'>('buy');
  const [amount, setAmount] = useState('');
  const [slippageBps, setSlippageBps] = useState(100);
  const [balance, setBalance] = useState<bigint | null>(null);
  const cluster = state.cluster;

  useEffect(() => {
    if (!wallet) return setBalance(null);
    fetch(`/api/launchpad/balance?owner=${wallet.toBase58()}&mint=${item.mint}`)
      .then((r) => r.json())
      .then((d) => setBalance(d?.ok ? BigInt(d.amount) : null))
      .catch(() => setBalance(null));
  }, [wallet, item.mint, state.fetchedAt]);

  const quote = useMemo(() => {
    if (!c || c.complete) return null;
    try {
      if (side === 'buy') {
        const total = parseUnits(amount, 9);
        if (!total) return null;
        const solIn = L.solInForBudget(total, feeBps);
        const q = L.quoteBuy(c.virtualSolReserves, c.virtualTokenReserves, c.realTokenReserves, feeBps, solIn);
        const before = L.spotPriceSol(c);
        const after = L.spotPriceSol({ virtualSolReserves: q.newVirtualSol, virtualTokenReserves: q.newVirtualToken });
        return { kind: 'buy' as const, q, impact: (after / before - 1) * 100, min: L.withSlippage(q.tokensOut, slippageBps) };
      }
      const tokens = parseUnits(amount, L.TOKEN_DECIMALS);
      if (!tokens) return null;
      const q = L.quoteSell(c.virtualSolReserves, c.virtualTokenReserves, c.realSolReserves, feeBps, tokens);
      return { kind: 'sell' as const, q, tokens, min: L.withSlippage(q.solOutNet, slippageBps) };
    } catch (e: any) {
      return { kind: 'error' as const, message: e?.code === 'InsufficientReserves' ? 'More than the curve can buy back right now.' : 'Amount too small.' };
    }
  }, [amount, side, slippageBps, c?.virtualSolReserves, c?.virtualTokenReserves, c?.realTokenReserves, c?.realSolReserves, feeBps]);

  if (!c) return <Card><div className="text-xs font-mono text-rose-300">This token's curve account couldn't be read.</div></Card>;

  const price = L.spotPriceSol(c);
  const mcapSol = price * (Number(c.tokenTotalSupply) / 10 ** L.TOKEN_DECIMALS);
  const I = L.launchpadInstructions(state.programId);

  const submit = () =>
    run(side === 'buy' ? `Buy ${item.symbol}` : `Sell ${item.symbol}`, async () => {
      const w = await ensureWallet();
      if (!quote || quote.kind === 'error') throw new Error('Enter a valid amount.');
      const ix =
        quote.kind === 'buy'
          ? I.buy(w, g.feeRecipient, item.mint, quote.q.solIn, quote.min)
          : I.sell(w, g.feeRecipient, item.mint, quote.tokens, quote.min);
      const sig = await signAndRelay({ feePayer: w, instructions: [ix], computeUnits: 150_000 });
      setAmount('');
      return sig;
    });

  return (
    <Card className="space-y-5">
      <div className="flex items-start gap-3">
        <TokenLogo src={item.image} symbol={item.symbol} size="w-14 h-14" />
        <div className="min-w-0 flex-1">
          <div className="text-xl font-extrabold text-white">
            {item.name} <span className="text-sm font-mono text-cyan-300">${item.symbol}</span>
          </div>
          <div className="text-[11px] font-mono text-[#8a93a8] flex flex-wrap gap-x-3">
            <a href={explorerUrl('token', item.mint, cluster)} target="_blank" rel="noreferrer" className="hover:text-white inline-flex items-center gap-1">
              mint {short(item.mint)} <ExternalLink className="w-3 h-3" />
            </a>
            <a href={explorerUrl('account', item.creator, cluster)} target="_blank" rel="noreferrer" className="hover:text-white">
              creator {short(item.creator)}
            </a>
            <span>launched {new Date(Number(item.createdAt) * 1000).toLocaleString()}</span>
          </div>
          {item.description && <p className="text-xs text-[#a3b0c6] mt-1 line-clamp-2">{item.description}</p>}
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Stat label="Price" value={fmtPrice(price)} tone="text-cyan-300" />
        <Stat label="Market cap" value={`${mcapSol.toLocaleString(undefined, { maximumFractionDigits: 2 })} SOL`} />
        <Stat
          label="Raised"
          value={fmtSol(c.migrated ? c.migrationSol : c.realSolReserves, 3)}
          tone="text-emerald-400"
          sub={c.complete ? 'sold out' : `${fmtSol(L.solToComplete(c), 2)} to sell out`}
        />
        <Stat label="Platform fees" value={fmtSol(c.feesLamports)} tone="text-amber-300" sub={`${c.tradeCount} trades`} />
      </div>
      <div className="text-[11px] font-mono text-[#6b7c96] flex flex-wrap gap-x-4 gap-y-1">
        <span className="inline-flex items-center gap-1"><Lock className="w-3 h-3" /> mint authority revoked · fixed supply {fmtTokens(c.tokenTotalSupply)}</span>
        <span>{fmtTokens(c.tokenTotalSupply - c.initialRealTokenReserves)} reserved for the DEX pool</span>
      </div>

      {c.complete ? (
        <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-200 text-xs font-mono leading-relaxed">
          {c.migrated ? (
            <>
              Sold out and migrated: {fmtSol(c.migrationSol, 3)} and {fmtTokens(c.migrationTokens)} {item.symbol} went to the platform's migration
              wallet to create the DEX pool.{' '}
              {c.migrationPool ? (
                <a href={explorerUrl('account', c.migrationPool, cluster)} target="_blank" rel="noreferrer" className="underline">
                  Pool {short(c.migrationPool)}
                </a>
              ) : (
                'Pool not recorded yet.'
              )}
            </>
          ) : (
            'Sold out. Trading on the curve has closed; the platform now moves the raised SOL and reserved tokens into a DEX pool.'
          )}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex gap-2">
            {(['buy', 'sell'] as const).map((s) => (
              <button
                type="button"
                key={s}
                onClick={() => {
                  setSide(s);
                  setAmount('');
                }}
                className={`flex-1 py-2 rounded-lg text-xs font-mono font-bold ${
                  side === s ? (s === 'buy' ? 'bg-emerald-500 text-[#05080f]' : 'bg-rose-500 text-white') : 'bg-[#0e1422] text-[#8a93a8] border border-[#1b263d]'
                }`}
              >
                {s === 'buy' ? 'Buy' : 'Sell'}
              </button>
            ))}
          </div>
          <div>
            <div className="flex justify-between text-[11px] font-mono text-[#8a93a8] mb-1">
              <span>{side === 'buy' ? 'SOL to spend (fee included)' : `${item.symbol} to sell`}</span>
              {side === 'sell' && balance !== null && <span>balance {fmtTokens(balance)}</span>}
            </div>
            <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder={side === 'buy' ? '0.1' : '1000000'} className={inputCls} inputMode="decimal" />
            {side === 'sell' && balance !== null && balance > 0n && (
              <div className="flex gap-2 mt-2">
                {[25, 50, 100].map((p) => (
                  <button
                    type="button"
                    key={p}
                    className={btnGhost}
                    onClick={() => {
                      const v = (balance * BigInt(p)) / 100n;
                      setAmount((Number(v) / 10 ** L.TOKEN_DECIMALS).toString());
                    }}
                  >
                    {p}%
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono text-[#8a93a8]">
            <span>Slippage</span>
            {[50, 100, 300].map((b) => (
              <button
                type="button"
                key={b}
                onClick={() => setSlippageBps(b)}
                className={`px-2 py-1 rounded border ${slippageBps === b ? 'border-cyan-400 text-white' : 'border-[#1b263d]'}`}
              >
                {b / 100}%
              </button>
            ))}
          </div>
          {quote && (
            <div className="p-3 rounded-xl bg-[#060911] border border-[#162032] text-xs font-mono text-[#a3b0c6] space-y-1">
              {quote.kind === 'error' && <div className="text-rose-300">{quote.message}</div>}
              {quote.kind === 'buy' && (
                <>
                  <div>You get ≈ <span className="text-white font-bold">{fmtTokens(quote.q.tokensOut)} {item.symbol}</span> (at least {fmtTokens(quote.min)})</div>
                  <div>Into the curve {fmtSol(quote.q.solIn)} · platform fee {fmtSol(quote.q.fee)}</div>
                  <div>Price impact {quote.impact.toFixed(2)}%{quote.q.completes ? ' · this buy sells out the curve' : ''}</div>
                </>
              )}
              {quote.kind === 'sell' && (
                <>
                  <div>You get ≈ <span className="text-white font-bold">{fmtSol(quote.q.solOutNet)}</span> (at least {fmtSol(quote.min)})</div>
                  <div>Platform fee {fmtSol(quote.q.fee)}</div>
                  {balance !== null && quote.tokens > balance && <div className="text-rose-300">More than your balance.</div>}
                </>
              )}
            </div>
          )}
          <button type="button" onClick={submit} disabled={!!busy || !quote || quote.kind === 'error'} className={`${btnPrimary} w-full`}>
            {busy ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Coins className="w-4 h-4" />}
            {busy ? `${busy}…` : wallet ? (side === 'buy' ? 'Buy' : 'Sell') : 'Connect wallet & trade'}
          </button>
        </div>
      )}
    </Card>
  );
};

// ---------- Launch ----------

const LaunchTab: React.FC<TabProps & { pinataEnabled: boolean; onLaunched: (mint: string) => void }> = ({
  state,
  pinataEnabled,
  busy,
  ensureWallet,
  run,
  onLaunched,
}) => {
  const g = state.global!;
  const [f, setF] = useState({ name: '', symbol: '', description: '', imageUrl: '', website: '', twitter: '', telegram: '', metadataUri: '', devBuy: '' });
  const [imageDataUrl, setImageDataUrl] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });

  const useManualUri = !pinataEnabled || f.metadataUri.trim() !== '';
  const problems: string[] = [];
  if (!f.name.trim() || utf8Len(f.name.trim()) > L.MAX_NAME_LEN) problems.push(`Name: 1–${L.MAX_NAME_LEN} characters`);
  if (!f.symbol.trim() || utf8Len(f.symbol.trim()) > L.MAX_SYMBOL_LEN) problems.push(`Symbol: 1–${L.MAX_SYMBOL_LEN} characters`);
  if (useManualUri && (!/^https:\/\//.test(f.metadataUri.trim()) || utf8Len(f.metadataUri.trim()) > L.MAX_URI_LEN))
    problems.push(pinataEnabled ? 'Metadata URL must start with https://' : 'Metadata URL (https://, hosting your token JSON) is required');
  if (!useManualUri && !imageDataUrl && !/^https:\/\//.test(f.imageUrl.trim())) problems.push('Add an image (upload or https link)');
  const devBuy = f.devBuy.trim() ? parseUnits(f.devBuy, 9) : 0n;
  if (devBuy === null) problems.push('Initial buy must be a SOL amount');

  const devQuote = useMemo(() => {
    if (!devBuy) return null;
    try {
      const solIn = L.solInForBudget(devBuy, Number(g.feeBps));
      return L.quoteBuy(B(g.initialVirtualSolReserves), B(g.initialVirtualTokenReserves), B(g.initialRealTokenReserves), Number(g.feeBps), solIn);
    } catch {
      return null;
    }
  }, [devBuy, g]);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2_000_000) return alert('Image must be under 2 MB.');
    const reader = new FileReader();
    reader.onload = () => setImageDataUrl(String(reader.result));
    reader.readAsDataURL(file);
  };

  const launch = () =>
    run(`Launch $${f.symbol.trim()}`, async () => {
      const w = await ensureWallet();
      let uri = f.metadataUri.trim();
      if (!useManualUri) {
        const up = await fetch('/api/launchpad/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...f, imageDataUrl, name: f.name.trim(), symbol: f.symbol.trim() }),
        }).then((r) => r.json());
        if (!up?.ok) throw new Error(up?.error || 'Metadata upload failed.');
        uri = up.uri;
      }
      // Read the launch counter right before building, since it seeds the registry entry.
      const fresh = (await fetch('/api/launchpad/state?fresh=1').then((r) => r.json())) as LpState;
      if (fresh.status !== 'LIVE' || !fresh.global) throw new Error('The launchpad is not live on this cluster.');
      if (fresh.global.paused) throw new Error('Launches are paused by the platform.');
      const fg = fresh.global;
      const mint = Keypair.generate();
      const I = L.launchpadInstructions(fresh.programId);
      const ixs = [I.launchToken(w, mint.publicKey, B(fg.launchCount), f.name.trim(), f.symbol.trim(), uri)];
      if (devBuy && devBuy > 0n) {
        const solIn = L.solInForBudget(devBuy, Number(fg.feeBps));
        const q = L.quoteBuy(B(fg.initialVirtualSolReserves), B(fg.initialVirtualTokenReserves), B(fg.initialRealTokenReserves), Number(fg.feeBps), solIn);
        ixs.push(I.buy(w, fg.feeRecipient, mint.publicKey, q.solIn, L.withSlippage(q.tokensOut, 50)));
      }
      const sig = await signAndRelay({ feePayer: w, instructions: ixs, extraSigners: [mint], computeUnits: devBuy ? 450_000 : 350_000 });
      onLaunched(mint.publicKey.toBase58());
      return sig;
    });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <Card className="lg:col-span-2 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Name</span>
            <input className={inputCls} value={f.name} onChange={set('name')} placeholder="Burn City" maxLength={32} />
          </label>
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Symbol</span>
            <input className={inputCls} value={f.symbol} onChange={set('symbol')} placeholder="BURN" maxLength={10} />
          </label>
        </div>
        <label className="text-xs font-mono text-[#8a93a8] space-y-1 block">
          <span>Description</span>
          <textarea className={`${inputCls} min-h-20`} value={f.description} onChange={set('description')} maxLength={1000} />
        </label>
        {pinataEnabled && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <label className="text-xs font-mono text-[#8a93a8] space-y-1">
              <span>Image (PNG/JPG/GIF/WebP, under 2 MB)</span>
              <input type="file" accept="image/png,image/jpeg,image/gif,image/webp" onChange={onFile} className="text-xs text-[#a3b0c6]" />
            </label>
            <label className="text-xs font-mono text-[#8a93a8] space-y-1">
              <span>…or image link</span>
              <input className={inputCls} value={f.imageUrl} onChange={set('imageUrl')} placeholder="https://…" />
            </label>
          </div>
        )}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {(['website', 'twitter', 'telegram'] as const).map((k) => (
            <label key={k} className="text-xs font-mono text-[#8a93a8] space-y-1">
              <span className="capitalize">{k === 'twitter' ? 'X / Twitter' : k} (optional)</span>
              <input className={inputCls} value={f[k]} onChange={set(k)} placeholder="https://…" />
            </label>
          ))}
        </div>
        <label className="text-xs font-mono text-[#8a93a8] space-y-1 block">
          <span>{pinataEnabled ? 'Metadata URL (optional: overrides the IPFS upload)' : 'Metadata URL (JSON with name, symbol, image)'}</span>
          <input className={inputCls} value={f.metadataUri} onChange={set('metadataUri')} placeholder="https://…/token.json" />
        </label>
        <label className="text-xs font-mono text-[#8a93a8] space-y-1 block">
          <span>Your initial buy in SOL (optional, same transaction, fee included)</span>
          <input className={inputCls} value={f.devBuy} onChange={set('devBuy')} placeholder="0" inputMode="decimal" />
        </label>
        {devQuote && (
          <div className="text-[11px] font-mono text-[#a3b0c6]">
            Initial buy gets ≈ {fmtTokens(devQuote.tokensOut)} {f.symbol || 'tokens'} for {fmtSol(devQuote.solIn)} + {fmtSol(devQuote.fee)} fee.
          </div>
        )}
        {problems.length > 0 && (
          <ul className="text-[11px] font-mono text-amber-300 list-disc pl-4">
            {problems.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        )}
        <button type="button" onClick={launch} disabled={!!busy || problems.length > 0} className={`${btnPrimary} w-full`}>
          {busy ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Rocket className="w-4 h-4" />}
          {busy ? `${busy}…` : 'Launch token'}
        </button>
      </Card>
      <Card className="space-y-3 text-xs font-mono text-[#a3b0c6] leading-relaxed">
        <div className="text-white font-bold text-sm">What a launch does</div>
        <ul className="list-disc pl-4 space-y-1">
          <li>Creates the token with a fixed supply of {fmtTokens(g.tokenTotalSupply)}, then revokes the mint authority. No freeze authority.</li>
          <li>Writes immutable on-chain metadata (name, symbol, URL).</li>
          <li>Puts {fmtTokens(g.initialRealTokenReserves)} on the bonding curve; the rest is reserved for the DEX pool when it sells out.</li>
          <li>Every buy and sell pays a {(Number(g.feeBps) / 100).toLocaleString()}% platform fee to {short(g.feeRecipient)}.</li>
        </ul>
        <div className="text-white font-bold text-sm pt-2">Cost to launch</div>
        <p>Roughly 0.02–0.03 SOL for account rent, Metaplex's metadata fee and network fees, plus any initial buy.</p>
      </Card>
    </div>
  );
};

// ---------- Platform admin ----------

const PlatformTab: React.FC<TabProps & { wallet: PublicKey | null }> = ({ state, wallet, busy, ensureWallet, run }) => {
  const me = wallet?.toBase58() ?? '';
  const g = state.global;
  const I = L.launchpadInstructions(state.programId);
  const [feePct, setFeePct] = useState(g ? String(Number(g.feeBps) / 100) : '1');
  const [feeRecipient, setFeeRecipient] = useState(g?.feeRecipient ?? '');
  const [migrationAuthority, setMigrationAuthority] = useState(g?.migrationAuthority ?? '');
  const [poolInputs, setPoolInputs] = useState<Record<string, string>>({});
  const cluster = state.cluster;

  const validKey = (s: string) => {
    try {
      return new PublicKey(s.trim()).toBase58() === s.trim();
    } catch {
      return false;
    }
  };
  const feeBps = Math.round(Number(feePct) * 100);
  const feeOk = Number.isFinite(feeBps) && feeBps >= 0 && feeBps <= L.MAX_FEE_BPS;

  if (state.status === 'NOT_DEPLOYED') {
    return (
      <Card className="text-xs font-mono text-[#a3b0c6] leading-relaxed space-y-2">
        <div className="text-white font-bold text-sm">Deploy the program first</div>
        <p>Program {state.programId} isn't on {cluster}. Follow DEPLOY.md: build with Anchor, deploy to devnet (free), test, then deploy to mainnet.</p>
      </Card>
    );
  }

  if (state.status === 'NOT_INITIALIZED') {
    const canInit = me && me === state.upgradeAuthority;
    return (
      <Card className="space-y-4">
        <div className="text-white font-bold text-sm">Initialize the launchpad (one time)</div>
        <p className="text-xs font-mono text-[#8a93a8]">
          Only the wallet that deployed the program can do this: {short(state.upgradeAuthority)}.{' '}
          {me ? (canInit ? 'That is your connected wallet.' : `Your connected wallet is ${short(me)}.`) : 'Connect it to continue.'}
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Platform fee % (max 5)</span>
            <input className={inputCls} value={feePct} onChange={(e) => setFeePct(e.target.value)} />
          </label>
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Fee wallet</span>
            <input className={inputCls} value={feeRecipient} onChange={(e) => setFeeRecipient(e.target.value)} placeholder={me || 'wallet address'} />
          </label>
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Migration wallet</span>
            <input className={inputCls} value={migrationAuthority} onChange={(e) => setMigrationAuthority(e.target.value)} placeholder={me || 'wallet address'} />
          </label>
        </div>
        <p className="text-[11px] font-mono text-[#6b7c96]">
          Uses the pump-style curve: about 85 SOL sells out a token, and 20.69% of supply is kept for the DEX pool. The fee wallet must
          already hold a little SOL (over 0.001) so it can receive small fees.
        </p>
        <button
          type="button"
          disabled={!!busy || !canInit || !feeOk}
          className={btnPrimary}
          onClick={() =>
            run('Initialize launchpad', async () => {
              const w = await ensureWallet();
              const params = {
                feeRecipient: validKey(feeRecipient) ? feeRecipient.trim() : w.toBase58(),
                migrationAuthority: validKey(migrationAuthority) ? migrationAuthority.trim() : w.toBase58(),
                feeBps,
                ...L.DEFAULT_CURVE,
              };
              return signAndRelay({ feePayer: w, instructions: [I.initializeGlobal(w, params)], computeUnits: 100_000 });
            })
          }
        >
          <Settings className="w-4 h-4" /> Initialize
        </button>
      </Card>
    );
  }

  const isAuthority = me === g!.authority;
  const isMigrator = me === g!.migrationAuthority;
  const queue = state.launches.filter((l) => l.curve && l.curve.complete);

  return (
    <div className="space-y-6">
      <Card className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-white font-bold text-sm">Settings</div>
          <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded border ${g!.paused ? 'border-rose-500/40 text-rose-300' : 'border-emerald-500/40 text-emerald-300'}`}>
            {g!.paused ? 'PAUSED (launches & buys)' : 'OPEN'}
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px] font-mono text-[#a3b0c6]">
          <div>Admin: <a className="text-white hover:underline" href={explorerUrl('account', g!.authority, cluster)} target="_blank" rel="noreferrer">{short(g!.authority)}</a></div>
          <div>Fee wallet: <a className="text-white hover:underline" href={explorerUrl('account', g!.feeRecipient, cluster)} target="_blank" rel="noreferrer">{short(g!.feeRecipient)}</a></div>
          <div>Migration wallet: <a className="text-white hover:underline" href={explorerUrl('account', g!.migrationAuthority, cluster)} target="_blank" rel="noreferrer">{short(g!.migrationAuthority)}</a></div>
        </div>
        {!isAuthority && <p className="text-[11px] font-mono text-[#6b7c96]">Connect the admin wallet to change settings.</p>}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Platform fee % (max 5)</span>
            <input className={inputCls} value={feePct} onChange={(e) => setFeePct(e.target.value)} disabled={!isAuthority} />
          </label>
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Fee wallet</span>
            <input className={inputCls} value={feeRecipient} onChange={(e) => setFeeRecipient(e.target.value)} disabled={!isAuthority} />
          </label>
          <label className="text-xs font-mono text-[#8a93a8] space-y-1">
            <span>Migration wallet</span>
            <input className={inputCls} value={migrationAuthority} onChange={(e) => setMigrationAuthority(e.target.value)} disabled={!isAuthority} />
          </label>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className={btnPrimary}
            disabled={!!busy || !isAuthority || !feeOk || !validKey(feeRecipient) || !validKey(migrationAuthority)}
            onClick={() =>
              run('Save settings', async () => {
                const w = await ensureWallet();
                const ix = I.updateGlobal(w, { feeBps, feeRecipient: feeRecipient.trim(), migrationAuthority: migrationAuthority.trim() });
                return signAndRelay({ feePayer: w, instructions: [ix], computeUnits: 60_000 });
              })
            }
          >
            Save settings
          </button>
          <button
            type="button"
            className={btnGhost}
            disabled={!!busy || !isAuthority}
            onClick={() =>
              run(g!.paused ? 'Resume launches & buys' : 'Pause launches & buys', async () => {
                const w = await ensureWallet();
                return signAndRelay({ feePayer: w, instructions: [I.updateGlobal(w, { paused: !g!.paused })], computeUnits: 60_000 });
              })
            }
          >
            {g!.paused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />} {g!.paused ? 'Resume' : 'Pause'}
          </button>
        </div>
        <p className="text-[11px] font-mono text-[#6b7c96]">Pausing stops new launches and buys. Sells always stay open so holders can exit.</p>
      </Card>

      <Card className="space-y-3">
        <div className="text-white font-bold text-sm flex items-center gap-2"><Flame className="w-4 h-4 text-amber-400" /> Graduation queue</div>
        <p className="text-[11px] font-mono text-[#8a93a8] leading-relaxed">
          When a curve sells out, the migration wallet withdraws its SOL and reserved tokens, creates the Raydium pool with them, burns the LP
          tokens, and records the pool here. Each step is on-chain and public.
        </p>
        {queue.length === 0 && <div className="text-xs font-mono text-[#6b7c96]">No sold-out curves yet.</div>}
        {queue.map((l) => {
          const c = toCurve(l.curve!);
          return (
            <div key={l.mint} className="p-3 rounded-xl border border-[#1b2436] bg-[#060911] text-xs font-mono space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-white font-bold">{l.name} ${l.symbol}</span>
                <span className={c.migrated ? 'text-cyan-300' : 'text-amber-300'}>{c.migrated ? (c.migrationPool ? 'pool recorded' : 'withdrawn, pool pending') : 'ready to withdraw'}</span>
              </div>
              {!c.migrated ? (
                <button
                  type="button"
                  className={btnPrimary}
                  disabled={!!busy || !isMigrator}
                  onClick={() =>
                    run(`Withdraw ${l.symbol} for migration`, async () => {
                      const w = await ensureWallet();
                      return signAndRelay({ feePayer: w, instructions: [I.withdrawForMigration(w, l.mint)], computeUnits: 120_000 });
                    })
                  }
                >
                  Withdraw {fmtSol(c.realSolReserves, 3)} + {fmtTokens(B(c.tokenTotalSupply) - c.initialRealTokenReserves)} {l.symbol}
                </button>
              ) : c.migrationPool ? (
                <a className="text-cyan-300 underline" href={explorerUrl('account', c.migrationPool, cluster)} target="_blank" rel="noreferrer">
                  Pool {short(c.migrationPool)}
                </a>
              ) : (
                <div className="space-y-2">
                  <div className="text-[#a3b0c6]">
                    Create a Raydium CPMM pool with {fmtSol(c.migrationSol, 3)} and {fmtTokens(c.migrationTokens)} {l.symbol} on{' '}
                    <a className="underline" href="https://raydium.io/liquidity/create-pool/" target="_blank" rel="noreferrer">raydium.io</a>, burn its LP
                    tokens, then paste the pool ID:
                  </div>
                  <div className="flex gap-2">
                    <input
                      className={inputCls}
                      value={poolInputs[l.mint] ?? ''}
                      onChange={(e) => setPoolInputs({ ...poolInputs, [l.mint]: e.target.value })}
                      placeholder="Pool ID"
                    />
                    <button
                      type="button"
                      className={btnPrimary}
                      disabled={!!busy || !isMigrator || !validKey(poolInputs[l.mint] ?? '')}
                      onClick={() =>
                        run(`Record ${l.symbol} pool`, async () => {
                          const w = await ensureWallet();
                          const ix = I.recordMigrationPool(w, l.mint, (poolInputs[l.mint] ?? '').trim());
                          return signAndRelay({ feePayer: w, instructions: [ix], computeUnits: 60_000 });
                        })
                      }
                    >
                      Record
                    </button>
                  </div>
                </div>
              )}
              {!isMigrator && <div className="text-[#6b7c96]">Connect the migration wallet ({short(g!.migrationAuthority)}) to act.</div>}
            </div>
          );
        })}
      </Card>
    </div>
  );
};
