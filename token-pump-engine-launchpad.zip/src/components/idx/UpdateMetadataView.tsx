import React, { useState } from 'react';
import { TokenMetadata } from '../../types';
import { FileEdit, CheckCircle2, RefreshCw, AlertCircle } from 'lucide-react';

interface UpdateMetadataViewProps {
  tokens: TokenMetadata[];
  onRefresh: () => void;
}

export const UpdateMetadataView: React.FC<UpdateMetadataViewProps> = ({ tokens, onRefresh }) => {
  const [selectedMint, setSelectedMint] = useState<string>(tokens[0]?.mint || '');
  const token = tokens.find((t) => t.mint === selectedMint) || tokens[0];

  const [name, setName] = useState<string>(token?.name || '');
  const [symbol, setSymbol] = useState<string>(token?.symbol || '');
  const [logo, setLogo] = useState<string>(token?.logo || '');
  const [description, setDescription] = useState<string>(token?.description || '');
  const [website, setWebsite] = useState<string>(token?.website || '');
  const [twitter, setTwitter] = useState<string>(token?.twitter || '');
  const [telegram, setTelegram] = useState<string>(token?.telegram || '');

  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleUpdate = async () => {
    if (!token) return;
    try {
      setLoading(true);
      setFeedback(null);
      const res = await fetch('/api/tokens/update-metadata', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mint: token.mint,
          name,
          symbol,
          logo,
          description,
          website,
          twitter,
          telegram,
        }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback('Token metadata updated successfully on Metaplex!');
        onRefresh();
      } else {
        setFeedback(data.error || 'Failed to update metadata.');
      }
    } catch (e: any) {
      setFeedback('Error updating metadata.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-[10px] text-cyan-400 font-bold uppercase">
            Metaplex Standard
          </span>
          <span className="text-[#8a93a8]">On-Chain Token Metadata</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Update Token Metadata
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Update token name, logo, description, and official social channels if update authority is retained.
        </p>
      </div>

      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <label className="text-[#8a93a8] block mb-1">Select Token</label>
          <select
            value={selectedMint}
            onChange={(e) => {
              setSelectedMint(e.target.value);
              const sel = tokens.find((t) => t.mint === e.target.value);
              if (sel) {
                setName(sel.name);
                setSymbol(sel.symbol);
                setLogo(sel.logo);
                setDescription(sel.description || '');
              }
            }}
            className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
          >
            {tokens.map((t, idx) => (
              <option key={`${t.mint}-${idx}`} value={t.mint}>
                {t.symbol} - {t.name}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-[#8a93a8] block mb-1">Token Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1">Token Symbol</label>
            <input
              type="text"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="text-[#8a93a8] block mb-1">Logo URL</label>
            <input
              type="text"
              value={logo}
              onChange={(e) => setLogo(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="text-[#8a93a8] block mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1">Website URL</label>
            <input
              type="text"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1">Twitter / X URL</label>
            <input
              type="text"
              value={twitter}
              onChange={(e) => setTwitter(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white focus:outline-none focus:border-[#0284c7]"
            />
          </div>
        </div>

        {feedback && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <button
          onClick={handleUpdate}
          disabled={loading}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#0284c7] to-[#0369a1] hover:from-[#38bdf8] hover:to-[#0284c7] text-white font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Updating Metaplex Metadata...</span>
            </>
          ) : (
            <>
              <FileEdit className="w-4 h-4" />
              <span>Update Token Metadata</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
