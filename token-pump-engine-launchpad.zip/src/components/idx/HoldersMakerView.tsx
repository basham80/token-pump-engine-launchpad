import React, { useState } from 'react';
import { HoldersMakerConfig, TokenMetadata } from '../../types';
import {
  Users,
  UserPlus,
  Send,
  CheckCircle2,
  RefreshCw,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';

interface HoldersMakerViewProps {
  config: HoldersMakerConfig;
  tokens: TokenMetadata[];
  onRefresh: () => void;
}

export const HoldersMakerView: React.FC<HoldersMakerViewProps> = ({
  config,
  tokens,
  onRefresh,
}) => {
  const [targetCount, setTargetCount] = useState<number>(50);
  const [selectedTokenMint, setSelectedTokenMint] = useState<string>(config.tokenMint);
  const [amountPerWallet, setAmountPerWallet] = useState<number>(config.amountPerWallet || 10000);
  const [generating, setGenerating] = useState<boolean>(false);
  const [distributing, setDistributing] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const selectedToken = tokens.find((t) => t.mint === selectedTokenMint) || tokens[0];

  const handleGenerate = async () => {
    try {
      setGenerating(true);
      setFeedback(null);
      const res = await fetch('/api/bot/holders/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ count: targetCount, tokenMint: selectedToken.mint }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback(`Generated ${targetCount} burner wallets ready for token funding.`);
        onRefresh();
      }
    } catch (e: any) {
      setFeedback('Error generating wallets.');
    } finally {
      setGenerating(false);
    }
  };

  const handleDistribute = async () => {
    try {
      setDistributing(true);
      setFeedback(null);
      const res = await fetch('/api/bot/holders/distribute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountPerWallet }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback(`Successfully funded ${data.config.wallets.length} wallets! DexScreener holder count updated.`);
        onRefresh();
      }
    } catch (e: any) {
      setFeedback('Error distributing tokens.');
    } finally {
      setDistributing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/30 text-[10px] font-mono text-purple-400 font-bold uppercase">
            Organic Growth Engine
          </span>
          <span className="text-xs text-[#8a93a8] font-mono">DexScreener & Solscan Verified</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Holders Maker · Multi-Wallet Distribution
        </h1>
        <p className="text-sm text-[#8a93a8] mt-1 max-w-3xl leading-relaxed">
          Generate clean burner wallets and distribute micro-amounts of your token to organically increase holder metrics on DexScreener, Birdeye, and Solscan without triggering bot spam flags.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234]">
          <span className="text-[#8a93a8]">CURRENT HOLDERS COUNT</span>
          <div className="text-2xl font-extrabold text-purple-300 mt-1">{config.currentHoldersCount}</div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">Reported on Solana blockchain</div>
        </div>
        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234]">
          <span className="text-[#8a93a8]">GENERATED WALLETS</span>
          <div className="text-2xl font-extrabold text-white mt-1">{config.wallets.length}</div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">Ready in batch queue</div>
        </div>
        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234]">
          <span className="text-[#8a93a8]">TOTAL DISTRIBUTED</span>
          <div className="text-2xl font-extrabold text-emerald-400 mt-1">
            {config.totalDistributedTokens.toLocaleString()} {config.tokenSymbol}
          </div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">Gas cost: {config.totalSolGasSpent.toFixed(4)} SOL</div>
        </div>
      </div>

      {/* Configuration Card */}
      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white font-mono uppercase">
          Holders Campaign Setup
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div>
            <label className="text-[#8a93a8] block mb-1">Target Token</label>
            <select
              value={selectedTokenMint}
              onChange={(e) => setSelectedTokenMint(e.target.value)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
            >
              {tokens.map((t, idx) => (
                <option key={`${t.mint}-${idx}`} value={t.mint}>
                  {t.symbol} - {t.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1">New Wallets to Generate</label>
            <select
              value={targetCount}
              onChange={(e) => setTargetCount(parseInt(e.target.value, 10))}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
            >
              <option value="25">+25 Wallets (Starter boost)</option>
              <option value="50">+50 Wallets (Standard boost)</option>
              <option value="100">+100 Wallets (Trending tier)</option>
              <option value="250">+250 Wallets (Ultra viral)</option>
            </select>
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1">Tokens Per Wallet</label>
            <input
              type="number"
              value={amountPerWallet}
              onChange={(e) => setAmountPerWallet(parseInt(e.target.value, 10) || 5000)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
            />
          </div>
        </div>

        {feedback && (
          <div className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/30 text-xs font-mono text-purple-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleGenerate}
            disabled={generating}
            className="px-4 py-2.5 rounded-lg bg-[#141a29] hover:bg-[#1e263c] border border-[#232c45] text-white text-xs font-mono font-bold flex items-center gap-2"
          >
            {generating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <UserPlus className="w-3.5 h-3.5" />}
            <span>Generate Cryptographic Wallets</span>
          </button>

          <button
            onClick={handleDistribute}
            disabled={distributing}
            className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-mono font-bold flex items-center gap-2 shadow-lg shadow-purple-950/40"
          >
            {distributing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            <span>Distribute & Boost Holders</span>
          </button>

          {config.wallets.length > 0 && (
            <button
              onClick={() => {
                const csvHeader = 'Index,Address,SecretKeyBase58,SolGasBalance,TokenBalance,Funded\n';
                const csvRows = config.wallets
                  .map(
                    (w, idx) =>
                      `${idx + 1},${w.address},${w.secretKeyBase58 || 'N/A'},${w.solGasBalance},${w.tokenBalance},${w.funded}`
                  )
                  .join('\n');
                const blob = new Blob([csvHeader + csvRows], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `solana_maker_wallets_${config.tokenSymbol}_${Date.now()}.csv`;
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="px-4 py-2.5 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold flex items-center gap-2"
            >
              <span>📥 Export CSV (with Private Keys)</span>
            </button>
          )}
        </div>
      </div>

      {/* Generated Wallets List */}
      {config.wallets.length > 0 && (
        <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 shadow-xl space-y-3">
          <h4 className="text-xs font-mono font-bold text-white uppercase">
            Active Distribution Batches ({config.wallets.length} Wallets)
          </h4>
          <div className="max-h-60 overflow-y-auto space-y-1.5 font-mono text-xs">
            {config.wallets.map((w, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2 rounded-lg bg-[#111624] border border-[#1a2336] text-[11px]"
              >
                <span className="text-white">{w.address}</span>
                <span className="text-emerald-400">
                  {w.tokenBalance > 0 ? `${w.tokenBalance.toLocaleString()} ${config.tokenSymbol}` : 'Pending Funding'}
                </span>
                <span className="text-xs">
                  {w.distributed ? '✅ Funded' : '⏳ Queued'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
