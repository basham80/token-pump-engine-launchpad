import React, { useState } from 'react';
import { ReactionBoosterState } from '../../types';
import { Rocket, Flame, TrendingUp, Heart, RefreshCw, CheckCircle2, Zap } from 'lucide-react';

interface ReactionBoosterViewProps {
  reactions: ReactionBoosterState;
  onRefresh: () => void;
}

export const ReactionBoosterView: React.FC<ReactionBoosterViewProps> = ({ reactions, onRefresh }) => {
  const [boostAmount, setBoostAmount] = useState<number>(50);
  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleBoost = async () => {
    try {
      setLoading(true);
      setFeedback(null);
      const res = await fetch('/api/bot/reactions/boost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: boostAmount }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback(`Fired +${boostAmount} social reactions across DexScreener & Pump.fun!`);
        onRefresh();
      }
    } catch (e: any) {
      setFeedback('Error firing reactions.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-red-500/10 border border-red-500/30 text-[10px] text-red-400 font-bold uppercase">
            Social Sentiment Engine
          </span>
          <span className="text-[#8a93a8]">DexScreener & Pump.fun Algorithm</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Reaction Booster · Trending Velocity
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Boost rocket, flame, and bull emoji reactions to elevate your token into DEXScreener Top Trending ranks.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234] text-center">
          <Rocket className="w-6 h-6 text-cyan-400 mx-auto mb-2" />
          <span className="text-[#8a93a8] text-[10px]">ROCKETS</span>
          <div className="text-2xl font-bold text-white mt-0.5">{reactions.rocketsCount.toLocaleString()}</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234] text-center">
          <Flame className="w-6 h-6 text-red-400 mx-auto mb-2" />
          <span className="text-[#8a93a8] text-[10px]">FIRE EMOJIS</span>
          <div className="text-2xl font-bold text-white mt-0.5">{reactions.firesCount.toLocaleString()}</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234] text-center">
          <TrendingUp className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
          <span className="text-[#8a93a8] text-[10px]">BULLS</span>
          <div className="text-2xl font-bold text-white mt-0.5">{reactions.bullsCount.toLocaleString()}</div>
        </div>

        <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#1b2234] text-center">
          <Heart className="w-6 h-6 text-pink-400 mx-auto mb-2" />
          <span className="text-[#8a93a8] text-[10px]">HEARTS</span>
          <div className="text-2xl font-bold text-white mt-0.5">{reactions.heartsCount.toLocaleString()}</div>
        </div>
      </div>

      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-white font-bold">Select Reaction Surge Size</span>
          <div className="flex items-center gap-1.5">
            {[25, 50, 100, 250].map((amt) => (
              <button
                key={amt}
                onClick={() => setBoostAmount(amt)}
                className={`px-3 py-1 rounded border transition-colors ${
                  boostAmount === amt
                    ? 'bg-red-500/20 text-red-300 border-red-500/50 font-bold'
                    : 'bg-[#111624] text-[#8a93a8] border-[#1f283d]'
                }`}
              >
                +{amt} Surges
              </button>
            ))}
          </div>
        </div>

        {feedback && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <button
          onClick={handleBoost}
          disabled={loading}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-red-600 hover:from-red-500 hover:to-rose-500 text-white font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Broadcasting reaction surge...</span>
            </>
          ) : (
            <>
              <Rocket className="w-4 h-4" />
              <span>Fire +{boostAmount} Reaction Boosters</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
