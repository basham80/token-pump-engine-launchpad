import React, { useState, useEffect } from 'react';
import {
  LayoutGrid,
  Activity,
  Rocket,
  RefreshCw,
  Copy,
  ExternalLink,
  Bell,
  CheckCircle2,
  ChevronDown,
  Droplet,
  Wallet,
  Globe,
  Key,
  ShieldCheck,
  PlusCircle,
  X,
  Search,
  Check,
  Download,
  Coins,
  PanelLeft,
  Sparkles,
  Brain,
} from 'lucide-react';
import { OPERATOR_IMGS } from '../operator/operatorAssets';
import type { WalletState, TokenMetadata } from '../../types';
import { MintAllTokensModal } from './MintAllTokensModal';

interface IdxTopNavProps {
  activeTab: string;
  onNavigate: (tab: any) => void;
  wallet: WalletState;
  tokens?: TokenMetadata[];
  cluster: 'mainnet-beta' | 'devnet';
  onClusterChange: (cluster: 'mainnet-beta' | 'devnet') => void;
  onRefreshWallet: () => void;
  onWalletAddressChange: (address: string, providerName?: string) => void;
  onToggleSidebar?: () => void;
}

export const IdxTopNav: React.FC<IdxTopNavProps> = ({
  activeTab,
  onNavigate,
  wallet,
  tokens = [],
  cluster,
  onClusterChange,
  onRefreshWallet,
  onWalletAddressChange,
  onToggleSidebar,
}) => {
  const [copied, setCopied] = useState(false);
  const [copiedMintId, setCopiedMintId] = useState<string | null>(null);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showClusterMenu, setShowClusterMenu] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [airdropping, setAirdropping] = useState(false);
  const [airdropMsg, setAirdropMsg] = useState<string | null>(null);
  const [showMintAllModal, setShowMintAllModal] = useState(false);

  // Manual address / import state
  const [customAddress, setCustomAddress] = useState('');
  const [generatedKeypairData, setGeneratedKeypairData] = useState<{
    publicKey: string;
    secretKeyBase58: string;
  } | null>(null);

  // Installed extension detection
  const [detectedWallets, setDetectedWallets] = useState<{
    phantom: boolean;
    solflare: boolean;
    backpack: boolean;
    coinbase: boolean;
  }>({
    phantom: false,
    solflare: false,
    backpack: false,
    coinbase: false,
  });

  useEffect(() => {
    const anyWindow = window as any;
    setDetectedWallets({
      phantom: !!(anyWindow?.solana?.isPhantom || anyWindow?.phantom?.solana),
      solflare: !!anyWindow?.solflare,
      backpack: !!anyWindow?.backpack,
      coinbase: !!anyWindow?.coinbaseSolana,
    });
  }, [showWalletModal]);

  const fullWallet = wallet.address;
  const walletDisplay =
    fullWallet.length > 8
      ? `${fullWallet.slice(0, 4)}...${fullWallet.slice(-4)}`
      : fullWallet;

  const displayTokens =
    tokens && tokens.length > 0
      ? tokens
      : wallet.tokens && wallet.tokens.length > 0
      ? wallet.tokens
      : wallet.tokenAccounts && wallet.tokenAccounts.length > 0
      ? (wallet.tokenAccounts as any)
      : [];

  const handleCopy = () => {
    navigator.clipboard?.writeText(fullWallet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await onRefreshWallet();
    setTimeout(() => setRefreshing(false), 600);
  };

  // Real 1-Click Devnet Airdrop
  const handleRequestAirdrop = async () => {
    try {
      setAirdropping(true);
      setAirdropMsg(null);
      const res = await fetch('/api/solana/airdrop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: fullWallet, amountSol: 1 }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setAirdropMsg('✅ +1 SOL Devnet Airdrop Confirmed!');
        onRefreshWallet();
      } else {
        setAirdropMsg(data.error || 'Airdrop rate limit reached. Try in 1m.');
      }
    } catch (e: any) {
      setAirdropMsg(e?.message || 'Airdrop request failed');
    } finally {
      setAirdropping(false);
      setTimeout(() => setAirdropMsg(null), 4000);
    }
  };

  // Real Browser Wallet Connection: Phantom
  const handleConnectPhantom = async () => {
    try {
      const anyWin = window as any;
      const solana = anyWin.phantom?.solana || anyWin.solana;
      if (solana && (solana.isPhantom || anyWin.phantom)) {
        const resp = await solana.connect();
        const pubkey = resp.publicKey.toString();
        onWalletAddressChange(pubkey, 'Phantom');
        setShowWalletModal(false);
      } else {
        window.open('https://phantom.app/', '_blank');
      }
    } catch (e: any) {
      console.warn('Phantom connection cancelled:', e);
    }
  };

  // Real Browser Wallet Connection: Solflare
  const handleConnectSolflare = async () => {
    try {
      const anyWin = window as any;
      if (anyWin.solflare) {
        await anyWin.solflare.connect();
        const pubkey = anyWin.solflare.publicKey.toString();
        onWalletAddressChange(pubkey, 'Solflare');
        setShowWalletModal(false);
      } else {
        window.open('https://solflare.com/', '_blank');
      }
    } catch (e: any) {
      console.warn('Solflare connection error:', e);
    }
  };

  // Real Browser Wallet Connection: Backpack
  const handleConnectBackpack = async () => {
    try {
      const anyWin = window as any;
      if (anyWin.backpack) {
        await anyWin.backpack.connect();
        const pubkey = anyWin.backpack.publicKey.toString();
        onWalletAddressChange(pubkey, 'Backpack');
        setShowWalletModal(false);
      } else {
        window.open('https://backpack.app/', '_blank');
      }
    } catch (e: any) {
      console.warn('Backpack connection error:', e);
    }
  };

  // Custom address / watch wallet connect
  const handleConnectCustomAddress = () => {
    if (!customAddress.trim()) return;
    const clean = customAddress.trim();
    if (clean.length < 32 || clean.length > 44) {
      alert('Invalid Solana public key length.');
      return;
    }
    onWalletAddressChange(clean, 'Watch Wallet');
    setShowWalletModal(false);
    setCustomAddress('');
  };

  // Generate real new Solana keypair
  const handleGenerateNewKeypair = async () => {
    try {
      const res = await fetch('/api/solana/operator-key');
      const data = await res.json();
      if (data.publicKey) {
        setGeneratedKeypairData({
          publicKey: data.publicKey,
          secretKeyBase58: 'Available in backend operator store',
        });
        onWalletAddressChange(data.publicKey, 'Generated Keypair');
      }
    } catch (e) {
      console.warn('Generate keypair error:', e);
    }
  };

  return (
    <header className="h-16 border-b border-[#1b2234] bg-[#07090f] sticky top-0 z-40 px-4 sm:px-6 flex items-center justify-between">
      {/* Left: Sidebar Toggle, Brand Logo & Top Center Links */}
      <div className="flex items-center gap-3 sm:gap-6">
        {onToggleSidebar && (
          <button
            type="button"
            onClick={onToggleSidebar}
            className="p-2 rounded-xl bg-[#0e121d] border border-[#1f283d] text-[#8a93a8] hover:text-white transition-colors"
            title="Toggle Sidebar"
          >
            <PanelLeft className="w-4 h-4" />
          </button>
        )}

        {/* Stylized Logo & Title: BASHAM */}
        <div
          onClick={() => onNavigate('meme_launch')}
          className="flex items-center gap-2.5 cursor-pointer group"
          title="BASHAM · The Best Solana Meme Coin"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#ec4899] via-[#8b5cf6] to-[#06b6d4] p-0.5 flex items-center justify-center shadow-lg shadow-purple-950/40 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#080b13] rounded-[10px] flex items-center justify-center overflow-hidden">
              <span className="text-base">👽</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-black text-white tracking-tight group-hover:text-cyan-300 transition-colors">
                BASHAM
              </span>
              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-gradient-to-r from-purple-500/20 to-pink-500/20 text-pink-300 border border-pink-500/40 font-extrabold uppercase">
                $BASHAM
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 text-[9px] font-mono text-cyan-400 font-bold uppercase tracking-wider -mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
              <span>Argon 4 Core · Meme Engine & Pools</span>
            </div>
          </div>
        </div>

        {/* Center Nav Buttons */}
        <nav className="hidden lg:flex items-center gap-1.5 ml-2">
          <button
            onClick={() => onNavigate('operator_ai_taskforce')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'operator_ai_taskforce'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400 shadow-md shadow-amber-950/40'
                : 'text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30'
            }`}
          >
            <Brain className="w-3.5 h-3.5 text-amber-400" />
            <span>Argon 4 Core</span>
            <span className="text-[9px] font-mono text-emerald-400 font-extrabold uppercase">
              1M CTX
            </span>
          </button>
          <button
            onClick={() => onNavigate('meme_launch')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'meme_launch'
                ? 'bg-rose-950/60 text-rose-300 border border-rose-500/50 shadow-sm shadow-rose-950/40'
                : 'text-rose-400/80 hover:text-rose-300 hover:bg-rose-950/20'
            }`}
          >
            <span className="text-sm">🔥</span>
            <span>$BASHAM Launch</span>
            <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 text-[9px] font-extrabold uppercase border border-rose-500/40">
              SOON
            </span>
          </button>

          <button
            onClick={() => onNavigate('staking_pools')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'staking_pools'
                ? 'bg-[#152136] text-cyan-300 border border-[#273d66] shadow-sm'
                : 'text-[#8a93a8] hover:text-white hover:bg-[#0f1422]'
            }`}
          >
            <Coins className="w-3.5 h-3.5 text-cyan-400" />
            <span>Staking Pools</span>
            <span className="px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 text-[9px] font-extrabold uppercase border border-cyan-500/40">
              148% APY
            </span>
          </button>

          <button
            onClick={() => onNavigate('create_pool')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'create_pool'
                ? 'bg-[#151c2d] text-emerald-400 border border-emerald-500/40 shadow-sm'
                : 'text-[#8a93a8] hover:text-white hover:bg-[#0f1422]'
            }`}
          >
            <Droplet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Create Pool</span>
          </button>

          <button
            onClick={() => onNavigate('dashboard')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'dashboard'
                ? 'bg-[#151c2d] text-cyan-300 border border-[#273554] shadow-sm'
                : 'text-[#8a93a8] hover:text-white hover:bg-[#0f1422]'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Bot Dashboard</span>
          </button>

          <button
            onClick={() => onNavigate('exchange')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'exchange'
                ? 'bg-[#151c2d] text-cyan-300 border border-[#273554] shadow-sm'
                : 'text-[#8a93a8] hover:text-white hover:bg-[#0f1422]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Exchange</span>
          </button>

          <button
            onClick={() => onNavigate('blank_balance')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'blank_balance'
                ? 'bg-[#ffd60a]/20 text-[#ffd60a] border border-[#ffd60a] shadow-md shadow-yellow-950/40'
                : 'text-[#ffd60a] bg-[#ffd60a]/10 hover:bg-[#ffd60a]/20 border border-[#ffd60a]/30'
            }`}
          >
            <Coins className="w-3.5 h-3.5 text-[#ffd60a]" />
            <span>$BLANK Balance</span>
          </button>

          <button
            onClick={() => onNavigate('hot_wallets')}
            className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'hot_wallets'
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500 shadow-md shadow-emerald-950/40'
                : 'text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30'
            }`}
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Hot Wallets</span>
          </button>
        </nav>
      </div>

      {/* Right: Network Cluster + Connected Wallet Capsule */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Quick Mint All & 30% AirDrop Button */}
        <button
          type="button"
          onClick={() => setShowMintAllModal(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500/20 via-blue-500/20 to-purple-500/20 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 hover:text-white text-xs font-mono font-bold transition-all shadow-sm shadow-cyan-950/30"
          title="Mint All Tokens on Solana SPL Token Program and AirDrop 30% to HTN1...ZV5i"
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden xl:inline">Mint All Tokens</span>
          <span className="px-1.5 py-0.2 rounded bg-cyan-400/20 text-cyan-300 text-[10px] font-extrabold uppercase border border-cyan-400/40">
            30% Airdrop
          </span>
        </button>

        {/* Official X link button */}
        <a
          href="https://x.com/omegaalienmeme"
          target="_blank"
          rel="noreferrer"
          className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0e121d] hover:bg-[#161c2d] border border-[#1f283d] hover:border-cyan-500/50 text-[#8a93a8] hover:text-white text-xs font-mono transition-all"
          title="Official BASHAM & Omega Alien Meme Announcements on X"
        >
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
          <span className="font-bold">@omegaalienmeme</span>
          <ExternalLink className="w-3 h-3 text-[#64748b]" />
        </a>

        {/* Public Solscan Link */}
        <a
          href={`https://solscan.io/account/${fullWallet}`}
          target="_blank"
          rel="noreferrer"
          className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 hover:border-emerald-400 text-emerald-300 hover:text-white text-[11px] font-mono font-bold transition-all shadow-sm shadow-emerald-950/40"
          title="Inspect Public Account on Solscan.io"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Public Solscan</span>
          <ExternalLink className="w-3 h-3 text-emerald-400" />
        </a>

        {/* Network Selector Pill */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowClusterMenu(!showClusterMenu)}
            className={`px-2.5 py-1.5 rounded-xl border text-[11px] font-mono font-bold flex items-center gap-1.5 transition-all ${
              cluster === 'mainnet-beta'
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300 shadow-sm shadow-emerald-950/50'
                : 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                cluster === 'mainnet-beta' ? 'bg-emerald-400 animate-ping' : 'bg-cyan-400'
              }`}
            ></span>
            <span className="hidden sm:inline">Solana</span>
            <span>{cluster === 'mainnet-beta' ? 'Mainnet-Beta' : 'Devnet'}</span>
            <ChevronDown className="w-3 h-3 text-[#8a93a8]" />
          </button>

          {showClusterMenu && (
            <div className="absolute right-0 mt-1.5 w-48 rounded-xl bg-[#0e121d] border border-[#1f283d] p-1.5 shadow-2xl z-50 text-xs font-mono">
              <button
                type="button"
                onClick={() => {
                  onClusterChange('mainnet-beta');
                  setShowClusterMenu(false);
                }}
                className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between ${
                  cluster === 'mainnet-beta'
                    ? 'bg-[#151c2d] text-emerald-400 font-bold'
                    : 'text-[#8a93a8] hover:text-white hover:bg-[#111624]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Mainnet-Beta (Live)</span>
                </div>
                {cluster === 'mainnet-beta' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
              </button>

              <button
                type="button"
                onClick={() => {
                  onClusterChange('devnet');
                  setShowClusterMenu(false);
                }}
                className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between ${
                  cluster === 'devnet'
                    ? 'bg-[#151c2d] text-cyan-400 font-bold'
                    : 'text-[#8a93a8] hover:text-white hover:bg-[#111624]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  <span>Solana Devnet (Test)</span>
                </div>
                {cluster === 'devnet' && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
              </button>
            </div>
          )}
        </div>

        {/* 1-Click Devnet Faucet Airdrop Button if in devnet */}
        {cluster === 'devnet' && (
          <button
            type="button"
            onClick={handleRequestAirdrop}
            disabled={airdropping}
            title="Request 1 Free SOL on Devnet"
            className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600/30 to-blue-600/30 border border-cyan-500/40 hover:border-cyan-400 text-[11px] font-mono font-bold text-cyan-300 transition-all shadow-sm"
          >
            <Droplet className={`w-3 h-3 text-cyan-400 ${airdropping ? 'animate-bounce' : ''}`} />
            <span>{airdropping ? 'Airdropping...' : '+1 SOL Faucet'}</span>
          </button>
        )}

        {/* Connected Wallet Capsule */}
        <div className="relative">
          <div
            onClick={() => setShowWalletModal(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0e121d] border border-[#1f283d] hover:border-[#38bdf8]/50 text-xs font-mono shadow-md cursor-pointer transition-colors"
          >
            {/* Pulsing indicator */}
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>

            {/* Address */}
            <span className="text-white font-bold tracking-wider">{walletDisplay}</span>

            {/* Balance & Provider */}
            <div className="flex items-center gap-1.5 border-l border-[#20293d] pl-2 text-[11px]">
              <span className="text-white font-semibold">
                {wallet.solBalance < 0.0001 && wallet.solBalance > 0
                  ? wallet.solBalance.toFixed(6)
                  : wallet.solBalance.toFixed(4)}{' '}
                SOL
              </span>
              <span className="text-[#8a93a8] text-[10px] hidden sm:inline">
                {wallet.provider || 'Phantom'}
              </span>
            </div>

            {/* Quick Action Icons */}
            <div
              className="flex items-center gap-1 pl-1 border-l border-[#20293d] text-[#8a93a8]"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={handleRefresh}
                title="Refresh Balances"
                className="hover:text-white p-1 rounded transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${refreshing ? 'animate-spin text-cyan-400' : ''}`} />
              </button>

              <button
                type="button"
                onClick={handleCopy}
                title="Copy Address"
                className="hover:text-white p-1 rounded transition-colors"
              >
                {copied ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              </button>

              <a
                href={`https://solscan.io/account/${fullWallet}${cluster === 'devnet' ? '?cluster=devnet' : ''}`}
                target="_blank"
                rel="noreferrer"
                title="View on Solscan Mainnet"
                className="hover:text-white p-1 rounded transition-colors"
              >
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* Notifications Bell with '1' badge */}
        <button
          type="button"
          onClick={() => alert(`Mainnet-Beta connection active. Connected to Solana RPC cluster slot. Live market listeners running.`)}
          className="relative p-2 rounded-xl bg-[#0e121d] border border-[#1f283d] text-[#8a93a8] hover:text-white transition-colors"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
          <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center font-mono">
            1
          </span>
        </button>

        {/* User Profile Avatar matching screenshot */}
        <img
          src={OPERATOR_IMGS.head}
          alt="User Profile"
          className="w-9 h-9 rounded-full border-2 border-yellow-400/80 object-cover cursor-pointer hover:scale-105 transition-transform shadow-md shadow-yellow-950/30"
          onClick={() => onNavigate('operator_command')}
          title="OMEGA Operator Command"
        />
      </div>

      {/* Airdrop feedback banner if active */}
      {airdropMsg && (
        <div className="fixed bottom-6 right-6 z-50 p-3 rounded-xl bg-[#0e121d] border border-cyan-500/50 shadow-2xl text-xs font-mono text-cyan-300 flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2">
          <Droplet className="w-4 h-4 text-cyan-400" />
          <span>{airdropMsg}</span>
        </div>
      )}

      {/* Wallet Management Modal */}
      {showWalletModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0a0d14] border border-[#1f283d] rounded-2xl p-6 shadow-2xl space-y-5 font-mono text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#1b2234]">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Solana Wallet Controller</h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  {cluster.toUpperCase()}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowWalletModal(false)}
                className="text-[#8a93a8] hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Current Active Wallet */}
            <div className="p-4 rounded-xl bg-[#0f1422] border border-[#1b253b] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#8a93a8] uppercase tracking-wider">Active Wallet Address</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#162136] text-cyan-300">
                  {wallet.provider || 'Connected'}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 bg-[#090d16] p-2 rounded-lg border border-[#171f30]">
                <span className="text-white font-bold break-all text-xs">{fullWallet}</span>
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={handleCopy} className="text-cyan-400 hover:text-cyan-300 p-1" title="Copy Address">
                    {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <a
                    href={`https://solscan.io/account/${fullWallet}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 rounded bg-[#162136] text-cyan-300 hover:text-white"
                    title="View on Public Solscan Explorer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
              <div className="flex items-center justify-between text-xs pt-2 border-t border-[#1b2234]">
                <span className="text-[#8a93a8]">SOL Balance:</span>
                <div className="text-right">
                  <span className="text-emerald-400 font-bold text-sm">{wallet.solBalance.toFixed(5)} SOL</span>
                  {wallet.solBalanceUsd !== undefined && wallet.solBalanceUsd > 0 && (
                    <span className="text-[#8a93a8] text-[10px] block">≈ ${wallet.solBalanceUsd.toFixed(2)} USD</span>
                  )}
                </div>
              </div>
            </div>

            {/* SPL Token Holdings & 30% AirDrops */}
            <div className="p-3.5 rounded-xl bg-[#0d121f] border border-[#1b253b] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#8a93a8] uppercase tracking-wider font-bold">
                  SPL Token Balances & 30% AirDrops ({displayTokens.length})
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setShowWalletModal(false);
                    setShowMintAllModal(true);
                  }}
                  className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 hover:text-white border border-cyan-500/40 text-[10px] font-bold flex items-center gap-1 transition-colors"
                >
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  <span>Mint All (30% AirDrop)</span>
                </button>
              </div>

              {/* On-Chain Verified Ferrari Inu Callout */}
              <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-500/40 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-emerald-300 font-bold text-[11px] flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>$RARINU (Ferrari Inu) Live On-Chain</span>
                  </span>
                  <span className="text-white font-bold text-xs">877,383,839.64 RARINU</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-[#8a93a8]">
                  <span>On-Chain ATA: 9X2o...5mjZ</span>
                  <a
                    href="https://solscan.io/account/9X2oGXZAhwdU5WKpWEquK8bXNmyX2yb7RFguo2UP5mjZ"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
                  >
                    <span>View on Solscan</span>
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>
              </div>

              {/* Token list */}
              <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                {displayTokens.map((tok: any, idx: number) => {
                  const mintStr = tok.mint || tok.address || '';
                  const shortMint = mintStr ? `${mintStr.slice(0, 4)}...${mintStr.slice(-4)}` : '';
                  const bal = tok.balance !== undefined ? tok.balance : (tok.userBalance || 0);
                  const isCopied = copiedMintId === mintStr;

                  return (
                    <div
                      key={`${tok.symbol}-${mintStr}-${idx}`}
                      className="p-2 rounded-lg bg-[#080c14] border border-[#161f33] space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          {tok.logo && (
                            <img src={tok.logo} alt={tok.symbol} className="w-4 h-4 rounded-full object-cover border border-[#27374f]" />
                          )}
                          <span className="text-white font-bold text-xs">${tok.symbol}</span>
                          <span className="text-[#8a93a8] text-[10px] truncate max-w-[90px]">{tok.name}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-cyan-300 font-bold text-xs">
                            {Number(bal).toLocaleString()}
                          </span>
                          <span className="ml-1 px-1 py-0.2 rounded bg-emerald-950/60 border border-emerald-800 text-[9px] text-emerald-300 font-bold">
                            {tok.airdropPct || 30}%
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-[#8a93a8] pt-1 border-t border-[#141b2b]">
                        <div className="flex items-center gap-1">
                          <span>Mint: <span className="text-yellow-400 font-mono">{shortMint}</span></span>
                          <button
                            type="button"
                            onClick={() => {
                              if (mintStr) {
                                navigator.clipboard?.writeText(mintStr);
                                setCopiedMintId(mintStr);
                                setTimeout(() => setCopiedMintId(null), 2000);
                              }
                            }}
                            className="px-1.5 py-0.5 rounded bg-[#162035] hover:bg-[#202d4a] text-[#8a93a8] hover:text-white flex items-center gap-0.5 transition-colors"
                            title="Copy Mint to show token in Phantom"
                          >
                            {isCopied ? (
                              <span className="text-emerald-400 font-bold text-[9px]">✓ Copied</span>
                            ) : (
                              <>
                                <Copy className="w-2.5 h-2.5" />
                                <span className="text-[9px]">Copy</span>
                              </>
                            )}
                          </button>
                        </div>

                        <a
                          href={tok.explorerUrl || `https://solscan.io/token/${mintStr}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
                        >
                          <span>Solscan</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Phantom Troubleshooting Guide */}
              <div className="p-2 rounded-lg bg-amber-950/20 border border-amber-500/20 text-[10px] text-amber-200/90 leading-relaxed font-sans">
                💡 <strong>Why aren't tokens showing automatically in Phantom?</strong> Phantom hides newly minted custom tokens by default. Click <strong>"Copy"</strong> next to any Mint above, open Phantom, scroll to the bottom of your token list, click <em>"Manage Token List"</em>, paste the mint address, and toggle to <strong>Show</strong>!
              </div>
            </div>

            {/* Connect Real Browser Wallets */}
            <div className="space-y-2">
              <span className="text-[10px] text-[#8a93a8] uppercase tracking-wider block">
                Connect Browser Wallet (Mainnet-Beta & Devnet)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* Phantom */}
                <button
                  type="button"
                  onClick={handleConnectPhantom}
                  className="py-2.5 px-3 rounded-xl bg-[#141226] hover:bg-[#1c1a38] border border-purple-500/40 text-purple-200 font-bold flex items-center justify-between transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-400 group-hover:scale-125 transition-transform"></span>
                    <span>Phantom</span>
                  </div>
                  <span className="text-[10px] text-purple-400 font-normal">
                    {detectedWallets.phantom ? 'Detected' : 'Install'}
                  </span>
                </button>

                {/* Solflare */}
                <button
                  type="button"
                  onClick={handleConnectSolflare}
                  className="py-2.5 px-3 rounded-xl bg-[#261514] hover:bg-[#381e1c] border border-orange-500/40 text-orange-200 font-bold flex items-center justify-between transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-orange-400 group-hover:scale-125 transition-transform"></span>
                    <span>Solflare</span>
                  </div>
                  <span className="text-[10px] text-orange-400 font-normal">
                    {detectedWallets.solflare ? 'Detected' : 'Install'}
                  </span>
                </button>

                {/* Backpack */}
                <button
                  type="button"
                  onClick={handleConnectBackpack}
                  className="py-2.5 px-3 rounded-xl bg-[#141d26] hover:bg-[#1a2838] border border-red-500/40 text-red-200 font-bold flex items-center justify-between transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-400 group-hover:scale-125 transition-transform"></span>
                    <span>Backpack</span>
                  </div>
                  <span className="text-[10px] text-red-400 font-normal">
                    {detectedWallets.backpack ? 'Detected' : 'Install'}
                  </span>
                </button>

                {/* Coinbase / OKX */}
                <button
                  type="button"
                  onClick={async () => {
                    const anyWin = window as any;
                    if (anyWin?.okxwallet?.solana) {
                      await anyWin.okxwallet.solana.connect();
                      onWalletAddressChange(anyWin.okxwallet.solana.publicKey.toString(), 'OKX');
                      setShowWalletModal(false);
                    } else if (anyWin?.coinbaseSolana) {
                      await anyWin.coinbaseSolana.connect();
                      onWalletAddressChange(anyWin.coinbaseSolana.publicKey.toString(), 'Coinbase');
                      setShowWalletModal(false);
                    } else {
                      handleConnectPhantom();
                    }
                  }}
                  className="py-2.5 px-3 rounded-xl bg-[#141d26] hover:bg-[#1b2633] border border-blue-500/40 text-blue-200 font-bold flex items-center justify-between transition-colors group"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-400 group-hover:scale-125 transition-transform"></span>
                    <span>Coinbase / OKX</span>
                  </div>
                  <span className="text-[10px] text-blue-400 font-normal">Ready</span>
                </button>
              </div>
            </div>

            {/* Custom Watch Address */}
            <div className="space-y-1.5 pt-2 border-t border-[#1b2234]">
              <span className="text-[10px] text-[#8a93a8] uppercase tracking-wider block">
                Connect Any Solana Address (Watch & Query Live On-Chain)
              </span>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Paste any Solana Mainnet public key..."
                  value={customAddress}
                  onChange={(e) => setCustomAddress(e.target.value)}
                  className="flex-1 bg-[#111624] border border-[#1f283d] rounded-xl px-3 py-2 text-white text-xs placeholder:text-[#525d73] focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleConnectCustomAddress}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl transition-colors shrink-0"
                >
                  Load
                </button>
              </div>
            </div>

            {/* Generate Hot Keypair for Bot Operations */}
            <div className="space-y-2 pt-2 border-t border-[#1b2234]">
              <button
                type="button"
                onClick={() => {
                  setShowWalletModal(false);
                  onNavigate('hot_wallets');
                }}
                className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-emerald-500/20 via-cyan-500/20 to-emerald-500/20 hover:from-emerald-500/30 hover:to-cyan-500/30 border border-emerald-500/50 text-emerald-300 font-bold flex items-center justify-between transition-all shadow-md shadow-emerald-950/30"
              >
                <div className="flex items-center gap-2.5">
                  <Wallet className="w-4 h-4 text-emerald-400" />
                  <span>Network Hot Wallets (Deposit & Withdraw Hub)</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/40 font-mono">
                  OPEN HUB →
                </span>
              </button>

              <button
                type="button"
                onClick={handleGenerateNewKeypair}
                className="w-full py-2.5 px-3.5 rounded-xl bg-[#131929] hover:bg-[#1a233a] border border-[#1f283d] text-white flex items-center justify-between transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <Key className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Generate New Ed25519 Solana Keypair</span>
                </div>
                <PlusCircle className="w-3.5 h-3.5 text-[#8a93a8]" />
              </button>

              {cluster === 'devnet' && (
                <button
                  type="button"
                  onClick={handleRequestAirdrop}
                  disabled={airdropping}
                  className="w-full py-2 px-3.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-200 font-bold flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Droplet className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Request Free 1 SOL Devnet Faucet</span>
                  </div>
                  <span>{airdropping ? 'Requesting...' : 'Free'}</span>
                </button>
              )}
            </div>

            <div className="pt-2 text-[11px] text-[#8a93a8] flex items-center gap-1.5 border-t border-[#1b2234]">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>
                Connected to <strong className="text-white">Solana {cluster.toUpperCase()}</strong> RPC. All transaction builders & balances are authenticated on-chain.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Real Solana Mainnet SPL Token Mint & 30% AirDrop Modal */}
      <MintAllTokensModal
        isOpen={showMintAllModal}
        onClose={() => setShowMintAllModal(false)}
        tokens={displayTokens}
        recipientAddress={fullWallet}
        onSuccess={onRefreshWallet}
      />
    </header>
  );
};
