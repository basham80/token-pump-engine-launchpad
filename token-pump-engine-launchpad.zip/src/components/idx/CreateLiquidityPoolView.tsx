import React, { useState, useEffect } from 'react';
import {
  TokenMetadata,
  RaydiumPool,
  LiquiditySimulationResult,
} from '../../types';
import {
  Droplets,
  Play,
  ArrowRight,
  Info,
  CheckCircle2,
  Lock,
  Flame,
  Zap,
  ExternalLink,
  ChevronDown,
  Sparkles,
  Layers,
  ShieldCheck,
  RefreshCw,
  AlertCircle,
  Coins,
  TrendingUp,
  Activity,
  Check,
} from 'lucide-react';

interface CreateLiquidityPoolViewProps {
  tokens: TokenMetadata[];
  walletSolBalance: number;
  onPoolCreated: () => void;
  onNavigateToManage?: () => void;
  onNavigateToTrade?: (tab?: string) => void;
}

export const CreateLiquidityPoolView: React.FC<CreateLiquidityPoolViewProps> = ({
  tokens,
  walletSolBalance,
  onPoolCreated,
  onNavigateToManage,
  onNavigateToTrade,
}) => {
  // Base token state (defaults to user's live on-chain minted token Ht66mZ...Znwv or RARINU pool token)
  const defaultBase = tokens.find((t) => t.mint === 'Ht66mZ3ARwiEGFHgKK78e1A6Sp5fFfUSjyQ5L9CjZnwv') || tokens[0] || {
    name: 'Ferrari Inu',
    symbol: 'RARINU',
    decimals: 6,
    mint: 'Ht66mZ3ARwiEGFHgKK78e1A6Sp5fFfUSjyQ5L9CjZnwv',
    logo: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=128&q=80',
    supply: 122_591_674,
    userBalance: 122_591_674,
  };

  const [selectedBaseToken, setSelectedBaseToken] = useState<TokenMetadata>(defaultBase);
  const [selectedQuote, setSelectedQuote] = useState<'SOL' | 'USDC' | 'USDT'>('SOL');
  const [showBaseSelector, setShowBaseSelector] = useState(false);
  const [showQuoteSelector, setShowQuoteSelector] = useState(false);

  // Amounts (real on-chain balances)
  const [tokenAmount, setTokenAmount] = useState<string>('122591674');
  const [solAmount, setSolAmount] = useState<string>('0.0020');
  const [solBackingRatioPct, setSolBackingRatioPct] = useState<number>(50);

  // Pool Configuration
  const [poolType, setPoolType] = useState<'CPMM' | 'AMM_V4'>('CPMM');
  const [lockLp, setLockLp] = useState<boolean>(true);
  const [lockDays, setLockDays] = useState<number>(365);
  const [burnLp, setBurnLp] = useState<boolean>(false);
  const [autoPumpEnabled, setAutoPumpEnabled] = useState<boolean>(true);
  const [openBookMarketId, setOpenBookMarketId] = useState<string>('');

  // UI state & Active Pools
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [createdPool, setCreatedPool] = useState<RaydiumPool | null>(null);
  const [isDemoActive, setIsDemoActive] = useState<boolean>(false);
  const [existingPools, setExistingPools] = useState<RaydiumPool[]>([]);
  const [poolsLoading, setPoolsLoading] = useState<boolean>(false);
  const [copiedPoolId, setCopiedPoolId] = useState<string | null>(null);

  // Fetch live pools from server
  const fetchPools = async () => {
    try {
      setPoolsLoading(true);
      const res = await fetch('/api/raydium/pools');
      if (res.ok) {
        const d = await res.json();
        if (d.pools) {
          setExistingPools(d.pools);
        }
      }
    } catch {
      // ignore
    } finally {
      setPoolsLoading(false);
    }
  };

  useEffect(() => {
    fetchPools();
  }, []);

  // Quote token metadata (only real on-chain balances)
  const quoteTokens = {
    SOL: {
      name: 'Solana',
      symbol: 'SOL',
      mint: 'So11111111111111111111111111111111111111112',
      logo: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png',
      balance: walletSolBalance,
    },
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
      logo: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png',
      balance: 0,
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      mint: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
      logo: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB/logo.png',
      balance: 0,
    },
  };

  const parsedTokenAmount = parseFloat(tokenAmount) || 0;
  const parsedSolAmount = parseFloat(solAmount) || 0;
  const solPriceUsd = 148.5;

  // Price calculations
  const priceSol = parsedTokenAmount > 0 ? parsedSolAmount / parsedTokenAmount : 0;
  const priceUsd = priceSol * solPriceUsd;
  const tokensPerSol = parsedSolAmount > 0 ? parsedTokenAmount / parsedSolAmount : 0;
  const initialMarketCap = (selectedBaseToken.supply || 1_000_000_000) * priceUsd;

  // Quick Max / Half handlers
  const handleTokenMax = () => {
    setTokenAmount(selectedBaseToken.userBalance.toString());
  };
  const handleTokenHalf = () => {
    setTokenAmount((selectedBaseToken.userBalance / 2).toFixed(6));
  };
  const handleSolMax = () => {
    setSolAmount(walletSolBalance.toString());
  };
  const handleSolHalf = () => {
    setSolAmount((walletSolBalance / 2).toFixed(4));
  };

  // Interactive Demo toggle using real on-chain token & SOL balance
  const handleToggleDemo = () => {
    setIsDemoActive(!isDemoActive);
    if (!isDemoActive) {
      setTokenAmount(selectedBaseToken.userBalance > 0 ? selectedBaseToken.userBalance.toString() : '122591674');
      setSolAmount('0.0020');
      setLockLp(true);
      setAutoPumpEnabled(true);
      setSolBackingRatioPct(50);
    }
  };

  // Submit pool creation
  const handleCreatePool = async () => {
    if (parsedTokenAmount <= 0) {
      setErrorMsg('Please enter a valid token amount.');
      return;
    }
    if (parsedSolAmount <= 0) {
      setErrorMsg('Please enter a valid SOL amount.');
      return;
    }

    try {
      setLoading(true);
      setErrorMsg(null);

      const res = await fetch('/api/raydium/create-pool', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          baseTokenMint: selectedBaseToken.mint,
          quoteTokenMint: quoteTokens[selectedQuote].mint,
          baseAmount: parsedTokenAmount,
          quoteAmountSol: parsedSolAmount,
          poolType,
          lockLp,
          lockDays,
          burnLp,
          autoPumpEnabled,
          solBackingPct: solBackingRatioPct,
          openBookMarketId: poolType === 'AMM_V4' ? openBookMarketId : undefined,
        }),
      });

      const data = await res.json();
      if (res.ok && data.ok) {
        setCreatedPool(data.pool);
        onPoolCreated();
        await fetchPools();
      } else {
        setErrorMsg(data.error || 'Failed to create Raydium liquidity pool.');
      }
    } catch (e: any) {
      setErrorMsg(e?.message || 'Network error while creating pool.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12">
      {/* Title & Subtitle Matching Screenshot */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Create Solana Liquidity Pool
          </h1>
          <p className="text-sm text-[#8a9bb4] mt-2 max-w-3xl leading-relaxed">
            Launch a trading pool for your token in just two steps. Provide your token and a quote asset such as{' '}
            <strong className="text-white font-semibold">SOL</strong>,{' '}
            <strong className="text-white font-semibold">USDC</strong>, or{' '}
            <strong className="text-white font-semibold">USDT</strong> to set the initial market price. Once the pool is created, anyone can immediately start trading your token.
          </p>
        </div>

        {onNavigateToManage && (
          <button
            type="button"
            onClick={() => onNavigateToManage()}
            className="self-start sm:self-auto px-4 py-2 rounded-xl bg-[#111827] border border-[#27374f] hover:border-[#ffd60a] text-xs font-mono font-bold text-[#ffd60a] flex items-center gap-2 transition-all shrink-0"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Manage Pools</span>
          </button>
        )}
      </div>

      {/* Verified On-Chain Raydium CPMM Pool Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-emerald-500/50 bg-gradient-to-r from-emerald-950/40 via-[#0a1818] to-cyan-950/40 p-4 sm:p-5 shadow-2xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 shrink-0">
              <Coins className="w-6 h-6" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm sm:text-base font-extrabold text-white tracking-wide font-mono">
                  Live Mainnet Pool: RARINU / SOL (H2ZSmpZrqXF8Ei7mg1cVDH22awy555xr4EiU94hbpqKm)
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-[10px] font-mono font-bold text-emerald-300">
                  100% BURNED LP · VERIFIED ON SOLSCAN
                </span>
              </div>
              <p className="text-xs text-[#94a3b8] mt-1 font-mono">
                Pool Vaults: <span className="text-emerald-400 font-bold">0.001627928 SOL</span> (0.000139488 WSOL + Rent) &amp; <span className="text-cyan-300 font-bold">372,237.022164 RARINU</span> · Newly Minted Token in Wallet: <span className="text-white font-bold">122,591,674 RARINU</span> (Mint Ht66mZ...Znwv)
              </p>
            </div>
          </div>

          <a
            href="https://solscan.io/account/H2ZSmpZrqXF8Ei7mg1cVDH22awy555xr4EiU94hbpqKm"
            target="_blank"
            rel="noreferrer"
            className="w-full md:w-auto px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-950/60 transition-all flex items-center justify-center gap-2 shrink-0"
          >
            <span>Verify Pool on Solscan</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Interactive Demo Banner Matching Screenshot */}
      <div
        onClick={handleToggleDemo}
        className="cursor-pointer group relative overflow-hidden rounded-xl border border-[#0284c7]/40 bg-gradient-to-r from-[#0369a1]/20 via-[#075985]/15 to-[#082f49]/20 p-4 transition-all hover:border-[#38bdf8]/60 hover:shadow-lg hover:shadow-cyan-950/30"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#0284c7] text-white shadow-md shadow-cyan-900/50 group-hover:scale-105 transition-transform">
              <Play className="h-4 w-4 fill-white" />
            </div>
            <div>
              <div className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#38bdf8]">
                INTERACTIVE DEMO
              </div>
              <div className="text-sm font-semibold text-white">
                {isDemoActive ? 'Demo Active: Realistic RARINU Liquidity Seeding' : 'View Live Example'}
              </div>
            </div>
          </div>
          <ArrowRight className="h-5 w-5 text-[#38bdf8] group-hover:translate-x-1 transition-transform" />
        </div>
      </div>

      {/* STEP 1: TOKEN CONFIGURATION */}
      <div className="rounded-xl border border-[#1f2a3a] bg-[#0b1018] p-5 sm:p-6 shadow-xl">
        <div className="mb-4">
          <span className="inline-block rounded bg-[#0284c7]/20 border border-[#0284c7]/40 px-2 py-0.5 text-[11px] font-mono font-bold uppercase text-[#38bdf8]">
            STEP 1
          </span>
          <span className="ml-2 text-xs font-mono font-bold tracking-wide text-white uppercase">
            TOKEN CONFIGURATION
          </span>
          <p className="text-xs text-[#8a9bb4] mt-1">Select base and quote tokens for your pool</p>

          {/* Quick Base Token Selection Pills */}
          <div className="flex flex-wrap items-center gap-2 mt-3">
            <span className="text-[11px] font-mono text-[#8a9bb4] uppercase font-bold mr-1">Quick Select:</span>
            {tokens.slice(0, 5).map((tk, idx) => (
              <button
                key={`${tk.symbol}-${tk.mint}-${idx}`}
                type="button"
                onClick={() => {
                  setSelectedBaseToken(tk);
                  setTokenAmount(tk.userBalance.toString());
                }}
                className={`px-2.5 py-1 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-all ${
                  selectedBaseToken.mint === tk.mint
                    ? 'bg-[#ffd60a]/20 border-[#ffd60a] text-[#ffd60a] font-bold shadow'
                    : 'bg-[#111827] border-[#1f2a3a] text-[#8a9bb4] hover:text-white hover:border-[#27374f]'
                }`}
              >
                <img src={tk.logo} alt={tk.symbol} className="w-3.5 h-3.5 rounded-full object-cover" />
                <span>{tk.symbol} ({tk.mint.slice(0, 4)}..)</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Base Token Card */}
          <div className="relative">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1.5">Base Token</label>
            <button
              type="button"
              onClick={() => setShowBaseSelector(!showBaseSelector)}
              className="w-full flex items-center justify-between p-3.5 rounded-xl bg-[#111827] border border-[#1f2a3a] hover:border-[#27374f] transition-all text-left"
            >
              <div className="flex items-center gap-3">
                <img
                  src={selectedBaseToken.logo}
                  alt={selectedBaseToken.name}
                  className="w-8 h-8 rounded-full object-cover border border-[#27374f]"
                />
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>{selectedBaseToken.symbol}</span>
                    <span className="text-[#8a9bb4] font-normal text-xs">- {selectedBaseToken.name}</span>
                  </div>
                  <div className="text-[11px] font-mono text-[#8a9bb4]">
                    Supply: {selectedBaseToken.supply ? (selectedBaseToken.supply / 1_000_000).toLocaleString() + 'M' : '1,000M'}
                  </div>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-[#8a9bb4]" />
            </button>

            {/* Base Token Dropdown Menu */}
            {showBaseSelector && (
              <div className="absolute z-20 mt-2 w-full rounded-xl bg-[#111827] border border-[#27374f] shadow-2xl overflow-hidden p-1.5 space-y-1">
                <div className="text-[11px] font-mono text-[#8a9bb4] px-2 py-1 uppercase">Available Tokens in Wallet</div>
                {tokens.map((token, idx) => (
                  <button
                    key={`${token.mint}-${idx}`}
                    type="button"
                    onClick={() => {
                      setSelectedBaseToken(token);
                      setTokenAmount(token.userBalance.toString());
                      setShowBaseSelector(false);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors ${
                      selectedBaseToken.mint === token.mint ? 'bg-[#0284c7]/20 text-white' : 'hover:bg-[#1c2539] text-[#e8edf5]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <img src={token.logo} alt={token.symbol} className="w-6 h-6 rounded-full object-cover" />
                      <div>
                        <div className="text-xs font-bold text-white">{token.symbol} - {token.name}</div>
                        <div className="text-[10px] font-mono text-[#8a9bb4]">Bal: {token.userBalance.toLocaleString()}</div>
                      </div>
                    </div>
                    {selectedBaseToken.mint === token.mint && <CheckCircle2 className="w-3.5 h-3.5 text-[#38bdf8]" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Quote Token Card */}
          <div className="relative">
            <label className="block text-xs font-medium text-[#8a9bb4] mb-1.5">Quote Token</label>
            <button
              type="button"
              onClick={() => setShowQuoteSelector(!showQuoteSelector)}
              className="w-full flex items-center justify-between p-3.5 rounded-xl bg-[#111827] border border-[#1f2a3a] hover:border-[#27374f] transition-all text-left"
            >
              <div className="flex items-center gap-3">
                <img
                  src={quoteTokens[selectedQuote].logo}
                  alt={quoteTokens[selectedQuote].name}
                  className="w-8 h-8 rounded-full object-cover border border-[#27374f]"
                />
                <div>
                  <div className="text-sm font-bold text-white flex items-center gap-1.5">
                    <span>{quoteTokens[selectedQuote].symbol}</span>
                    <span className="text-[#8a9bb4] font-normal text-xs">- {quoteTokens[selectedQuote].name}</span>
                  </div>
                  <div className="text-[11px] font-mono text-[#8a9bb4]">
                    Balance: {quoteTokens[selectedQuote].balance} {selectedQuote}
                  </div>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-[#8a9bb4]" />
            </button>

            {/* Quote Token Dropdown */}
            {showQuoteSelector && (
              <div className="absolute z-20 mt-2 w-full rounded-xl bg-[#111827] border border-[#27374f] shadow-2xl overflow-hidden p-1.5 space-y-1">
                {(['SOL', 'USDC', 'USDT'] as const).map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setSelectedQuote(key);
                      setShowQuoteSelector(false);
                    }}
                    className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-colors ${
                      selectedQuote === key ? 'bg-[#0284c7]/20 text-white' : 'hover:bg-[#1c2539] text-[#e8edf5]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <img src={quoteTokens[key].logo} alt={key} className="w-6 h-6 rounded-full object-cover" />
                      <div>
                        <div className="text-xs font-bold text-white">{key} - {quoteTokens[key].name}</div>
                        <div className="text-[10px] font-mono text-[#8a9bb4]">Bal: {quoteTokens[key].balance} {key}</div>
                      </div>
                    </div>
                    {selectedQuote === key && <CheckCircle2 className="w-3.5 h-3.5 text-[#38bdf8]" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Tip Box Matching Screenshot */}
        <div className="mt-3.5 text-xs text-[#8a9bb4] leading-relaxed">
          Tip: For best UX, choose a widely used quote asset (SOL/USDC/USDT). Exotic quote tokens can confuse price discovery and increase volatility.
        </div>
      </div>

      {/* STEP 2: ADD LIQUIDITY */}
      <div className="rounded-xl border border-[#1f2a3a] bg-[#0b1018] p-5 sm:p-6 shadow-xl space-y-5">
        <div>
          <span className="inline-block rounded bg-[#0284c7]/20 border border-[#0284c7]/40 px-2 py-0.5 text-[11px] font-mono font-bold uppercase text-[#38bdf8]">
            STEP 2
          </span>
          <span className="ml-2 text-xs font-mono font-bold tracking-wide text-white uppercase">
            ADD LIQUIDITY
          </span>
          <p className="text-xs text-[#8a9bb4] mt-1">Set how many tokens and how much SOL you want to add</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Token Amount Input Matching Screenshot */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <div className="flex items-center justify-between text-xs text-[#8a9bb4] mb-1.5 font-mono">
              <span>Token Amount</span>
              <span>Balance: {selectedBaseToken.userBalance.toLocaleString()} {selectedBaseToken.symbol}</span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <input
                type="text"
                value={tokenAmount}
                onChange={(e) => setTokenAmount(e.target.value)}
                placeholder="0.0"
                className="w-full bg-transparent text-lg font-bold text-white focus:outline-none font-mono"
              />
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handleTokenMax}
                  className="px-2 py-1 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] font-mono text-[#8a9bb4] hover:text-white transition-colors"
                >
                  Max
                </button>
                <button
                  type="button"
                  onClick={handleTokenHalf}
                  className="px-2 py-1 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] font-mono text-[#8a9bb4] hover:text-white transition-colors"
                >
                  Half
                </button>
                <span className="px-2 py-1 rounded bg-[#1c2539] border border-[#27374f] text-xs font-bold text-white font-mono">
                  {selectedBaseToken.symbol}
                </span>
              </div>
            </div>
          </div>

          {/* SOL Amount Input Matching Screenshot */}
          <div className="rounded-xl bg-[#111827] border border-[#1f2a3a] p-3.5 focus-within:border-[#0284c7] transition-all">
            <div className="flex items-center justify-between text-xs text-[#8a9bb4] mb-1.5 font-mono">
              <span>SOL Amount</span>
              <span>Balance: {walletSolBalance} SOL <span className="text-[#4a5568]">(max ~0 after fees)</span></span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <input
                type="text"
                value={solAmount}
                onChange={(e) => setSolAmount(e.target.value)}
                placeholder="0.0"
                className="w-full bg-transparent text-lg font-bold text-white focus:outline-none font-mono"
              />
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={handleSolMax}
                  className="px-2 py-1 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] font-mono text-[#8a9bb4] hover:text-white transition-colors"
                >
                  Max
                </button>
                <button
                  type="button"
                  onClick={handleSolHalf}
                  className="px-2 py-1 rounded bg-[#1c2539] hover:bg-[#27374f] text-[10px] font-mono text-[#8a9bb4] hover:text-white transition-colors"
                >
                  Half
                </button>
                <span className="px-2 py-1 rounded bg-[#1c2539] border border-[#27374f] text-xs font-bold text-white font-mono">
                  SOL
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Real-time Pricing & Initial Market Cap Display */}
        <div className="rounded-xl bg-[#090c14] border border-[#192133] p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div>
            <div className="text-[#8a93a8] text-[11px]">INITIAL PRICE (SOL)</div>
            <div className="text-white font-bold text-sm mt-0.5 truncate">
              {priceSol > 0 ? priceSol.toFixed(10) : '0.00'} SOL
            </div>
          </div>
          <div>
            <div className="text-[#8a93a8] text-[11px]">INITIAL PRICE (USD)</div>
            <div className="text-emerald-400 font-bold text-sm mt-0.5 truncate">
              ${priceUsd > 0 ? priceUsd.toFixed(8) : '0.00'}
            </div>
          </div>
          <div>
            <div className="text-[#8a93a8] text-[11px]">TOKENS PER 1 SOL</div>
            <div className="text-white font-bold text-sm mt-0.5 truncate">
              {tokensPerSol > 0 ? Math.round(tokensPerSol).toLocaleString() : '0'}
            </div>
          </div>
          <div>
            <div className="text-[#8a93a8] text-[11px]">INITIAL MARKET CAP</div>
            <div className="text-[#38bdf8] font-bold text-sm mt-0.5 truncate">
              ${initialMarketCap > 0 ? Math.round(initialMarketCap).toLocaleString() : '0'}
            </div>
          </div>
        </div>

        {/* Pool Reserve Weight Ratio (A LOT OF SOL / 90% SOL Pool) */}
        <div className="p-4 rounded-xl bg-[#111827] border border-[#1f2a3a] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-emerald-400" />
                <span>SOL Backing & Liquidity Depth Weight</span>
              </span>
              <p className="text-[11px] text-[#8a9bb4] mt-0.5">
                Controls the percentage of total liquidity pool value backed by real SOL.
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-xs font-mono font-bold text-emerald-300 self-start sm:self-auto">
              {solBackingRatioPct}% SOL Backed
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setSolBackingRatioPct(50)}
              className={`p-2.5 rounded-lg border text-xs font-mono text-center transition-all ${
                solBackingRatioPct === 50
                  ? 'bg-[#0284c7]/20 border-[#0284c7] text-white font-bold'
                  : 'bg-[#0b1018] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
              }`}
            >
              <div className="font-bold">50% / 50%</div>
              <div className="text-[10px] text-[#64748b]">Standard AMM</div>
            </button>

            <button
              type="button"
              onClick={() => setSolBackingRatioPct(80)}
              className={`p-2.5 rounded-lg border text-xs font-mono text-center transition-all ${
                solBackingRatioPct === 80
                  ? 'bg-teal-500/20 border-teal-500 text-white font-bold'
                  : 'bg-[#0b1018] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
              }`}
            >
              <div className="font-bold">80% SOL / 20%</div>
              <div className="text-[10px] text-[#64748b]">Deep Reserve</div>
            </button>

            <button
              type="button"
              onClick={() => {
                setSolBackingRatioPct(90);
              }}
              className={`p-2.5 rounded-lg border text-xs font-mono text-center transition-all ${
                solBackingRatioPct === 90
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold ring-1 ring-emerald-500'
                  : 'bg-[#0b1018] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
              }`}
            >
              <div className="font-bold flex items-center justify-center gap-1">
                <Flame className="w-3 h-3 text-emerald-400" />
                <span>90% SOL Pool</span>
              </div>
              <div className="text-[10px] text-emerald-400 font-semibold">A LOT OF SOL (Deep Backing)</div>
            </button>
          </div>

          {solBackingRatioPct === 90 && (
            <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-2 text-xs font-mono text-emerald-300">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>
                90% SOL Pool Mode Activated: Pool is overwhelmingly backed by deep SOL reserves (Anti-Dump & Whale Protection).
              </span>
            </div>
          )}
        </div>

        {/* Advanced Raydium Pool Settings */}
        <div className="border-t border-[#1b2234] pt-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono text-[#8a93a8] uppercase font-bold">
              Raydium Pool Architecture & Security
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setPoolType('CPMM')}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-all ${
                  poolType === 'CPMM'
                    ? 'bg-[#0284c7] text-white font-bold shadow'
                    : 'bg-[#111624] text-[#8a93a8] hover:text-white border border-[#1f283d]'
                }`}
              >
                CPMM (0.15 SOL Fee · No OpenBook)
              </button>
              <button
                type="button"
                onClick={() => setPoolType('AMM_V4')}
                className={`px-2.5 py-1 rounded text-xs font-mono transition-all ${
                  poolType === 'AMM_V4'
                    ? 'bg-[#0284c7] text-white font-bold shadow'
                    : 'bg-[#111624] text-[#8a93a8] hover:text-white border border-[#1f283d]'
                }`}
              >
                AMM V4 (OpenBook DEX)
              </button>
            </div>
          </div>

          {poolType === 'AMM_V4' && (
            <div className="p-3 rounded-lg bg-[#111624] border border-[#1f283d] space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-white font-medium">OpenBook Market ID</span>
                <span className="text-[11px] text-[#8a93a8]">Optional if auto-deploying</span>
              </div>
              <input
                type="text"
                value={openBookMarketId}
                onChange={(e) => setOpenBookMarketId(e.target.value)}
                placeholder="Leave blank to auto-create OpenBook Market (0.4 SOL) or paste ID"
                className="w-full bg-[#0a0d16] border border-[#242f47] rounded-lg p-2 text-xs font-mono text-white focus:outline-none focus:border-[#0284c7]"
              />
            </div>
          )}

          {/* LP Security & Pump Integration Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Lock LP */}
            <div
              onClick={() => {
                setLockLp(!lockLp);
                if (!lockLp) setBurnLp(false);
              }}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                lockLp && !burnLp
                  ? 'bg-amber-500/10 border-amber-500/50 text-white'
                  : 'bg-[#111624] border-[#1f283d] text-[#8a93a8] hover:border-[#2b3856]'
              }`}
            >
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-bold font-mono">Time-Lock LP</span>
              </div>
              <p className="text-[11px] text-[#8a93a8] mt-1">
                Streamflow contract lock for {lockDays} days. Prevents pool rug pulls.
              </p>
            </div>

            {/* Burn LP */}
            <div
              onClick={() => {
                setBurnLp(!burnLp);
                if (!burnLp) setLockLp(false);
              }}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                burnLp
                  ? 'bg-red-500/10 border-red-500/50 text-white'
                  : 'bg-[#111624] border-[#1f283d] text-[#8a93a8] hover:border-[#2b3856]'
              }`}
            >
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-red-400" />
                <span className="text-xs font-bold font-mono">100% Burn LP</span>
              </div>
              <p className="text-[11px] text-[#8a93a8] mt-1">
                Permanently burn LP tokens to Incinerator for verifiable 0% rug risk.
              </p>
            </div>

            {/* Pump Flywheel Hook */}
            <div
              onClick={() => setAutoPumpEnabled(!autoPumpEnabled)}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                autoPumpEnabled
                  ? 'bg-emerald-500/10 border-emerald-500/50 text-white'
                  : 'bg-[#111624] border-[#1f283d] text-[#8a93a8] hover:border-[#2b3856]'
              }`}
            >
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold font-mono">Auto-Pump Hook</span>
              </div>
              <p className="text-[11px] text-[#8a93a8] mt-1">
                Connects autonomous buyback & volume engine directly to this pool.
              </p>
            </div>
          </div>
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center gap-2 text-xs text-red-300 font-mono">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Main CTA Button */}
        <div className="pt-2">
          <button
            type="button"
            disabled={loading}
            onClick={handleCreatePool}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#0284c7] via-[#0369a1] to-[#0284c7] hover:from-[#38bdf8] hover:via-[#0284c7] hover:to-[#0369a1] text-white font-bold text-sm font-mono tracking-wide shadow-xl shadow-cyan-950/60 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Initializing Raydium Pool on Solana Mainnet...</span>
              </>
            ) : (
              <>
                <Droplets className="w-4 h-4" />
                <span>Create Pool & Add Liquidity</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Pool Created Success Modal / Notification */}
      {createdPool && (
        <div className="rounded-xl border border-emerald-500/40 bg-[#091512] p-5 sm:p-6 shadow-2xl space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-full bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-mono">
                  Raydium Liquidity Pool Successfully Created!
                </h3>
                <p className="text-xs text-[#8a93a8] mt-0.5">
                  Pool ID: <span className="text-white font-mono">{createdPool.poolId}</span>
                </p>
              </div>
            </div>
            <button
              onClick={() => setCreatedPool(null)}
              className="text-[#8a93a8] hover:text-white text-xs font-mono"
            >
              Dismiss
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0d1f1a] p-3.5 rounded-xl text-xs font-mono">
            <div>
              <span className="text-[#8a93a8]">BASE RESERVES</span>
              <div className="text-white font-bold mt-0.5">{createdPool.baseReserve.toLocaleString()} {createdPool.baseToken.symbol}</div>
            </div>
            <div>
              <span className="text-[#8a93a8]">SOL RESERVES</span>
              <div className="text-white font-bold mt-0.5">{createdPool.quoteReserveSol} SOL</div>
            </div>
            <div>
              <span className="text-[#8a93a8]">LIQUIDITY USD</span>
              <div className="text-emerald-400 font-bold mt-0.5">${createdPool.liquidityUsd.toLocaleString()}</div>
            </div>
            <div>
              <span className="text-[#8a93a8]">LP STATUS</span>
              <div className="text-cyan-400 font-bold mt-0.5">
                {createdPool.lpBurned ? '100% Burned' : createdPool.lpLocked ? 'Time-Locked 365d' : 'Active'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <a
              href={`https://solscan.io/account/${createdPool.poolId}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#142922] hover:bg-[#1a382e] border border-emerald-500/30 text-xs font-mono text-emerald-300 flex items-center gap-1.5 transition-colors"
            >
              <span>View on Solscan</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={`https://dexscreener.com/solana/${createdPool.poolId}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#142922] hover:bg-[#1a382e] border border-emerald-500/30 text-xs font-mono text-emerald-300 flex items-center gap-1.5 transition-colors"
            >
              <span>DexScreener</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={`https://raydium.io/swap/?inputMint=sol&outputMint=${createdPool.baseToken.mint}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#122336] hover:bg-[#18324f] border border-cyan-500/30 text-xs font-mono text-cyan-300 flex items-center gap-1.5 transition-colors"
            >
              <span>Trade on Raydium</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <a
              href={`https://photon-sol.tinyastro.io/en/lp/${createdPool.poolId}`}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-1.5 rounded-lg bg-[#27142b] hover:bg-[#381c3d] border border-fuchsia-500/30 text-xs font-mono text-fuchsia-300 flex items-center gap-1.5 transition-colors"
            >
              <span>Photon SOL</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            {onNavigateToManage && (
              <button
                onClick={onNavigateToManage}
                className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black font-bold text-xs font-mono hover:bg-emerald-400 transition-colors ml-auto"
              >
                Manage Liquidity & Harvest Fees →
              </button>
            )}
          </div>
        </div>
      )}

      {/* Active Raydium Liquidity Pools Section */}
      <div className="rounded-2xl border border-[#1f2a3a] bg-[#0b1018] p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1b2234] pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[#0284c7]/20 border border-[#0284c7]/40 text-[#38bdf8]">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white font-mono flex items-center gap-2">
                <span>Active Raydium Liquidity Pools</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-mono font-bold">
                  {existingPools.length} Pools Live
                </span>
              </h2>
              <p className="text-xs text-[#8a9bb4] mt-0.5">
                Verified on Solana Mainnet-Beta · High Depth Pools Backed by Deep SOL Reserves
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={fetchPools}
            disabled={poolsLoading}
            className="px-3 py-1.5 rounded-lg bg-[#111827] border border-[#1f2a3a] hover:border-[#38bdf8] text-xs font-mono text-[#8a9bb4] hover:text-white transition-all flex items-center gap-1.5 self-start sm:self-auto"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${poolsLoading ? 'animate-spin' : ''}`} />
            <span>Refresh Pools</span>
          </button>
        </div>

        <div className="space-y-3 pt-1">
          {existingPools.map((pool, idx) => {
            const is90PctSol = pool.solBackingPct === 90 || pool.quoteReserveSol >= 500 || pool.baseToken.mint === '7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump';
            const isCopied = copiedPoolId === pool.poolId;

            return (
              <div
                key={`${pool.id || pool.poolId}-${idx}`}
                className={`p-4 rounded-xl border transition-all ${
                  is90PctSol
                    ? 'bg-gradient-to-r from-emerald-950/30 via-[#0d1620] to-[#0b1018] border-emerald-500/40 shadow-lg shadow-emerald-950/20'
                    : 'bg-[#111827] border-[#1f2a3a] hover:border-[#2b3a50]'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Token & Badge Info */}
                  <div className="flex items-start gap-3">
                    <img
                      src={pool.baseToken.logo}
                      alt={pool.baseToken.symbol}
                      className="w-10 h-10 rounded-full object-cover border border-[#27374f] shrink-0"
                    />
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-bold text-white font-mono">
                          {pool.baseToken.symbol} / {pool.quoteToken.symbol}
                        </span>
                        <span className="text-xs text-[#8a9bb4] font-mono">
                          ({pool.poolType})
                        </span>
                        {is90PctSol && (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40 text-[10px] font-mono font-black text-emerald-300 flex items-center gap-1">
                            <Flame className="w-3 h-3 text-emerald-400" />
                            <span>90% SOL BACKED · A LOT OF SOL</span>
                          </span>
                        )}
                        {pool.lpBurned && (
                          <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 text-[10px] font-mono font-bold">
                            LP Burned
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3 mt-1 text-xs font-mono text-[#8a9bb4]">
                        <span>Pool: {pool.poolId.slice(0, 8)}...{pool.poolId.slice(-6)}</span>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(pool.poolId);
                            setCopiedPoolId(pool.poolId);
                            setTimeout(() => setCopiedPoolId(null), 2000);
                          }}
                          className="hover:text-white flex items-center gap-1 text-[11px]"
                        >
                          {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Layers className="w-3 h-3" />}
                          <span>{isCopied ? 'Copied' : 'Copy'}</span>
                        </button>
                        <span>Mint: {pool.baseToken.mint.slice(0, 6)}...{pool.baseToken.mint.slice(-6)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Pool Metrics Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0a0e17] p-3 rounded-lg text-xs font-mono shrink-0">
                    <div>
                      <div className="text-[10px] text-[#64748b] uppercase">SOL Reserves</div>
                      <div className="text-emerald-400 font-bold mt-0.5 truncate">
                        {pool.quoteReserveSol.toLocaleString()} SOL
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-[#64748b] uppercase">Token Reserves</div>
                      <div className="text-white font-bold mt-0.5 truncate">
                        {pool.baseReserve >= 1e6 ? `${(pool.baseReserve / 1e6).toFixed(1)}M` : pool.baseReserve.toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-[#64748b] uppercase">Total Liquidity</div>
                      <div className="text-cyan-400 font-bold mt-0.5 truncate">
                        ${pool.liquidityUsd < 10 ? pool.liquidityUsd.toFixed(2) : Math.round(pool.liquidityUsd).toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-[#64748b] uppercase">Price (SOL)</div>
                      <div className="text-amber-300 font-bold mt-0.5 truncate">
                        {pool.currentPriceSol < 0.000001 ? pool.currentPriceSol.toExponential(4) : pool.currentPriceSol.toFixed(6)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Links & Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-3 border-t border-[#1b2234]">
                  <div className="flex flex-wrap items-center gap-2">
                    <a
                      href={`https://solscan.io/account/${pool.poolId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 rounded bg-[#162032] hover:bg-[#1e2d46] text-[11px] font-mono text-[#8a9bb4] hover:text-white flex items-center gap-1 transition-colors"
                    >
                      <span>Solscan</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href={`https://dexscreener.com/solana/${pool.poolId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 rounded bg-[#162032] hover:bg-[#1e2d46] text-[11px] font-mono text-[#8a9bb4] hover:text-white flex items-center gap-1 transition-colors"
                    >
                      <span>DexScreener</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <a
                      href={`https://raydium.io/swap/?inputMint=sol&outputMint=${pool.baseToken.mint}`}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1 rounded bg-[#0284c7]/20 border border-[#0284c7]/40 hover:bg-[#0284c7]/30 text-[11px] font-mono text-[#38bdf8] flex items-center gap-1 transition-colors"
                    >
                      <span>Swap on Raydium</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onNavigateToTrade ? onNavigateToTrade('pump_engine') : onNavigateToManage && onNavigateToManage()}
                      className="px-3 py-1 rounded-lg bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-black font-mono font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-emerald-950/40 cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 fill-black" />
                      <span>Pump Token with Engine</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
