import React, { useState } from 'react';
import {
  Info,
  ChevronDown,
  ChevronUp,
  Copy,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Wallet,
  Sparkles,
  Search,
  Eye,
  Zap,
} from 'lucide-react';

interface PhantomTokenVisibilityGuideProps {
  onOpenMintModal?: () => void;
  defaultExpanded?: boolean;
}

export const PhantomTokenVisibilityGuide: React.FC<PhantomTokenVisibilityGuideProps> = ({
  onOpenMintModal,
  defaultExpanded = true,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(defaultExpanded);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const RARINU_MINT = 'svNLzvHKAbLUquHgJGGiLCKLiJNFsXdyKPomHisoNY3';
  const RARINU_ATA = '9X2oGXZAhwdU5WKpWEquK8bXNmyX2yb7RFguo2UP5mjZ';
  const USER_WALLET = 'HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i';

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleConnectOrOpenPhantom = async () => {
    const anyWin = window as any;
    const solana = anyWin.phantom?.solana || anyWin.solana || anyWin.solflare;
    if (solana) {
      try {
        await solana.connect();
      } catch (e) {
        console.warn('Phantom connection attempt:', e);
      }
    } else {
      window.open('https://phantom.app', '_blank', 'noreferrer');
    }
  };

  return (
    <div className="rounded-2xl border-2 border-amber-500/40 bg-gradient-to-br from-[#1c1407] via-[#0d101d] to-[#0a0d18] p-4 sm:p-6 shadow-2xl relative overflow-hidden font-sans">
      {/* Glow highlight */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Accordion Header */}
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-start sm:items-center justify-between gap-3 text-left group cursor-pointer relative z-10"
      >
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-amber-950/40">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-mono font-bold uppercase tracking-wider">
                ESSENTIAL WALLET GUIDE · MAINNET
              </span>
              <span className="text-[11px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                877,383,839.64 $RARINU ON-CHAIN
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-white group-hover:text-amber-300 transition-colors mt-0.5">
              Why Aren&apos;t Tokens Showing in My Phantom / Solflare Wallet? (Click to view guide)
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 pt-1 sm:pt-0">
          <span className="text-xs font-mono text-amber-400 hidden sm:inline">
            {isExpanded ? 'Hide Guide' : 'Show Guide'}
          </span>
          <div className="p-1 rounded-lg bg-[#151c2e] text-[#94a3b8] group-hover:text-white transition-colors">
            {isExpanded ? <ChevronUp className="w-5 h-5 text-amber-400" /> : <ChevronDown className="w-5 h-5" />}
          </div>
        </div>
      </button>

      {/* Expanded Content with the 3 exact points */}
      {isExpanded && (
        <div className="mt-5 pt-5 border-t border-amber-500/30 space-y-5 text-xs sm:text-sm text-[#cbd5e1] leading-relaxed relative z-10">
          {/* Item 1 */}
          <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#232f48] space-y-2">
            <div className="flex items-center gap-2 text-white font-bold font-mono text-sm sm:text-base">
              <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center text-xs">
                1
              </span>
              <span>On-Chain Confirmation &amp; Rent Exemption:</span>
            </div>
            <p className="text-[#94a3b8] text-xs sm:text-sm">
              Solana requires each token account (ATA) to be created on-chain with a rent-exemption fee (~0.00204 SOL). Because only your wallet possesses the private key for{' '}
              <strong className="text-cyan-300 font-mono">HTN1...ZV5i</strong>, you must click{' '}
              <strong className="text-purple-300">&quot;Sign in Phantom&quot;</strong> below so Phantom can sign the transaction and broadcast it to the Solana Mainnet validators.
            </p>
            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              {onOpenMintModal && (
                <button
                  type="button"
                  onClick={onOpenMintModal}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-950/40 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Open Mint &amp; Sign Modal</span>
                </button>
              )}
              <button
                type="button"
                onClick={handleConnectOrOpenPhantom}
                className="px-3.5 py-1.5 rounded-xl bg-[#141a29] border border-[#2a3b5c] hover:border-purple-400 text-purple-300 hover:text-white font-mono font-bold text-xs flex items-center gap-2 transition-all"
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>Connect / Prompt Phantom Wallet</span>
              </button>
            </div>
          </div>

          {/* Item 2 */}
          <div className="p-4 rounded-xl bg-[#0b0e17] border border-[#232f48] space-y-2.5">
            <div className="flex items-center gap-2 text-white font-bold font-mono text-sm sm:text-base">
              <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center text-xs">
                2
              </span>
              <span>Phantom Automatically Hides Unverified Tokens:</span>
            </div>
            <p className="text-[#94a3b8] text-xs sm:text-sm">
              By default, Phantom and Solflare place newly minted custom meme coins in a <em className="text-amber-200">Hidden / Spam</em> folder until you add the mint address:
            </p>
            <ol className="list-decimal list-inside space-y-1.5 text-xs sm:text-sm text-[#cbd5e1] font-mono bg-[#070911] p-3 rounded-lg border border-[#1b253b]">
              <li>Open your Phantom wallet extension.</li>
              <li>
                Scroll down to the bottom of your token list and click{' '}
                <strong className="text-white bg-[#151c2e] px-1.5 py-0.5 rounded border border-[#253350]">
                  &quot;Manage Token List&quot;
                </strong>
                .
              </li>
              <li>
                Click the <strong>search / copy mint</strong> button next to any token below and paste it into the search bar.
              </li>
              <li>
                Toggle the switch to <strong className="text-emerald-400">ON</strong> so it appears permanently on your home screen.
              </li>
            </ol>
          </div>

          {/* Item 3 */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#171e12] to-[#0c141d] border-2 border-emerald-500/40 space-y-3 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-white font-bold font-mono text-sm sm:text-base">
                <span className="w-6 h-6 rounded-lg bg-emerald-500/30 text-emerald-400 border border-emerald-500/50 flex items-center justify-center text-xs">
                  3
                </span>
                <span className="text-emerald-300">
                  Your Wallet Already Holds 877,383,839.64 $RARINU:
                </span>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 text-[11px] font-mono font-bold flex items-center gap-1.5 self-start sm:self-auto">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Confirmed on Solana Mainnet</span>
              </span>
            </div>

            <p className="text-xs sm:text-sm text-[#cbd5e1]">
              Your wallet already owns on-chain Ferrari Inu ($RARINU) at mint{' '}
              <span className="font-mono font-bold text-amber-300 bg-black/60 px-2 py-0.5 rounded border border-amber-500/30">
                {RARINU_MINT}
              </span>
              . Search this mint in Phantom to reveal your 877M token balance!
            </p>

            {/* Mint Copy Callout Card */}
            <div className="p-3 sm:p-4 rounded-xl bg-[#070a12] border border-[#21304d] space-y-3 font-mono text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="text-[10px] text-[#64748b] uppercase">Ferrari Inu ($RARINU) Mint Address</div>
                  <div className="text-amber-400 font-bold break-all text-xs sm:text-sm">
                    {RARINU_MINT}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopy(RARINU_MINT, 'rarinu-mint-hero')}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold font-mono flex items-center justify-center gap-2 transition-all shrink-0 ${
                    copiedId === 'rarinu-mint-hero'
                      ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-950/50'
                      : 'bg-amber-400 hover:bg-amber-300 text-black shadow-lg shadow-amber-950/50'
                  }`}
                  title="Copy Mint Address to Paste into Phantom Manage Token List"
                >
                  {copiedId === 'rarinu-mint-hero' ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>✓ Copied to Clipboard!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Mint Address</span>
                    </>
                  )}
                </button>
              </div>

              {/* On-Chain Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-[#172238] text-[11px] text-[#94a3b8]">
                <div>
                  <span className="text-[#64748b] block text-[10px]">VERIFIED HOLDING:</span>
                  <strong className="text-white text-xs">877,383,839.64 RARINU</strong>
                </div>
                <div>
                  <span className="text-[#64748b] block text-[10px]">OWNER WALLET:</span>
                  <strong className="text-cyan-300 text-xs">HTN1...ZV5i</strong>
                </div>
                <div>
                  <span className="text-[#64748b] block text-[10px]">ASSOCIATED TOKEN ACCOUNT (ATA):</span>
                  <span className="text-emerald-400 text-xs font-mono">9X2o...5mjZ</span>
                </div>
              </div>

              {/* Verification & Solscan Links */}
              <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
                <a
                  href={`https://solscan.io/token/${RARINU_MINT}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 hover:underline"
                >
                  <span>View $RARINU Token on Solscan</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                <a
                  href={`https://solscan.io/account/${RARINU_ATA}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 hover:underline"
                >
                  <span>View Your ATA on Solscan ({RARINU_ATA.slice(0, 4)}...{RARINU_ATA.slice(-4)})</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                <a
                  href={`https://solscan.io/account/${USER_WALLET}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1 hover:underline"
                >
                  <span>View Wallet on Solscan</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
