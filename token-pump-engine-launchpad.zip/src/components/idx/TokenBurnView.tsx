import React, { useState } from 'react';
import { TokenMetadata } from '../../types';
import {
  Flame,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';

interface TokenBurnViewProps {
  tokens: TokenMetadata[];
  onRefresh: () => void;
}

export const TokenBurnView: React.FC<TokenBurnViewProps> = ({ tokens, onRefresh }) => {
  const [selectedTokenMint, setSelectedTokenMint] = useState<string>(tokens[0]?.mint || '');
  const [burnAmount, setBurnAmount] = useState<string>('10000000');
  const [burnPct, setBurnPct] = useState<number>(10);
  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const token = tokens.find((t) => t.mint === selectedTokenMint) || tokens[0];

  const handleBurn = async () => {
    if (!token) return;
    const amountNum = parseFloat(burnAmount);
    if (!amountNum || amountNum <= 0) {
      setFeedback({ type: 'error', msg: 'Please enter a valid amount to burn.' });
      return;
    }

    try {
      setLoading(true);
      setFeedback(null);
      const res = await fetch('/api/tokens/burn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mint: token.mint, amount: amountNum }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback({
          type: 'success',
          msg: `Successfully burned ${amountNum.toLocaleString()} ${token.symbol} to Solana Incinerator! Tx: ${data.txSignature}`,
        });
        onRefresh();
      } else {
        setFeedback({ type: 'error', msg: data.error || 'Burn transaction failed.' });
      }
    } catch (e: any) {
      setFeedback({ type: 'error', msg: 'Network error during token burn.' });
    } finally {
      setLoading(false);
    }
  };

  const handlePctChange = (pct: number) => {
    setBurnPct(pct);
    if (token) {
      const amt = (token.userBalance * pct) / 100;
      setBurnAmount(amt.toFixed(0));
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-red-500/10 border border-red-500/30 text-[10px] text-red-400 font-bold uppercase">
            Permanent Incinerator
          </span>
          <span className="text-[#8a93a8]">11111111111111111111111111111111</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Token Burn · Solana Supply Reducer
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Permanently incinerate SPL token supply or Raydium LP tokens. Reduces circulating supply and boosts scarcity.
        </p>
      </div>

      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <label className="text-[#8a93a8] block mb-1">Select Token to Burn</label>
          <select
            value={selectedTokenMint}
            onChange={(e) => {
              setSelectedTokenMint(e.target.value);
              const sel = tokens.find((t) => t.mint === e.target.value);
              if (sel) {
                setBurnAmount((sel.userBalance * 0.1).toFixed(0));
              }
            }}
            className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
          >
            {tokens.map((t, idx) => (
              <option key={`${t.mint}-${idx}`} value={t.mint}>
                {t.symbol} - {t.name} (Balance: {t.userBalance.toLocaleString()})
              </option>
            ))}
          </select>
        </div>

        {token && (
          <div className="p-3.5 rounded-lg bg-[#111624] border border-[#1f283d] flex items-center justify-between">
            <span className="text-[#8a93a8]">AVAILABLE WALLET BALANCE</span>
            <span className="text-white font-bold text-sm">
              {token.userBalance.toLocaleString()} {token.symbol}
            </span>
          </div>
        )}

        <div>
          <div className="flex items-center justify-between text-[#8a93a8] mb-1">
            <span>Burn Amount</span>
            <span>{burnPct}% of balance</span>
          </div>
          <input
            type="text"
            value={burnAmount}
            onChange={(e) => setBurnAmount(e.target.value)}
            className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold text-base focus:outline-none focus:border-red-500"
          />

          <div className="flex items-center gap-2 mt-2">
            {[10, 25, 50, 75, 100].map((pct) => (
              <button
                key={pct}
                onClick={() => handlePctChange(pct)}
                className={`px-3 py-1 rounded border transition-colors ${
                  burnPct === pct
                    ? 'bg-red-500/20 text-red-300 border-red-500/50 font-bold'
                    : 'bg-[#111624] text-[#8a93a8] border-[#1f283d] hover:text-white'
                }`}
              >
                {pct}%
              </button>
            ))}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 leading-relaxed">
          <div className="flex items-center gap-1.5 font-bold mb-1">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>Irreversible Action Warning</span>
          </div>
          Tokens sent to the incinerator are irreversibly destroyed and removed from total supply on Solscan.
        </div>

        {feedback && (
          <div
            className={`p-3 rounded-lg border flex items-center gap-2 ${
              feedback.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-red-500/10 border-red-500/30 text-red-300'
            }`}
          >
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            )}
            <span>{feedback.msg}</span>
          </div>
        )}

        <button
          onClick={handleBurn}
          disabled={loading}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold shadow-lg shadow-red-950/40 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Incinerating tokens on Solana...</span>
            </>
          ) : (
            <>
              <Flame className="w-4 h-4" />
              <span>Confirm & Burn {parseFloat(burnAmount || '0').toLocaleString()} Tokens</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
