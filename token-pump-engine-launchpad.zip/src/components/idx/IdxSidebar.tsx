import React, { useState } from 'react';
import {
  LayoutGrid,
  Activity,
  Bot,
  Users,
  Rocket,
  FlaskConical,
  Coins,
  Flame,
  Send,
  FileEdit,
  Sparkles,
  Droplets,
  Layers,
  BarChart3,
  ShieldAlert,
  ArrowLeftRight,
  Zap,
  ChevronDown,
  ChevronRight,
  Brain,
  Wallet,
} from 'lucide-react';

export type NavItemKey =
  | 'launchpad'
  | 'meme_launch'
  | 'staking_pools'
  | 'blank_balance'
  | 'hot_wallets'
  | 'pump_engine'
  | 'dashboard'
  | 'exchange'
  | 'volume_bot'
  | 'holders_maker'
  | 'reaction_booster'
  | 'launchlab'
  | 'token_hub'
  | 'token_burn'
  | 'bulk_sender'
  | 'update_metadata'
  | 'create_token'
  | 'create_pool'
  | 'manage_liquidity'
  | 'liquidity_simulator'
  | 'revoke_authorities'
  | 'fast_swap'
  | 'pump_flywheel'
  | 'operator_command'
  | 'operator_ai_taskforce'
  | 'operator_truth'
  | 'operator_opportunities'
  | 'operator_x402'
  | 'operator_compounding'
  | 'operator_syndicate'
  | 'operator_agents'
  | 'operator_jarvis'
  | 'operator_ledger';

interface IdxSidebarProps {
  activeTab: NavItemKey;
  onNavigate: (tab: NavItemKey) => void;
}

export const IdxSidebar: React.FC<IdxSidebarProps> = ({ activeTab, onNavigate }) => {
  // Dropdown expansion toggles
  const [openDropdowns, setOpenDropdowns] = useState<Record<string, boolean>>({
    volume: false,
    createToken: false,
    manageLiquidity: false,
    revoke: false,
  });

  const toggleDropdown = (key: string) => {
    setOpenDropdowns((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const navItems = [
    {
      key: 'launchpad',
      label: 'Launchpad',
      icon: Rocket,
      highlight: true,
      badge: 'ON-CHAIN',
      badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    },
    {
      key: 'meme_launch',
      label: '$BASHAM Meme Launch',
      icon: Flame,
      specialHighlight: true,
      badge: 'VIRAL',
      badgeClass: 'bg-rose-500/20 text-rose-400 border-rose-500/40',
    },
    {
      key: 'staking_pools',
      label: 'BASHAM Pools (StakePoint)',
      icon: Coins,
      highlight: true,
      badge: '148% APY',
      badgeClass: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40',
    },
    { key: 'blank_balance', label: 'BLANK Network Balance', icon: Coins, specialHighlight: true },
    {
      key: 'hot_wallets',
      label: 'Hot Wallets (Deposit/Withdraw)',
      icon: Wallet,
      specialHighlight: true,
      badge: 'LIVE',
      badgeClass: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
    },
    {
      key: 'pump_engine',
      label: 'Anchor Pump Engine',
      icon: Flame,
      specialHighlight: true,
      badge: '86 SOL CAP',
      badgeClass: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
    },
    { key: 'dashboard', label: 'Bot Dashboard', icon: LayoutGrid },
    { key: 'exchange', label: 'IDX Exchange', icon: Activity },
    {
      key: 'volume_bot',
      label: 'Volume Bot',
      icon: Bot,
      hasDropdown: true,
      dropdownKey: 'volume',
      subItems: [
        { key: 'volume_bot', label: 'Micro-Trading Bot' },
        { key: 'volume_bot', label: 'Bundler Volume' },
        { key: 'volume_bot', label: 'Multi-Wallet Swapper' },
      ],
    },
    { key: 'holders_maker', label: 'Holders Maker', icon: Users },
    { key: 'reaction_booster', label: 'Reaction Booster', icon: Rocket },
    { key: 'launchlab', label: 'Launchlab', icon: FlaskConical },
    { key: 'token_hub', label: 'Token Hub', icon: Coins },
    { key: 'token_burn', label: 'Token Burn', icon: Flame },
    { key: 'bulk_sender', label: 'Bulk Sender', icon: Send },
    { key: 'update_metadata', label: 'Update Token Metadata', icon: FileEdit },
    {
      key: 'create_token',
      label: 'Create Token Pro',
      icon: Sparkles,
      hasDropdown: true,
      dropdownKey: 'createToken',
      subItems: [
        { key: 'create_token', label: 'Standard SPL Token' },
        { key: 'create_token', label: 'Token-2022 Tax Token' },
        { key: 'create_token', label: 'Pump.fun Fair Launch' },
      ],
    },
    { key: 'create_pool', label: 'Create Liquidity Pool', icon: Droplets, highlight: true },
    {
      key: 'manage_liquidity',
      label: 'Manage Liquidity',
      icon: Layers,
      hasDropdown: true,
      dropdownKey: 'manageLiquidity',
      subItems: [
        { key: 'manage_liquidity', label: 'Add / Remove LP' },
        { key: 'manage_liquidity', label: 'Burn LP Tokens' },
        { key: 'manage_liquidity', label: 'Harvest AMM Fees' },
      ],
    },
    { key: 'liquidity_simulator', label: 'Liquidity Simulator', icon: BarChart3 },
    {
      key: 'revoke_authorities',
      label: 'Revoke Authorities',
      icon: ShieldAlert,
      hasDropdown: true,
      dropdownKey: 'revoke',
      subItems: [
        { key: 'revoke_authorities', label: 'Revoke Freeze' },
        { key: 'revoke_authorities', label: 'Revoke Mint' },
        { key: 'revoke_authorities', label: 'Revoke Update' },
      ],
    },
    { key: 'fast_swap', label: 'Fast Swap', icon: ArrowLeftRight },
    { key: 'pump_flywheel', label: 'Pump Mechanisms', icon: Zap },
  ];

  return (
    <aside className="w-64 border-r border-[#161c2b] bg-[#07090f] flex flex-col shrink-0 min-h-[calc(100vh-4rem)] p-3 select-none">
      <div className="space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.key;
          const isDropdownOpen = item.dropdownKey ? openDropdowns[item.dropdownKey] : false;

          return (
            <div key={item.label} className="space-y-0.5">
              <div
                onClick={() => {
                  if (item.hasDropdown) {
                    toggleDropdown(item.dropdownKey!);
                  }
                  onNavigate(item.key as NavItemKey);
                }}
                className={`flex items-center justify-between px-3 py-2.5 rounded-xl cursor-pointer text-xs font-mono transition-all ${
                  isActive
                    ? item.key === 'blank_balance'
                      ? 'bg-[#1a1708] text-[#ffd60a] font-bold border border-[#ffd60a]/50 shadow-md shadow-yellow-950/30'
                      : item.key === 'hot_wallets'
                      ? 'bg-[#041a13] text-emerald-400 font-bold border border-emerald-500/50 shadow-md shadow-emerald-950/30'
                      : item.key === 'create_pool'
                      ? 'bg-[#0b1424] text-white font-bold border border-[#162744] shadow-md shadow-cyan-950/20'
                      : 'bg-[#0f172a] text-[#38bdf8] font-bold border border-[#1e293b] shadow-sm'
                    : item.key === 'blank_balance'
                    ? 'text-[#ffd60a]/80 hover:text-[#ffd60a] hover:bg-[#141208]'
                    : item.key === 'hot_wallets'
                    ? 'text-emerald-400/90 hover:text-emerald-300 hover:bg-[#061e16]'
                    : 'text-[#8a93a8] hover:text-white hover:bg-[#0c0f18]'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive
                        ? item.key === 'blank_balance'
                          ? 'text-[#ffd60a]'
                          : item.key === 'hot_wallets'
                          ? 'text-emerald-400'
                          : item.key === 'create_pool'
                          ? 'text-emerald-400'
                          : 'text-[#38bdf8]'
                        : item.key === 'blank_balance'
                        ? 'text-[#ffd60a]'
                        : item.key === 'hot_wallets'
                        ? 'text-emerald-400'
                        : 'text-[#64748b]'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                  {(item as any).badge && (
                    <span
                      className={`text-[8px] font-mono px-1.5 py-0.5 rounded border font-extrabold uppercase shrink-0 ${(item as any).badgeClass || 'bg-cyan-500/20 text-cyan-400 border-cyan-500/40'}`}
                    >
                      {(item as any).badge}
                    </span>
                  )}
                </div>

                {item.hasDropdown && (
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleDropdown(item.dropdownKey!);
                    }}
                    className="text-[#64748b] hover:text-white p-0.5"
                  >
                    {isDropdownOpen ? (
                      <ChevronDown className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5" />
                    )}
                  </span>
                )}
              </div>

              {/* Submenu items if dropdown expanded */}
              {item.hasDropdown && isDropdownOpen && item.subItems && (
                <div className="pl-8 pr-2 py-1 space-y-1 border-l border-[#161f33] ml-4 my-0.5">
                  {item.subItems.map((sub, i) => (
                    <div
                      key={i}
                      onClick={() => onNavigate(sub.key as NavItemKey)}
                      className="px-2 py-1 rounded text-[11px] font-mono text-[#64748b] hover:text-cyan-300 hover:bg-[#0f1422] cursor-pointer transition-colors"
                    >
                      {sub.label}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {/* OMEGA Operator Suite Section */}
        <div className="pt-3 mt-2 border-t border-[#161f33] space-y-1">
          <div className="px-3 py-1 text-[10px] font-mono font-bold text-[#ffd60a] uppercase tracking-wider flex items-center justify-between">
            <span>OMEGA OPERATOR</span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#ffd60a] animate-pulse"></span>
          </div>

          {[
            { key: 'operator_command', label: 'Command HUD', icon: LayoutGrid },
            { key: 'operator_ai_taskforce', label: 'Argon 4 AI Task Force (5 Models)', icon: Brain },
            { key: 'operator_truth', label: 'Economic Truth', icon: ShieldAlert },
            { key: 'operator_opportunities', label: 'Opportunity Engine', icon: Sparkles },
            { key: 'operator_x402', label: 'x402 Products', icon: Bot },
            { key: 'operator_compounding', label: 'Compounding', icon: Layers },
            { key: 'operator_syndicate', label: 'Syndicate Wallets', icon: Users },
            { key: 'operator_agents', label: '21-Agent Matrix', icon: Bot },
            { key: 'operator_jarvis', label: 'JARVIS AI', icon: Sparkles },
            { key: 'operator_ledger', label: 'Tx Ledger', icon: BarChart3 },
          ].map((op) => {
            const OpIcon = op.icon;
            const isOpActive = activeTab === op.key;
            return (
              <div
                key={op.key}
                onClick={() => onNavigate(op.key as NavItemKey)}
                className={`flex items-center gap-2.5 px-3 py-2 rounded-xl cursor-pointer text-xs font-mono transition-all ${
                  isOpActive
                    ? 'bg-[#ffd60a]/10 text-[#ffd60a] font-bold border border-[#ffd60a]/30 shadow-sm'
                    : 'text-[#8a93a8] hover:text-[#ffd60a] hover:bg-[#0c0f18]'
                }`}
              >
                <OpIcon className={`w-3.5 h-3.5 ${isOpActive ? 'text-[#ffd60a]' : 'text-[#64748b]'}`} />
                <span className="truncate">{op.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Status Box */}
      <div className="mt-auto pt-4 border-t border-[#161c2b] text-[10px] font-mono text-[#64748b] px-2 space-y-1">
        <div className="flex items-center justify-between">
          <span>RAYDIUM PROTOCOL</span>
          <span className="text-emerald-400 font-bold">ONLINE</span>
        </div>
        <div className="flex items-center justify-between">
          <span>AUTONOMOUS ENGINE</span>
          <span className="text-cyan-400 font-bold">RUNNING</span>
        </div>
      </div>
    </aside>
  );
};
