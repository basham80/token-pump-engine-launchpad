import React, { useState } from 'react';
import { VolumeBotConfig, RaydiumPool } from '../../types';
import {
  Bot,
  TrendingUp,
  Play,
  Square,
  Zap,
  Activity,
  Sliders,
  Clock,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  CheckCircle2,
} from 'lucide-react';

interface VolumeBotViewProps {
  config: VolumeBotConfig;
  pools: RaydiumPool[];
  onUpdateConfig: (updates: Partial<VolumeBotConfig>) => void;
  onTriggerBurst: () => void;
}

export const VolumeBotView: React.FC<VolumeBotViewProps> = ({
  config,
  pools,
  onUpdateConfig,
  onTriggerBurst,
}) => {
  const [mode, setMode] = useState<'MICRO' | 'BUNDLER' | 'MULTI_WALLET' | 'SCHEDULED'>(config.mode);
  const [targetVolume, setTargetVolume] = useState<number>(config.targetVolume24hSol);
  const [minTrade, setMinTrade] = useState<number>(config.minTradeSol);
  const [maxTrade, setMaxTrade] = useState<number>(config.maxTradeSol);
  const [interval, setIntervalVal] = useState<number>(config.intervalSeconds);
  const [buySellRatio, setBuySellRatio] = useState<number>(config.buySellRatioPct);
  const [slippage, setSlippage] = useState<number>(config.slippagePct);
  const [saving, setSaving] = useState<boolean>(false);
  const [savedNotice, setSavedNotice] = useState<boolean>(false);

  const handleSave = () => {
    setSaving(true);
    onUpdateConfig({
      mode,
      targetVolume24hSol: targetVolume,
      minTradeSol: minTrade,
      maxTradeSol: maxTrade,
      intervalSeconds: interval,
      buySellRatioPct: buySellRatio,
      slippagePct: slippage,
    });
    setTimeout(() => {
      setSaving(false);
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 3000);
    }, 400);
  };

  const handleToggleRunning = () => {
    onUpdateConfig({ enabled: !config.enabled });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-mono text-emerald-400 font-bold uppercase">
              Automated Market Maker
            </span>
            <span className="text-xs text-[#8a93a8] font-mono">Raydium AMM V4 & CPMM</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Volume Bot & Organic Market Maker
          </h1>
          <p className="text-sm text-[#8a93a8] mt-1">
            Simulate organic retail trading volume, boost DEXScreener and Birdeye trending algorithms, and attract real crypto traders.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onTriggerBurst}
            className="px-4 py-2.5 rounded-xl bg-[#141a29] hover:bg-[#1e263c] border border-[#232c45] text-cyan-300 text-xs font-mono font-bold transition-all flex items-center gap-2"
          >
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>Instant 0.5 SOL Burst</span>
          </button>

          <button
            onClick={handleToggleRunning}
            className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold transition-all flex items-center gap-2 ${
              config.enabled
                ? 'bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40'
                : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-950/50'
            }`}
          >
            {config.enabled ? (
              <>
                <Square className="w-3.5 h-3.5 fill-red-400 text-red-400" />
                <span>Stop Volume Bot</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-black text-black" />
                <span>Start Volume Bot</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Mode Switcher */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { id: 'MICRO', label: 'Micro-Trading Bot', desc: 'Randomized small buys/sells every 15-30s' },
          { id: 'BUNDLER', label: 'Bundler Volume', desc: 'Simultaneous multi-wallet buy/sell blocks' },
          { id: 'MULTI_WALLET', label: 'Multi-Wallet Swapper', desc: 'Rotates through 6+ syndicate addresses' },
          { id: 'SCHEDULED', label: 'Scheduled Volume', desc: 'Maintains steady $15k-$50k 24h volume target' },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id as any)}
            className={`p-4 rounded-xl border text-left transition-all ${
              mode === m.id
                ? 'bg-[#12192b] border-[#0284c7] text-white shadow-lg shadow-cyan-950/30'
                : 'bg-[#0b0e17] border-[#1b2234] text-[#8a93a8] hover:border-[#2b3856]'
            }`}
          >
            <div className="text-xs font-bold font-mono text-white">{m.label}</div>
            <div className="text-[11px] text-[#8a93a8] mt-1">{m.desc}</div>
          </button>
        ))}
      </div>

      {/* Control Parameters Card */}
      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex items-center justify-between border-b border-[#1b2234] pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white font-mono uppercase">
              Trading Algorithm Parameters
            </h3>
          </div>
          {savedNotice && (
            <span className="text-xs text-emerald-400 font-mono flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Settings updated!
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div>
            <label className="text-[#8a93a8] block mb-1.5">Target 24h Volume (SOL)</label>
            <input
              type="number"
              step="0.5"
              value={targetVolume}
              onChange={(e) => setTargetVolume(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1.5">Trade Size Range (Min - Max SOL)</label>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                step="0.005"
                value={minTrade}
                onChange={(e) => setMinTrade(parseFloat(e.target.value) || 0)}
                placeholder="Min"
                className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
              />
              <input
                type="number"
                step="0.005"
                value={maxTrade}
                onChange={(e) => setMaxTrade(parseFloat(e.target.value) || 0)}
                placeholder="Max"
                className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
              />
            </div>
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1.5">Trade Execution Interval (Seconds)</label>
            <input
              type="number"
              step="1"
              value={interval}
              onChange={(e) => setIntervalVal(parseInt(e.target.value, 10) || 15)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1.5">
              Buy / Sell Bias ({buySellRatio}% Buys / {100 - buySellRatio}% Sells)
            </label>
            <input
              type="range"
              min="40"
              max="80"
              value={buySellRatio}
              onChange={(e) => setBuySellRatio(parseInt(e.target.value, 10))}
              className="w-full accent-cyan-500"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1.5">Max Slippage Tolerance (%)</label>
            <input
              type="number"
              step="0.1"
              value={slippage}
              onChange={(e) => setSlippage(parseFloat(e.target.value) || 1.0)}
              className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none focus:border-[#0284c7]"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full py-2.5 rounded-lg bg-[#0284c7] hover:bg-[#0369a1] text-white font-bold transition-colors"
            >
              Save Configuration
            </button>
          </div>
        </div>
      </div>

      {/* Live Trades Stream Table */}
      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
              Live Raydium Market Making Trades Feed
            </h3>
          </div>
          <span className="text-xs text-[#8a93a8] font-mono">
            {config.recentTrades.length} recent executions
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1b2234] text-[#8a93a8]">
                <th className="pb-3 font-semibold">TIME</th>
                <th className="pb-3 font-semibold">TYPE</th>
                <th className="pb-3 font-semibold">WALLET</th>
                <th className="pb-3 font-semibold">SOL AMOUNT</th>
                <th className="pb-3 font-semibold">TOKENS RECEIVED</th>
                <th className="pb-3 font-semibold">PRICE (SOL)</th>
                <th className="pb-3 font-semibold text-right">TX SIGNATURE</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#161c2b]">
              {config.recentTrades.map((t, idx) => (
                <tr key={`${t.id || 'trade'}-${idx}`} className="hover:bg-[#111624] transition-colors">
                  <td className="py-2.5 text-[#8a93a8]">
                    {new Date(t.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-2.5">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        t.type === 'BUY'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-500/15 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {t.type}
                    </span>
                  </td>
                  <td className="py-2.5 text-white">{t.walletLabel}</td>
                  <td className="py-2.5 text-white font-bold">{t.amountSol.toFixed(4)} SOL</td>
                  <td className="py-2.5 text-cyan-300">{t.tokensAmount.toLocaleString()}</td>
                  <td className="py-2.5 text-[#8a93a8]">{t.priceSol.toFixed(10)}</td>
                  <td className="py-2.5 text-right text-emerald-400 font-mono">
                    <a
                      href={`https://solscan.io/tx/${t.txSignature}`}
                      target="_blank"
                      rel="noreferrer"
                      className="hover:underline flex items-center justify-end gap-1"
                    >
                      <span>{t.txSignature.slice(0, 8)}...</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
