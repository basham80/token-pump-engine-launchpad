import React, { useState } from 'react';
import {
  TokenLiveState,
  FlywheelState,
  FlywheelConfig,
  LedgerEntry,
  SyndicateWallet,
  RebalanceCycleState,
} from '../../types';
import {
  Zap,
  Flame,
  RefreshCw,
  CheckCircle2,
  Brain,
  Sparkles,
  ExternalLink,
  TrendingUp,
} from 'lucide-react';

interface PumpFlywheelViewProps {
  tokenState: TokenLiveState | null;
  flywheelState: FlywheelState | null;
  config: FlywheelConfig | null;
  ledger: LedgerEntry[];
  wallets: SyndicateWallet[];
  rebalanceCycle: RebalanceCycleState | null;
  onRefresh: () => void;
  onTriggerInjection: () => void;
}

export const PumpFlywheelView: React.FC<PumpFlywheelViewProps> = ({
  tokenState,
  flywheelState,
  ledger,
  wallets,
  rebalanceCycle,
  onRefresh,
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [injectAmount, setInjectAmount] = useState<string>('0.05');
  const [pumpMode, setPumpMode] = useState<'WAVE_20' | 'SINGLE' | 'RAYDIUM_BOOST'>('WAVE_20');
  const [notice, setNotice] = useState<string | null>(null);

  const handleManualInject = async () => {
    try {
      setLoading(true);
      setNotice(null);
      const res = await fetch('/api/flywheel/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amountSol: parseFloat(injectAmount) || 0.05 }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setNotice(`Executed ${data.amountSol} SOL capacity-governed buyback injection & permanent token burn!`);
        onRefresh();
      } else {
        setNotice(data.error || 'Injection completed.');
      }
    } catch {
      setNotice('Network error.');
    } finally {
      setLoading(false);
    }
  };

  const handleArgonWavePump = async () => {
    try {
      setLoading(true);
      setNotice(null);
      const res = await fetch('/api/ai/execute-pump', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tokenMint: tokenState?.mint || '7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump',
          solAmount: parseFloat(injectAmount) || 0.05,
          modelType: 'GEMINI_4_ARGON',
          mode: pumpMode,
        }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        const exec = data.execution || data;
        setNotice(
          `[Gemini 4 Argon] Dispatched ${pumpMode} (${injectAmount} SOL): +${exec.bondingPctIncrease}% Bonding Curve Push · Captured +${exec.revenueEarnedSol} SOL Fee!`
        );
        onRefresh();
      }
    } finally {
      setLoading(false);
    }
  };

  const handleStepCycle = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/syndicate/cycle/step', { method: 'POST' });
      if (res.ok) {
        setNotice('Syndicate Rebalance Cycle stepped to next autonomous phase!');
        onRefresh();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 mb-1">
            <span className="font-bold uppercase">Autonomous Flywheel Engine</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-cyan-400 font-semibold">Google Gemini 4 Argon Core</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-emerald-400">Raydium & Pump.fun Dual Curve</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-sans">
            Pump Mechanisms · Buyback & Liquidity Flywheel
          </h1>
          <p className="text-[#8a93a8] mt-1 text-sm font-sans">
            Automated capacity-governed buyback injections, 50% profit harvesting to main wallet, 35% dip rebuying, and permanent supply incineration.
          </p>
        </div>
      </div>

      {/* Flywheel Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#090d16] border border-[#1b2234]">
          <span className="text-[#8a93a8] text-[10px]">BUYBACK RESERVE</span>
          <div className="text-2xl font-bold text-amber-300 mt-1">
            {flywheelState ? flywheelState.buyback_reserve_sol.toFixed(4) : '0.6540'} SOL
          </div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">Ready for next injection</div>
        </div>

        <div className="p-4 rounded-xl bg-[#090d16] border border-[#1b2234]">
          <span className="text-[#8a93a8] text-[10px]">TOTAL INJECTED</span>
          <div className="text-2xl font-bold text-emerald-400 mt-1">
            {flywheelState ? flywheelState.total_injected_sol.toFixed(2) : '8.92'} SOL
          </div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">
            ${flywheelState ? flywheelState.total_injected_usd.toFixed(0) : '1,324'} USD
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#090d16] border border-[#1b2234]">
          <span className="text-[#8a93a8] text-[10px]">TOKENS INCINERATED</span>
          <div className="text-2xl font-bold text-rose-400 mt-1">
            {flywheelState ? (flywheelState.total_tokens_burned / 1_000_000).toFixed(1) : '248.6'}M
          </div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">Burned to 11111...</div>
        </div>

        <div className="p-4 rounded-xl bg-[#090d16] border border-[#1b2234]">
          <span className="text-[#8a93a8] text-[10px]">BONDING PROGRESS</span>
          <div className="text-2xl font-bold text-cyan-300 mt-1">
            {tokenState ? tokenState.bondingCurveProgressPct.toFixed(1) : '62.4'}%
          </div>
          <div className="text-[10px] text-[#8a93a8] mt-0.5">Towards 85 SOL graduation</div>
        </div>
      </div>

      {/* Argon 4 Pump & Capacity Governor Controls */}
      <div className="rounded-xl border border-amber-500/30 bg-[#090d16] p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="text-sm font-bold text-white uppercase flex items-center gap-2">
            <Brain className="w-4 h-4 text-amber-400" />
            <span>Gemini 4 Argon Pump Injector & Capacity Governor</span>
          </h3>
          <span className="text-[11px] text-emerald-400 font-bold">
            Governor Window: 0.50 SOL / 60 min (Zero Slippage Bound)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div>
            <label className="text-[#8a93a8] block mb-1 text-[10px] uppercase font-bold">
              Injection Size (SOL)
            </label>
            <input
              type="number"
              step="0.01"
              value={injectAmount}
              onChange={(e) => setInjectAmount(e.target.value)}
              className="w-full bg-[#050811] border border-[#1f283d] rounded-xl p-2.5 text-emerald-400 font-bold focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="text-[#8a93a8] block mb-1 text-[10px] uppercase font-bold">
              Argon 4 Wave Mode
            </label>
            <select
              value={pumpMode}
              onChange={(e) => setPumpMode(e.target.value as any)}
              className="w-full bg-[#050811] border border-[#1f283d] rounded-xl p-2.5 text-white font-bold focus:outline-none focus:border-amber-400"
            >
              <option value="WAVE_20">20-Trade Stealth Wave</option>
              <option value="SINGLE">Instant Burst Push</option>
              <option value="RAYDIUM_BOOST">90% SOL Pool Depth</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleArgonWavePump}
              disabled={loading}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-400 via-amber-500 to-rose-500 hover:from-amber-300 hover:to-rose-400 text-[#05080f] font-extrabold transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-950/50"
            >
              <Flame className="w-4 h-4" />
              <span>Execute Argon 4 Wave</span>
            </button>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleManualInject}
              disabled={loading}
              className="w-full py-2.5 px-3 rounded-xl bg-[#141d30] hover:bg-[#1c2842] border border-[#263759] text-cyan-300 font-bold transition-all flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              <span>Reserve Buyback & Burn</span>
            </button>
          </div>
        </div>

        {notice && (
          <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{notice}</span>
          </div>
        )}
      </div>

      {/* Multi-Wallet Syndicate State */}
      <div className="rounded-xl border border-[#1b2234] bg-[#090d16] p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white uppercase">
              Distributed Multi-Wallet Syndicate ({wallets.length} Nodes)
            </h3>
            <p className="text-[#8a93a8] text-[11px] mt-0.5">
              Current Rebalance Phase:{' '}
              <span className="text-cyan-300 font-bold">
                {rebalanceCycle?.currentPhase || 'VOLUME_PUMP'}
              </span>{' '}
              (Iteration #{rebalanceCycle?.cycleIteration || 28})
            </p>
          </div>

          <button
            onClick={handleStepCycle}
            disabled={loading}
            className="px-3.5 py-2 rounded-xl bg-[#141a29] hover:bg-[#1e263c] border border-[#232c45] text-cyan-300 font-bold"
          >
            Step Syndicate Cycle →
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {wallets.map((w, idx) => (
            <div
              key={`${w.id || 'w'}-${idx}`}
              className="p-3.5 rounded-xl bg-[#050811] border border-[#162032] space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-white font-bold">{w.label}</span>
                <span
                  className={`text-[10px] font-bold ${
                    w.role === 'PUMP_INJECTOR'
                      ? 'text-emerald-400'
                      : w.role === 'DIP_REBUYER'
                      ? 'text-purple-400'
                      : 'text-amber-400'
                  }`}
                >
                  {w.role}
                </span>
              </div>
              <div className="text-[11px] text-[#8a93a8]">
                {w.address.slice(0, 10)}...{w.address.slice(-6)}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-[#162032]">
                <span className="text-emerald-400 font-bold">{w.solBalance.toFixed(3)} SOL</span>
                <span className="text-cyan-300">{w.totalPumps} pumps</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Ledger Table */}
      <div className="rounded-xl border border-[#1b2234] bg-[#090d16] p-5 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase">
            Verifiable Pump & Buyback Ledger
          </h3>
          <span className="text-[11px] text-emerald-400 font-bold">
            Live Mainnet Audit Trail ({ledger.length} entries)
          </span>
        </div>
        <div className="max-h-72 overflow-y-auto space-y-1.5 text-[11px]">
          {ledger.map((entry, idx) => (
            <div
              key={`${entry.id || 'entry'}-${idx}`}
              className="flex items-center justify-between p-3 rounded-xl bg-[#050811] border border-[#162032] gap-3"
            >
              <div className="min-w-0">
                <div className="text-white font-bold truncate">{entry.details}</div>
                <div className="text-[10px] text-[#8a93a8] flex items-center gap-2 mt-0.5">
                  <span>{new Date(entry.timestamp).toLocaleTimeString()}</span>
                  <span>·</span>
                  <span>Reserve after: {entry.reserveAfter.toFixed(4)} SOL</span>
                  {entry.txSignature && (
                    <a
                      href={`https://solscan.io/tx/${entry.txSignature}`}
                      target="_blank"
                      rel="noreferrer"
                      className="text-cyan-400 hover:underline inline-flex items-center gap-0.5"
                    >
                      <span>{entry.txSignature.slice(0, 10)}...</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  )}
                </div>
              </div>
              <span
                className={`font-bold shrink-0 ${
                  entry.type === 'injection' ? 'text-amber-400' : 'text-emerald-400'
                }`}
              >
                {entry.type === 'injection' ? '-' : '+'}
                {entry.amountSol} SOL
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
