import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { LivePoolInfo, LivePoolStatus, LivePoolsResponse, LivePoolToken, RaydiumPool } from '../../types';
import {
  AlertCircle,
  AlertTriangle,
  Brain,
  Coins,
  Droplets,
  ExternalLink,
  Eye,
  Flame,
  Lock,
  Minus,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Wallet,
  XCircle,
} from 'lucide-react';

/**
 * Manage Liquidity — live edition.
 *
 * Pool figures come from GET /api/raydium/pools/live (Solana mainnet RPC + Raydium API v3),
 * and the position is the connected wallet's real LP balance. Nothing on this screen is read
 * from the app's stored pool records except the list of pool IDs to check.
 * Liquidity actions open Raydium, where the user's wallet signs real transactions.
 */

interface ManageLiquidityViewProps {
  pools: RaydiumPool[];
  walletAddress: string;
  onRefresh: () => void;
  onNavigateToCreate: () => void;
}

type ActionTab = 'ADD' | 'REMOVE' | 'BURN' | 'LOCK' | 'FEES';

const LIVE_REFRESH_MS = 30_000;
const OFF_CHAIN: LivePoolStatus[] = ['NOT_FOUND', 'NOT_A_POOL', 'INVALID_ID'];

const STATUS_CHIP: Record<LivePoolStatus, { label: string; cls: string }> = {
  LIVE: { label: 'Live on-chain', cls: 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300' },
  ONCHAIN_NO_STATS: { label: 'On-chain · no stats', cls: 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300' },
  NOT_FOUND: { label: 'Not on-chain', cls: 'bg-rose-500/10 border-rose-500/40 text-rose-300' },
  NOT_A_POOL: { label: 'Not a pool', cls: 'bg-rose-500/10 border-rose-500/40 text-rose-300' },
  INVALID_ID: { label: 'Invalid ID', cls: 'bg-rose-500/10 border-rose-500/40 text-rose-300' },
  UNVERIFIED: { label: 'Unverified', cls: 'bg-slate-500/10 border-slate-500/40 text-slate-300' },
};

const KIND_LABEL: Record<string, string> = { AMM_V4: 'AMM v4', CPMM: 'CPMM', CLMM: 'CLMM', OTHER: 'pool' };

// -------------------------------------------------------------
// Formatting
// -------------------------------------------------------------

const shortAddr = (a: string) => (a && a.length > 12 ? `${a.slice(0, 4)}…${a.slice(-4)}` : a || '—');

function fmtAmount(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  if (n === 0) return '0';
  const abs = Math.abs(n);
  if (abs >= 1e9) return `${(n / 1e9).toLocaleString(undefined, { maximumFractionDigits: 2 })}B`;
  if (abs >= 1e6) return `${(n / 1e6).toLocaleString(undefined, { maximumFractionDigits: 2 })}M`;
  if (abs >= 1000) return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
  if (abs >= 1) return n.toLocaleString(undefined, { maximumFractionDigits: 4 });
  if (abs >= 1e-6) return n.toLocaleString(undefined, { maximumSignificantDigits: 4 });
  return n.toExponential(2);
}

function fmtUsd(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  if (n === 0) return '$0';
  const abs = Math.abs(n);
  if (abs < 0.01) return '<$0.01';
  if (abs >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  return `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtPct(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return '—';
  if (n === 0) return '0%';
  if (Math.abs(n) < 0.0001) return '<0.0001%';
  return `${n.toLocaleString(undefined, { maximumFractionDigits: 4 })}%`;
}

const timeOf = (ts: number) => new Date(ts).toLocaleTimeString();

// -------------------------------------------------------------
// Small presentational pieces
// -------------------------------------------------------------

const TokenLogo: React.FC<{ src?: string; symbol: string; size: string }> = ({ src, symbol, size }) => {
  const [broken, setBroken] = useState(false);
  if (!src || broken) {
    return (
      <span
        className={`${size} rounded-full bg-[#1b2436] border border-[#232c45] text-[9px] font-bold text-[#8a93a8] flex items-center justify-center shrink-0`}
      >
        {symbol.slice(0, 2).toUpperCase()}
      </span>
    );
  }
  return (
    <img
      src={src}
      alt={symbol}
      onError={() => setBroken(true)}
      className={`${size} rounded-full object-cover border border-[#232c45] shrink-0 bg-[#0b0e17]`}
    />
  );
};

interface PairView {
  a: string;
  b: string;
  logoA?: string;
  logoB?: string;
  fromChain: boolean;
}

function logoFor(t: LivePoolToken, p: RaydiumPool): string | undefined {
  if (t.logo) return t.logo;
  if (t.mint === p.baseToken.mint || t.symbol === p.baseToken.symbol) return p.baseToken.logo;
  if (t.mint === p.quoteToken.mint || t.symbol === p.quoteToken.symbol) return p.quoteToken.logo;
  return undefined;
}

function pairOf(p: RaydiumPool, info?: LivePoolInfo): PairView {
  if (info?.mintA && info?.mintB) {
    return {
      a: info.mintA.symbol,
      b: info.mintB.symbol,
      logoA: logoFor(info.mintA, p),
      logoB: logoFor(info.mintB, p),
      fromChain: true,
    };
  }
  return {
    a: p.baseToken.symbol,
    b: p.quoteToken.symbol,
    logoA: p.baseToken.logo,
    logoB: p.quoteToken.logo,
    fromChain: false,
  };
}

const PairLogos: React.FC<{ pair: PairView; large?: boolean }> = ({ pair, large }) => {
  const size = large ? 'w-10 h-10' : 'w-5 h-5';
  return (
    <span className="flex items-center shrink-0">
      <TokenLogo src={pair.logoA} symbol={pair.a} size={size} />
      <span className={large ? '-ml-3' : '-ml-1.5'}>
        <TokenLogo src={pair.logoB} symbol={pair.b} size={size} />
      </span>
    </span>
  );
};

const BANNER_TONES = {
  emerald: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200',
  amber: 'bg-amber-500/10 border-amber-500/30 text-amber-200',
  rose: 'bg-rose-500/10 border-rose-500/30 text-rose-200',
  cyan: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-200',
  slate: 'bg-[#0e1422] border-[#1b263d] text-[#a3b0c6]',
} as const;

const Banner: React.FC<{
  tone: keyof typeof BANNER_TONES;
  icon: React.ComponentType<{ className?: string }>;
  title?: string;
  children: React.ReactNode;
}> = ({ tone, icon: Icon, title, children }) => (
  <div className={`p-3.5 rounded-xl border text-xs font-mono flex items-start gap-2.5 leading-relaxed ${BANNER_TONES[tone]}`}>
    <Icon className="w-4 h-4 shrink-0 mt-0.5" />
    <div>
      {title && <div className="font-bold text-white mb-0.5">{title}</div>}
      <div>{children}</div>
    </div>
  </div>
);

const Stat: React.FC<{ label: string; value: React.ReactNode; sub?: React.ReactNode; valueClass?: string }> = ({
  label,
  value,
  sub,
  valueClass = 'text-white',
}) => (
  <div className="p-3.5 rounded-xl bg-[#060911] border border-[#162032] min-w-0">
    <span className="text-[#6b7c96] text-[10px] uppercase">{label}</span>
    <div className={`${valueClass} font-bold text-sm mt-1 truncate`}>{value}</div>
    {sub && <div className="text-[10px] text-[#6b7c96] mt-0.5 truncate">{sub}</div>}
  </div>
);

function raydiumLinks(info: LivePoolInfo) {
  const id = encodeURIComponent(info.poolId);
  const portfolio = 'https://raydium.io/portfolio/';
  if (info.poolKind === 'CLMM') {
    return { add: `https://raydium.io/clmm/create-position/?pool_id=${id}`, remove: portfolio, portfolio };
  }
  return {
    add: `https://raydium.io/liquidity/increase/?mode=add&pool_id=${id}`,
    remove: `https://raydium.io/liquidity/increase/?mode=remove&pool_id=${id}`,
    portfolio,
  };
}

// -------------------------------------------------------------
// View
// -------------------------------------------------------------

export const ManageLiquidityView: React.FC<ManageLiquidityViewProps> = ({
  pools,
  walletAddress,
  onRefresh,
  onNavigateToCreate,
}) => {
  const [selectedPoolId, setSelectedPoolId] = useState<string>(pools[0]?.poolId || '');
  const [actionTab, setActionTab] = useState<ActionTab>('ADD');

  const [live, setLive] = useState<LivePoolsResponse | null>(null);
  const [liveLoading, setLiveLoading] = useState<boolean>(false);
  const [liveError, setLiveError] = useState<string | null>(null);
  const requestSeq = useRef(0);

  const [argonAnalysis, setArgonAnalysis] = useState<string>('');
  const [analyzingPool, setAnalyzingPool] = useState<boolean>(false);

  // A stable key so the 5-second pool polling in App doesn't trigger a new chain lookup each time.
  const poolIdsKey = useMemo(
    () => Array.from(new Set(pools.map((p) => p.poolId).filter(Boolean))).join(','),
    [pools]
  );

  useEffect(() => {
    if (pools.length > 0 && !pools.some((p) => p.poolId === selectedPoolId)) {
      setSelectedPoolId(pools[0].poolId);
    }
  }, [pools, selectedPoolId]);

  // A different wallet means different positions: drop the previous answer rather than show it.
  useEffect(() => {
    setLive(null);
    setLiveError(null);
  }, [walletAddress]);

  useEffect(() => {
    setArgonAnalysis('');
  }, [selectedPoolId, walletAddress]);

  const loadLive = useCallback(async () => {
    if (!poolIdsKey) return;
    const seq = ++requestSeq.current;
    setLiveLoading(true);
    try {
      const qs = new URLSearchParams({ ids: poolIdsKey });
      if (walletAddress) qs.set('wallet', walletAddress);
      const res = await fetch(`/api/raydium/pools/live?${qs.toString()}`);
      const data = (await res.json().catch(() => null)) as LivePoolsResponse | null;
      if (seq !== requestSeq.current) return;
      if (!res.ok || !data || !Array.isArray(data.pools)) {
        throw new Error(data?.errors?.[0] || `request failed (HTTP ${res.status})`);
      }
      setLive(data);
      setLiveError(null);
    } catch (e: any) {
      if (seq !== requestSeq.current) return;
      setLiveError(e?.message || 'request failed');
    } finally {
      if (seq === requestSeq.current) setLiveLoading(false);
    }
  }, [poolIdsKey, walletAddress]);

  useEffect(() => {
    loadLive();
    const timer = setInterval(loadLive, LIVE_REFRESH_MS);
    return () => clearInterval(timer);
  }, [loadLive]);

  const liveById = useMemo(
    () => new Map((live?.pools || []).map((p) => [p.poolId, p] as const)),
    [live]
  );

  const counts = useMemo(() => {
    if (!live) return null;
    return {
      onChain: live.pools.filter((p) => p.status === 'LIVE' || p.status === 'ONCHAIN_NO_STATS').length,
      offChain: live.pools.filter((p) => OFF_CHAIN.includes(p.status)).length,
      withLp: live.pools.filter((p) => (p.walletLpBalance ?? 0) > 0).length,
    };
  }, [live]);

  const pool = pools.find((p) => p.poolId === selectedPoolId) || pools[0];
  const info = pool ? liveById.get(pool.poolId) : undefined;

  const handleRefresh = () => {
    loadLive();
    onRefresh();
  };

  if (!pool) {
    return (
      <div className="max-w-4xl mx-auto p-12 text-center rounded-2xl bg-[#0b0e17] border border-[#1b2234]">
        <Droplets className="w-12 h-12 text-cyan-400 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-white font-mono">No Raydium Pools Tracked</h3>
        <p className="text-xs text-[#8a93a8] mt-1 max-w-md mx-auto">
          Pools you track here are checked live against Solana mainnet and Raydium, together with your wallet's LP
          position.
        </p>
        <button
          onClick={onNavigateToCreate}
          className="mt-4 px-4 py-2 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] text-white text-xs font-mono font-bold"
        >
          Create Solana Liquidity Pool →
        </button>
      </div>
    );
  }

  const pair = pairOf(pool, info);
  const isLive = info?.status === 'LIVE';
  const isClmm = info?.poolKind === 'CLMM';
  const lpKnown = info?.walletLpBalance !== null && info?.walletLpBalance !== undefined;
  const lp = info?.walletLpBalance ?? 0;
  const links = info ? raydiumLinks(info) : null;
  const myFees24h =
    info && info.fees24hUsd !== null && info.walletSharePct !== null
      ? (info.walletSharePct / 100) * info.fees24hUsd
      : null;

  // ---------- position banner ----------
  const renderPositionBanner = () => {
    if (!info) {
      return liveError ? (
        <Banner tone="slate" icon={AlertCircle}>
          Couldn't read this pool live ({liveError}). No figures are shown rather than guessing.
        </Banner>
      ) : (
        <Banner tone="slate" icon={RefreshCw}>
          Checking Solana mainnet and Raydium for this pool…
        </Banner>
      );
    }
    if (OFF_CHAIN.includes(info.status)) {
      return (
        <Banner tone="rose" icon={XCircle} title="Not a real on-chain pool">
          {info.statusDetail}
        </Banner>
      );
    }
    if (!isLive) {
      return (
        <Banner tone="slate" icon={AlertCircle}>
          {info.statusDetail}
        </Banner>
      );
    }
    if (isClmm) {
      return (
        <Banner tone="cyan" icon={Eye} title="Concentrated-liquidity pool">
          Positions in CLMM pools are NFTs, which this panel doesn't read yet. Check positions for{' '}
          {shortAddr(walletAddress)} on Raydium's portfolio page.
        </Banner>
      );
    }
    if (!lpKnown) {
      return (
        <Banner tone="slate" icon={AlertCircle}>
          This wallet's LP balance couldn't be read right now, so no position is shown.
        </Banner>
      );
    }
    if (lp === 0) {
      return (
        <Banner tone="amber" icon={Eye} title="Watch-only">
          Wallet {shortAddr(walletAddress)} holds 0 LP tokens for this pool, so none of its liquidity or fees belong to
          this wallet.
          {info.walletLpCheck === 'ASSOCIATED_ACCOUNT_ONLY' &&
            " (Checked the wallet's standard LP token account; this RPC doesn't allow a full token-account scan.)"}
        </Banner>
      );
    }
    return (
      <Banner tone="emerald" icon={Wallet} title="Your position">
        {fmtAmount(lp)} LP · {fmtPct(info.walletSharePct)} of the pool ≈ {fmtUsd(info.walletValueUsd)} (
        {fmtAmount(info.walletAmountA)} {pair.a} + {fmtAmount(info.walletAmountB)} {pair.b})
      </Banner>
    );
  };

  // ---------- primary action ----------
  const action: { href?: string; label: string } = (() => {
    if (!info) return { label: liveLoading ? 'Checking pool on-chain…' : 'Live data unavailable' };
    if (!isLive || !links) {
      return {
        label: OFF_CHAIN.includes(info.status)
          ? 'Unavailable: this pool is not on-chain'
          : 'Unavailable until live pool data loads',
      };
    }
    if (actionTab === 'ADD') return { href: links.add, label: 'Add liquidity on Raydium' };
    if (isClmm) return { href: links.portfolio, label: 'Manage CLMM positions on Raydium' };
    if (!lpKnown) return { href: links.portfolio, label: 'Check your positions on Raydium' };
    switch (actionTab) {
      case 'REMOVE':
        return lp > 0
          ? { href: links.remove, label: 'Withdraw on Raydium' }
          : { label: 'Nothing to withdraw: 0 LP in this wallet' };
      case 'BURN':
        return lp > 0
          ? { href: links.portfolio, label: 'Burn LP on Raydium' }
          : { label: 'Nothing to burn: 0 LP in this wallet' };
      case 'LOCK':
        return lp > 0
          ? { href: links.portfolio, label: 'Lock LP on Raydium' }
          : { label: 'Nothing to lock: 0 LP in this wallet' };
      case 'FEES':
      default:
        return lp > 0
          ? { href: links.remove, label: 'Collect fees by withdrawing on Raydium' }
          : { label: 'No fees to collect: 0 LP in this wallet' };
    }
  })();

  // ---------- Argon audit (live figures only) ----------
  const handleRunArgonPoolAudit = async () => {
    if (!info || info.status !== 'LIVE') return;
    setAnalyzingPool(true);
    setArgonAnalysis('Gemini 4 Argon is reading the live pool figures…');
    const facts = {
      pair: `${pair.a}/${pair.b}`,
      poolId: info.poolId,
      program: info.ownerProgramLabel,
      reserves: { [pair.a]: info.reserveA, [pair.b]: info.reserveB },
      priceBPerA: info.price,
      tvlUsd: info.tvlUsd,
      swapFeeRate: info.feeRate,
      volume24hUsd: info.volume24hUsd,
      fees24hUsdWholePool: info.fees24hUsd,
      lpSupply: info.lpSupply,
      lpBurnedPct: info.lpBurnPct,
      wallet: info.wallet,
      walletLpBalance: info.walletLpBalance,
      walletSharePct: info.walletSharePct,
      walletValueUsd: info.walletValueUsd,
      fetchedAt: new Date(info.fetchedAt).toISOString(),
      sources: info.sources,
    };
    try {
      const res = await fetch('/api/ai/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          engineId: 'GEMINI_4_ARGON',
          prompt:
            'Review this Raydium liquidity pool using ONLY the live figures provided (read from Solana mainnet and the Raydium API). ' +
            'Do not invent numbers; if something is not in the data, say it is unknown. Cover: liquidity depth and price impact for ' +
            'typical trade sizes, what the LP-burn percentage means for holders, and what this wallet\'s position (or lack of one) means.\n\n' +
            JSON.stringify(facts, null, 2),
          context: facts,
        }),
      });
      const data = await res.json();
      if (data?.ok && data.responseText && !data.fallback) {
        setArgonAnalysis(data.responseText);
      } else if (data?.fallback) {
        setArgonAnalysis(
          "Audit unavailable: the AI model didn't respond, and the app's built-in template text isn't shown here because it isn't an analysis of this pool."
        );
      } else {
        setArgonAnalysis(`Audit unavailable: ${data?.error || 'the AI service returned no analysis.'}`);
      }
    } catch (e: any) {
      setArgonAnalysis(`Audit unavailable: ${e?.message || 'network error'}`);
    } finally {
      setAnalyzingPool(false);
    }
  };

  const argonDefault = !info
    ? '[Waiting for live pool data]'
    : !isLive
      ? `[No live pool data]\n${info.statusDetail}\n\nNothing to audit.`
      : `[Live pool data · ${timeOf(info.fetchedAt)}]\n• Pair: ${pair.a} / ${pair.b} (${info.ownerProgramLabel || 'Raydium'})\n• Liquidity: ${fmtUsd(info.tvlUsd)} · LP burned: ${fmtPct(info.lpBurnPct)}\n• This wallet: ${
          isClmm ? 'CLMM positions not read' : lpKnown ? (lp > 0 ? `${fmtAmount(lp)} LP (${fmtPct(info.walletSharePct)})` : '0 LP (watch-only)') : 'unknown'
        }\n\nClick "Run Argon 4 Pool Audit" for an AI read of these live figures.`;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <span className="font-bold uppercase">Raydium Pools · Live On-Chain Data</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-[#8a93a8]">{pools.length} tracked</span>
            {counts && (
              <>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-emerald-400">{counts.onChain} on-chain</span>
                {counts.offChain > 0 && (
                  <>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-rose-300">{counts.offChain} not on-chain</span>
                  </>
                )}
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-amber-300">{counts.withLp} with your LP</span>
              </>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Manage Liquidity · Live Positions
          </h1>
          <p className="text-sm text-[#8a93a8] mt-1 max-w-3xl">
            Pool figures are read live from Solana mainnet and Raydium, and positions are checked against wallet{' '}
            <span className="font-mono text-white">{shortAddr(walletAddress)}</span>. Pools that don't exist on-chain
            are flagged instead of shown with stored numbers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleRefresh}
            disabled={liveLoading}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#05080f] text-xs font-mono font-extrabold flex items-center gap-2 shadow-lg shadow-emerald-950/50 transition-all disabled:opacity-60"
          >
            <RefreshCw className={`w-4 h-4 ${liveLoading ? 'animate-spin' : ''}`} />
            <span>{liveLoading ? 'Checking chain…' : 'Refresh live data'}</span>
          </button>

          <button
            type="button"
            onClick={onNavigateToCreate}
            className="px-4 py-2.5 rounded-xl bg-[#0284c7] hover:bg-[#0369a1] text-white text-xs font-mono font-bold flex items-center gap-2 transition-all"
          >
            <Droplets className="w-4 h-4" />
            <span>+ Create New Pool</span>
          </button>
        </div>
      </div>

      {liveError && (
        <div className="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs font-mono flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>
            Live refresh failed: {liveError}.{' '}
            {live
              ? `Showing the last successful check from ${timeOf(live.fetchedAt)}.`
              : 'No pool figures are shown until the chain can be read.'}
          </span>
        </div>
      )}

      {live && live.errors.length > 0 && (
        <div className="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-200 text-xs font-mono space-y-1">
          {live.errors.map((e, i) => (
            <div key={i} className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
              <span>{e}</span>
            </div>
          ))}
        </div>
      )}

      {/* Pool selector */}
      {pools.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 font-mono text-xs">
          {pools.map((p, idx) => {
            const i = liveById.get(p.poolId);
            const tabPair = pairOf(p, i);
            const active = p.poolId === pool.poolId;
            const hasLp = (i?.walletLpBalance ?? 0) > 0;
            return (
              <button
                type="button"
                key={`${p.id || p.poolId}-${idx}`}
                onClick={() => setSelectedPoolId(p.poolId)}
                className={`px-3.5 py-2 rounded-xl border flex items-center gap-2 shrink-0 transition-all ${
                  active
                    ? 'bg-[#10192b] border-amber-400 text-white font-bold shadow-md'
                    : 'bg-[#090d16] border-[#1b2436] text-[#8a93a8] hover:text-white'
                }`}
              >
                <PairLogos pair={tabPair} />
                <span>
                  {tabPair.a}/{tabPair.b}
                </span>
                {!i ? (
                  <span className="text-[10px] text-[#6b7c96]">{liveLoading ? 'checking…' : '—'}</span>
                ) : i.status === 'LIVE' ? (
                  <span className="text-[10px] text-emerald-400">{fmtUsd(i.tvlUsd)}</span>
                ) : (
                  <span className={`text-[10px] ${OFF_CHAIN.includes(i.status) ? 'text-rose-300' : 'text-slate-300'}`}>
                    {STATUS_CHIP[i.status].label}
                  </span>
                )}
                {hasLp && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-400/15 text-amber-300 font-bold">YOUR LP</span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Pool overview */}
      <div className="rounded-xl border border-[#1b2436] bg-[#090d16] p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#162032] pb-4">
          <div className="flex items-center gap-3 min-w-0">
            <PairLogos pair={pair} large />
            <div className="min-w-0">
              <div className="text-lg font-bold text-white flex flex-wrap items-center gap-2">
                <span>
                  {pair.a} / {pair.b}
                </span>
                <span className="text-xs text-cyan-400 font-mono">
                  {info?.poolKind
                    ? `Raydium ${KIND_LABEL[info.poolKind]}`
                    : `${pool.poolType} · app record`}
                </span>
              </div>
              <div className="text-xs text-[#8a93a8] font-mono flex flex-wrap items-center gap-x-3 gap-y-1">
                <span>
                  Pool ID: {pool.poolId.slice(0, 14)}...{pool.poolId.slice(-6)}
                </span>
                <a
                  href={`https://solscan.io/account/${pool.poolId}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-cyan-400 hover:underline inline-flex items-center gap-1"
                >
                  <span>Solscan</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                {isLive && (
                  <a
                    href={`https://dexscreener.com/solana/${pool.poolId}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:underline inline-flex items-center gap-1"
                  >
                    <span>DexScreener</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            {info ? (
              <span className={`px-2.5 py-1 rounded-lg border font-bold uppercase ${STATUS_CHIP[info.status].cls}`}>
                {STATUS_CHIP[info.status].label}
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-lg border border-[#1f2b40] text-[#8a93a8]">
                {liveLoading ? 'Checking…' : 'Not checked'}
              </span>
            )}
          </div>
        </div>

        {renderPositionBanner()}

        {isLive && info && (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs font-mono">
              <Stat label={`${pair.a} in pool`} value={`${fmtAmount(info.reserveA)} ${pair.a}`} />
              <Stat
                label={`${pair.b} in pool`}
                value={`${fmtAmount(info.reserveB)} ${pair.b}`}
                valueClass="text-emerald-400"
              />
              <Stat label="Total liquidity" value={fmtUsd(info.tvlUsd)} />
              <Stat
                label={`Price per ${pair.a}`}
                value={`${fmtAmount(info.price)} ${pair.b}`}
                sub={info.price ? `1 ${pair.b} = ${fmtAmount(1 / info.price)} ${pair.a}` : undefined}
                valueClass="text-cyan-300"
              />
              <Stat
                label="LP burned (all holders)"
                value={fmtPct(info.lpBurnPct)}
                valueClass={info.lpBurnPct ? 'text-rose-300' : 'text-white'}
              />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <Stat label="24h volume" value={fmtUsd(info.volume24hUsd)} />
              <Stat
                label="24h fees · whole pool"
                value={fmtUsd(info.fees24hUsd)}
                sub="shared by all LPs + protocol"
                valueClass="text-amber-300"
              />
              <Stat label="Swap fee" value={info.feeRate !== null ? fmtPct(info.feeRate * 100) : '—'} />
              <Stat
                label="LP supply"
                value={fmtAmount(info.lpSupply)}
                sub={info.lpMint ? `mint ${shortAddr(info.lpMint)}` : undefined}
              />
            </div>
          </>
        )}

        <div className="text-[10px] font-mono text-[#5b6a82]">
          {info
            ? `Sources: ${info.sources.length ? info.sources.join(' + ') : 'none reachable'} · checked ${timeOf(
                info.fetchedAt
              )} · refreshes every 30s`
            : 'Waiting for the first live check…'}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Actions */}
        <div className="lg:col-span-2 rounded-xl border border-[#1b2436] bg-[#090d16] p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex flex-wrap items-center gap-2 border-b border-[#162032] pb-3">
            {[
              { id: 'ADD', label: 'Add Liquidity', icon: Plus },
              { id: 'REMOVE', label: 'Remove Liquidity', icon: Minus },
              { id: 'BURN', label: 'Burn LP', icon: Flame },
              { id: 'LOCK', label: 'Lock LP', icon: Lock },
              { id: 'FEES', label: 'Fees', icon: Coins },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  type="button"
                  key={tab.id}
                  onClick={() => setActionTab(tab.id as ActionTab)}
                  className={`px-3 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center gap-1.5 ${
                    actionTab === tab.id
                      ? 'bg-[#0284c7] text-white shadow-md shadow-cyan-950/40'
                      : 'bg-[#0e1422] text-[#8a93a8] hover:text-white border border-[#1b263d]'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="text-[11px] text-[#8a93a8] font-mono flex items-start gap-2 leading-relaxed">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0 mt-0.5 text-cyan-400" />
            <span>
              This app doesn't sign liquidity transactions. Actions open Raydium, where your wallet signs a real
              transaction you can check on Solscan. Refresh here afterwards to see the result.
            </span>
          </div>

          {!info || !isLive ? (
            <div className="p-4 rounded-xl bg-[#060911] border border-[#162032] text-xs font-mono text-[#a3b0c6] leading-relaxed">
              {info ? info.statusDetail : liveLoading ? 'Checking this pool on-chain…' : 'Live pool data is unavailable.'}
            </div>
          ) : (
            <div className="space-y-3 text-xs font-mono text-[#a3b0c6] leading-relaxed">
              {actionTab === 'ADD' && (
                <p>
                  Deposits go in at the pool's current ratio (1 {pair.a} : {fmtAmount(info.price)} {pair.b}) and earn a
                  share of the {info.feeRate !== null ? fmtPct(info.feeRate * 100) : '—'} swap fee in proportion to the
                  LP tokens you receive.
                </p>
              )}

              {actionTab === 'REMOVE' &&
                (isClmm ? (
                  <p>CLMM positions are withdrawn per position NFT on Raydium's portfolio page.</p>
                ) : !lpKnown ? (
                  <p>This wallet's LP balance couldn't be read, so check your positions on Raydium.</p>
                ) : lp > 0 ? (
                  <p>
                    This wallet holds {fmtAmount(lp)} LP ({fmtPct(info.walletSharePct)}) ≈ {fmtUsd(info.walletValueUsd)}.
                    Withdrawing returns {pair.a} and {pair.b} at the current ratio, including the fees your share has
                    earned.
                  </p>
                ) : (
                  <p>Nothing to withdraw: {shortAddr(walletAddress)} holds 0 LP tokens for this pool.</p>
                ))}

              {actionTab === 'BURN' && (
                <>
                  <p>
                    LP burned across all holders: <span className="text-white font-bold">{fmtPct(info.lpBurnPct)}</span>.
                    Burning is permanent: that share of the liquidity can never be withdrawn by anyone.
                  </p>
                  <p>
                    {isClmm
                      ? 'CLMM positions are NFTs; manage them on Raydium.'
                      : !lpKnown
                        ? "This wallet's LP balance couldn't be read."
                        : lp > 0
                          ? `This wallet holds ${fmtAmount(lp)} LP that could be burned.`
                          : 'This wallet has no LP tokens to burn.'}
                  </p>
                </>
              )}

              {actionTab === 'LOCK' && (
                <p>
                  Locking LP is done through Raydium's Burn &amp; Earn, which keeps the right to claim fees.{' '}
                  {isClmm
                    ? 'CLMM positions are managed on Raydium.'
                    : !lpKnown
                      ? "This wallet's LP balance couldn't be read."
                      : lp > 0
                        ? `This wallet holds ${fmtAmount(lp)} LP that could be locked.`
                        : 'This wallet has no LP tokens to lock.'}
                </p>
              )}

              {actionTab === 'FEES' &&
                (isClmm ? (
                  <p>Concentrated pools pay fees per position. View and claim them on Raydium's portfolio page.</p>
                ) : (
                  <>
                    <div className="p-4 rounded-xl bg-[#060911] border border-[#162032]">
                      <div className="text-[#6b7c96] text-[10px] uppercase">24h trading fees · whole pool</div>
                      <div className="text-amber-300 font-bold text-sm mt-1">{fmtUsd(info.fees24hUsd)}</div>
                      <div className="text-[10px] text-[#6b7c96] mt-0.5">
                        This wallet's share: {lpKnown ? fmtPct(info.walletSharePct) : 'unknown'} → up to{' '}
                        {lpKnown ? fmtUsd(myFees24h) : 'unknown'}
                      </div>
                    </div>
                    <p>
                      Raydium {KIND_LABEL[info.poolKind || 'OTHER']} pools have no separate "unclaimed fees" balance.
                      Swap fees are added to the pool's reserves, and LP holders receive their share when they withdraw
                      ("up to" because Raydium takes a protocol cut first).
                    </p>
                  </>
                ))}
            </div>
          )}

          {action.href ? (
            <a
              href={action.href}
              target="_blank"
              rel="noreferrer"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#0284c7] to-[#0369a1] hover:from-[#38bdf8] hover:to-[#0284c7] text-white font-bold text-xs font-mono shadow-lg shadow-cyan-950/40 transition-all flex items-center justify-center gap-2"
            >
              <span>{action.label}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          ) : (
            <button
              type="button"
              disabled
              className="w-full py-3.5 rounded-xl bg-[#0e1422] border border-[#1b263d] text-[#6b7c96] font-bold text-xs font-mono cursor-not-allowed"
            >
              {action.label}
            </button>
          )}
        </div>

        {/* Gemini 4 Argon audit of the live figures */}
        <div className="rounded-xl border border-amber-500/30 bg-[#090d16] p-5 shadow-xl flex flex-col justify-between space-y-4 font-mono text-xs">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <Brain className="w-4 h-4" />
                <span>ARGON 4 POOL AUDITOR</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-bold">LIVE DATA ONLY</span>
            </div>

            <p className="text-[11px] text-[#8a9bb4] font-sans leading-relaxed">
              Ask Gemini 4 Argon to review the live figures for{' '}
              <strong className="text-white">
                {pair.a}/{pair.b}
              </strong>
              : depth, price impact and what your position means. It only sees the numbers shown on this screen.
            </p>

            <div className="p-3 rounded-xl bg-[#05080f] border border-[#162032] text-[11px] text-cyan-300 whitespace-pre-wrap min-h-40 max-h-60 overflow-y-auto leading-relaxed">
              {argonAnalysis || argonDefault}
            </div>
          </div>

          <button
            type="button"
            onClick={handleRunArgonPoolAudit}
            disabled={analyzingPool || !isLive}
            className="w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#05080f] font-extrabold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100"
          >
            <Sparkles className={`w-3.5 h-3.5 ${analyzingPool ? 'animate-spin' : ''}`} />
            <span>{analyzingPool ? 'Auditing live figures…' : 'Run Argon 4 Pool Audit'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
