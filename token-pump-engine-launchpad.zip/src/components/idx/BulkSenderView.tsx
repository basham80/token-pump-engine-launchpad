import React, { useState } from 'react';
import { TokenMetadata } from '../../types';
import { Send, Upload, CheckCircle2, RefreshCw, AlertCircle } from 'lucide-react';

interface BulkSenderViewProps {
  tokens: TokenMetadata[];
  onRefresh: () => void;
}

export const BulkSenderView: React.FC<BulkSenderViewProps> = ({ tokens, onRefresh }) => {
  const [selectedTokenMint, setSelectedTokenMint] = useState<string>(tokens[0]?.mint || '');
  const [recipientsText, setRecipientsText] = useState<string>(
    `7uXm9Q5fL1V24kP9q8rL8n7r5g7L1h4E1K8n1K2j8ZV1, 50000\n3kPn4Y8xR7T12mQ5wL9vE4sK6j8H2n1B9zX4cV7mD2, 50000\n9qLt2W6vM4K89xP1nL7yE5sR8j3H1n4B2zX9cV3mF3, 50000`
  );
  const [loading, setLoading] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const token = tokens.find((t) => t.mint === selectedTokenMint) || tokens[0];

  const handleSend = async () => {
    if (!token) return;
    const lines = recipientsText.split('\n').filter((l) => l.trim().length > 0);
    const recipients = lines.map((line) => {
      const parts = line.split(',').map((p) => p.trim());
      return {
        address: parts[0],
        amount: parseFloat(parts[1]) || 1000,
      };
    });

    if (recipients.length === 0) {
      setFeedback('Please provide at least one recipient address.');
      return;
    }

    try {
      setLoading(true);
      setFeedback(null);
      const res = await fetch('/api/tokens/bulk-send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tokenMint: token.mint, recipients }),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setFeedback(`Airdropped to ${recipients.length} wallets successfully!`);
        onRefresh();
      } else {
        setFeedback(data.error || 'Airdrop batch failed.');
      }
    } catch (e: any) {
      setFeedback('Network error during airdrop.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12 font-mono text-xs">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-[10px] text-cyan-400 font-bold uppercase">
            Multisender & Airdrop
          </span>
          <span className="text-[#8a93a8]">Batch Token Distribution</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Bulk Sender · Solana Multisend
        </h1>
        <p className="text-[#8a93a8] mt-1 text-sm font-sans">
          Distribute tokens to thousands of Solana wallets in optimized parallel transaction bundles.
        </p>
      </div>

      <div className="rounded-xl border border-[#1b2234] bg-[#0b0e17] p-5 sm:p-6 shadow-xl space-y-4">
        <div>
          <label className="text-[#8a93a8] block mb-1">Select Token to Distribute</label>
          <select
            value={selectedTokenMint}
            onChange={(e) => setSelectedTokenMint(e.target.value)}
            className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-2.5 text-white font-bold focus:outline-none"
          >
            {tokens.map((t, idx) => (
              <option key={`${t.mint}-${idx}`} value={t.mint}>
                {t.symbol} - {t.name} (Balance: {t.userBalance.toLocaleString()})
              </option>
            ))}
          </select>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[#8a93a8]">Recipients (Address, Amount)</label>
            <button
              type="button"
              onClick={() => {
                if (token) {
                  const thirtyPct = Math.round(token.supply * 0.3);
                  setRecipientsText(`HTN1fvHwbzKiMwh9YXZEe3eooiMdoCAs3TweWdiSZV5i, ${thirtyPct}`);
                }
              }}
              className="text-cyan-400 hover:text-cyan-300 text-[11px] underline"
            >
              Set 30% Airdrop to HTN1...ZV5i
            </button>
          </div>
          <textarea
            rows={6}
            value={recipientsText}
            onChange={(e) => setRecipientsText(e.target.value)}
            className="w-full bg-[#111624] border border-[#1f283d] rounded-lg p-3 text-white focus:outline-none focus:border-[#0284c7] font-mono leading-relaxed"
          />
        </div>

        {feedback && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <button
          onClick={handleSend}
          disabled={loading}
          className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#0284c7] to-[#0369a1] hover:from-[#38bdf8] hover:to-[#0284c7] text-white font-bold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Broadcasting Airdrop Batches...</span>
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Send Batch Airdrop</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
