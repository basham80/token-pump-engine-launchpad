import React, { useState, useEffect } from 'react';
import {
  Brain,
  Zap,
  Bot,
  TrendingUp,
  Cpu,
  Layers,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Terminal,
  Activity,
  ArrowUpRight,
  Flame,
  Coins,
  RefreshCw,
  Clock,
  Sliders,
  DollarSign,
  Copy,
  Check,
} from 'lucide-react';
import type {
  AIModelType,
  AIModelEngine,
  StrategyUpgradeDef,
  AIPumpExecutionResult,
} from '../../types';

interface AITaskForceMatrixViewProps {
  walletSolBalance?: number;
  onNavigateToTab?: (tab: string) => void;
  onRefreshGlobal?: () => void;
}

export const AITaskForceMatrixView: React.FC<AITaskForceMatrixViewProps> = ({
  walletSolBalance = 0,
  onNavigateToTab,
  onRefreshGlobal,
}) => {
  // State
  const [engines, setEngines] = useState<AIModelEngine[]>([]);
  const [strategies, setStrategies] = useState<StrategyUpgradeDef[]>([]);
  const [selectedEngine, setSelectedEngine] = useState<AIModelType>('GEMINI_3_8_FLASH');
  const [loading, setLoading] = useState<boolean>(false);
  const [inferring, setInferring] = useState<boolean>(false);
  const [pumping, setPumping] = useState<boolean>(false);
  const [pulsing, setPulsing] = useState<boolean>(false);

  // Pump form parameters
  const [pumpTokenMint, setPumpTokenMint] = useState<string>('7cnu3w5SbTxCrYTPavBJ7dib4Bdnf6mN5AG98xzDpump');
  const [pumpAmountSol, setPumpAmountSol] = useState<number>(0.05);
  const [pumpMode, setPumpMode] = useState<'WAVE_20' | 'SINGLE' | 'RAYDIUM_BOOST'>('WAVE_20');

  // Outputs & Telemetry
  const [inferencePrompt, setInferencePrompt] = useState<string>(
    'Synthesize optimal 20-wave pump schedule for $BASH to maximize bonding curve velocity with minimum price distortion.'
  );
  const [inferenceResult, setInferenceResult] = useState<string>('');
  const [lastPumpResult, setLastPumpResult] = useState<AIPumpExecutionResult | null>(null);
  const [copiedLlamaCmd, setCopiedLlamaCmd] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [taskForceReports, setTaskForceReports] = useState<any[]>([]);

  const llamaCommand =
    'llama serve -hf DavidAU/Qwen3.8-27B-TURBO-Fable-Cold-Fusion-735-882-Heretic-Uncensored-NEO-CODER-MAX-MTP-GGUF:Q4_K_M --port 8080 -c 8192';

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Fetch Engines & Strategies
  const fetchData = async () => {
    try {
      setLoading(true);
      const [engRes, stratRes] = await Promise.all([
        fetch('/api/ai/engines'),
        fetch('/api/ai/strategies'),
      ]);
      const engData = await engRes.json();
      const stratData = await stratRes.json();

      if (engData.ok) setEngines(engData.engines);
      if (stratData.ok) setStrategies(stratData.strategies);
    } catch (e) {
      console.error('Failed to load AI orchestrator data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handle Run Inference
  const handleRunInference = async () => {
    try {
      setInferring(true);
      setInferenceResult(`Querying ${selectedEngine}... Synthesizing quantitative reasoning.`);
      const res = await fetch('/api/ai/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          engineId: selectedEngine,
          prompt: inferencePrompt,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setInferenceResult(data.responseText);
        showToast(`Inference synthesized by ${data.engineUsed} in ${data.latencyMs}ms`);
      } else {
        setInferenceResult(`Inference error: ${data.error || 'Server rejected query'}`);
      }
    } catch (err: any) {
      setInferenceResult(`Inference failed: ${err?.message || 'Network unreachable'}`);
    } finally {
      setInferring(false);
    }
  };

  // Handle Execute AI Pump
  const handleExecuteAIPump = async () => {
    try {
      setPumping(true);
      const res = await fetch('/api/ai/execute-pump', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tokenMint: pumpTokenMint,
          solAmount: pumpAmountSol,
          modelType: selectedEngine,
          mode: pumpMode,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setLastPumpResult(data);
        showToast(`🚀 Pump executed! +${data.bondingPctIncrease}% bonding progress. Earned +${data.revenueEarnedSol} SOL`);
        fetchData();
        if (onRefreshGlobal) onRefreshGlobal();
      } else {
        showToast(`Pump failed: ${data.error || 'Check server status'}`);
      }
    } catch (err: any) {
      showToast(`Execution error: ${err?.message || 'Network error'}`);
    } finally {
      setPumping(false);
    }
  };

  // Handle Upgrade Strategy
  const handleUpgradeStrategy = async (strategyId: string) => {
    try {
      const res = await fetch('/api/ai/upgrade-strategy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ strategyId }),
      });
      const data = await res.json();
      if (data.ok) {
        showToast(`⭐ Strategy upgraded to ${data.upgraded?.name}!`);
        fetchData();
      } else {
        showToast(`Upgrade error: ${data.error || 'Insufficient rank'}`);
      }
    } catch (e) {
      showToast('Upgrade request failed');
    }
  };

  // Handle Task Force Pulse
  const handleTaskForcePulse = async () => {
    try {
      setPulsing(true);
      const res = await fetch('/api/ai/taskforce-pulse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (data.ok) {
        setTaskForceReports(data.pulse.squadronReports || []);
        showToast(`✅ Task Force Pulse synchronized! +${data.pulse.feeGeneratedSol} SOL fee added.`);
        if (onRefreshGlobal) onRefreshGlobal();
      }
    } catch (e) {
      showToast('Pulse sync failed');
    } finally {
      setPulsing(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLlamaCmd(true);
    setTimeout(() => setCopiedLlamaCmd(false), 2500);
    showToast('Llama serve command copied to clipboard!');
  };

  return (
    <div className="space-y-6 text-[#e8edf5]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-[#ffd60a] text-[#060a12] font-mono text-xs font-bold px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 border border-[#ffe74d] animate-in fade-in slide-in-from-top duration-200">
          <Sparkles className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* TOP HERO HEADER */}
      <div className="rounded-2xl bg-gradient-to-r from-[#0d1627] via-[#09111f] to-[#121c2e] border border-[#23334d] p-6 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
        <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-[#ffd60a]/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono text-xs uppercase tracking-wider">
              <Brain className="w-3.5 h-3.5 text-cyan-400" />
              <span>Multi-AI Task Force & Strategy Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <span>Autonomous AI Token Operator</span>
              <span className="text-xs px-2.5 py-1 rounded-lg bg-[#ffd60a]/20 border border-[#ffd60a]/40 text-[#ffd60a] font-mono font-bold">
                PRO OPTIMAL
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-[#8a9bb4] max-w-2xl font-mono leading-relaxed">
              Coordinating Google Gemini 3.8 Flash, JEV Elasticity Math, Liquid AI d1-3B continuous dynamics, and local Qwen3.8-27B-TURBO GGUF to execute algorithmic bonding curve pumps, harvest AMM yield, and upgrade token earning strategies.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0 font-mono text-xs">
            <button
              type="button"
              onClick={handleTaskForcePulse}
              disabled={pulsing}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
            >
              <Activity className={`w-4 h-4 ${pulsing ? 'animate-spin' : ''}`} />
              <span>{pulsing ? 'Synchronizing Pulse...' : 'Task Force Pulse'}</span>
            </button>

            <button
              type="button"
              onClick={fetchData}
              disabled={loading}
              className="px-3.5 py-2.5 rounded-xl bg-[#111827] border border-[#223048] hover:border-[#384d72] text-[#8a9bb4] hover:text-white font-bold flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>

        {/* Live Token Status Quickbar */}
        <div className="mt-6 pt-4 border-t border-[#1e2a3d] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="bg-[#060a12]/60 border border-[#1a2538] p-2.5 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase">Target Token</div>
            <div className="font-bold text-white flex items-center gap-1.5 mt-0.5 truncate">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>$BASH (pump.fun)</span>
            </div>
            <div className="text-[10px] text-[#8a9bb4] truncate font-mono">7cnu3w5...Dpump</div>
          </div>

          <div className="bg-[#060a12]/60 border border-[#1a2538] p-2.5 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase">AI Orchestrator Mesh</div>
            <div className="font-bold text-cyan-400 mt-0.5 flex items-center gap-1.5">
              <span>4 Models Active</span>
              <span className="text-[10px] text-emerald-400">● 100% Online</span>
            </div>
            <div className="text-[10px] text-[#8a9bb4]">Gemini · JEV · Liquid · Qwen</div>
          </div>

          <div className="bg-[#060a12]/60 border border-[#1a2538] p-2.5 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase">Active Strategy Level</div>
            <div className="font-bold text-[#ffd60a] mt-0.5 flex items-center gap-1.5">
              <span>Level 3 / 6 Unlocked</span>
              <span className="text-[10px] text-emerald-400 font-bold">2.4x Yield</span>
            </div>
            <div className="text-[10px] text-[#8a9bb4]">Max Target: 8.5x Supreme</div>
          </div>

          <div className="bg-[#060a12]/60 border border-[#1a2538] p-2.5 rounded-xl">
            <div className="text-[10px] text-[#6b7c96] uppercase">Treasury Wallet Balance</div>
            <div className="font-bold text-emerald-400 mt-0.5 truncate">
              {walletSolBalance.toFixed(4)} SOL
            </div>
            <div className="text-[10px] text-[#8a9bb4]">Real RPC mainnet buffer</div>
          </div>
        </div>
      </div>

      {/* SECTION 1: MULTI-AI MODEL MESH (THE 4 HOOKED-UP ENGINES) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono">
              Hooked-Up AI Model Ensemble
            </h2>
          </div>
          <span className="text-xs text-[#8a9bb4] font-mono">Select driver for active strategy & pump synthesis</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {engines.map((eng) => {
            const isSelected = selectedEngine === eng.id;
            return (
              <div
                key={eng.id}
                onClick={() => setSelectedEngine(eng.id)}
                className={`p-4 rounded-xl border cursor-pointer transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#0f172a] border-[#ffd60a] shadow-lg shadow-[#ffd60a]/10 ring-1 ring-[#ffd60a]'
                    : 'bg-[#0b1018] border-[#1f2a3a] hover:border-[#2d3e58] hover:bg-[#0e1420]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-[#172236] text-[#8a9bb4]">
                      {eng.provider}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        eng.status === 'ONLINE'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : eng.status === 'READY'
                          ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                      <span>{eng.status}</span>
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-white mt-2.5">{eng.name}</h3>
                  <div className="text-[11px] font-mono text-[#ffd60a] mt-0.5 line-clamp-1">{eng.tag}</div>

                  <p className="text-[11px] text-[#8a9bb4] mt-2 line-clamp-3 leading-relaxed">
                    {eng.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#182335] space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#6b7c96]">
                    <span>Latency:</span>
                    <span className="text-white font-bold">{eng.latencyMs}ms</span>
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {eng.capabilities.slice(0, 2).map((cap) => (
                      <span
                        key={cap}
                        className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#131d2e] text-[#93a7c4]"
                      >
                        {cap}
                      </span>
                    ))}
                  </div>

                  {isSelected && (
                    <div className="text-[10px] font-mono text-[#ffd60a] font-bold flex items-center justify-end gap-1 mt-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>SELECTED DRIVER</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Local Llama Serve Quick Launcher Banner */}
        <div className="p-3.5 rounded-xl bg-[#080d15] border border-cyan-500/30 font-mono text-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <Terminal className="w-4 h-4 text-cyan-400 shrink-0" />
            <div className="min-w-0">
              <span className="text-white font-bold">Llama Serve CLI (Qwen3.8-27B-TURBO GGUF): </span>
              <span className="text-[#8a9bb4] truncate block md:inline text-[11px]">
                {llamaCommand}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => copyToClipboard(llamaCommand)}
            className="px-3 py-1.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center gap-1.5 text-xs font-bold shrink-0 transition-colors"
          >
            {copiedLlamaCmd ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLlamaCmd ? 'COPIED!' : 'COPY COMMAND'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 2: INTERACTIVE AI STRATEGY INFERENCE & LIVE PUMP TERMINAL */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* LEFT COLUMN: AI STRATEGIC REASONING & INFERENCE ENGINE */}
        <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-[#ffd60a]" />
              <h3 className="font-bold text-sm text-white font-mono uppercase tracking-wider">
                Multi-Model Strategic Reasoning
              </h3>
            </div>
            <span className="text-[11px] font-mono text-cyan-400 font-bold">
              Active: {engines.find((e) => e.id === selectedEngine)?.name || selectedEngine}
            </span>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-mono text-[#8a9bb4] uppercase tracking-wider">
              Strategic Directive Prompt
            </label>
            <textarea
              rows={3}
              value={inferencePrompt}
              onChange={(e) => setInferencePrompt(e.target.value)}
              className="w-full bg-[#060a12] border border-[#1f2a3a] focus:border-cyan-500/50 rounded-xl p-3 text-xs text-white font-mono focus:outline-none transition-colors"
              placeholder="Enter strategy prompt..."
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRunInference}
              disabled={inferring}
              className="px-4 py-2 rounded-xl bg-[#ffd60a] hover:bg-[#ffe74d] text-[#060a12] font-mono font-bold text-xs flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-[#ffd60a]/10"
            >
              <Sparkles className={`w-3.5 h-3.5 ${inferring ? 'animate-spin' : ''}`} />
              <span>{inferring ? 'Synthesizing Reasoning...' : 'Run Model Inference'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                setInferencePrompt(
                  `Analyze token $BASH bonding curve elasticity. What is the optimal SOL injection size to accelerate Raydium migration without triggering high slippage?`
                )
              }
              className="px-3 py-2 rounded-xl bg-[#111827] border border-[#223048] hover:text-white text-[#8a9bb4] font-mono text-xs transition-colors"
            >
              Preset: Curve Elasticity
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="text-[11px] font-mono text-[#8a9bb4] uppercase tracking-wider flex items-center justify-between">
              <span>Model Output & Synthesis</span>
              {inferring && <span className="text-cyan-400 animate-pulse">Running live neural pass...</span>}
            </div>
            <div className="p-3.5 rounded-xl bg-[#060a12] border border-[#1a2538] text-xs font-mono text-cyan-300 leading-relaxed whitespace-pre-wrap min-h-36 max-h-60 overflow-y-auto">
              {inferenceResult || (
                <span className="text-[#4b5563]">
                  Select an engine above and click &quot;Run Model Inference&quot; to synthesize optimal token strategies across Gemini, JEV, LiquidAI, or Qwen-TURBO.
                </span>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIONABLE AI PUMP & TOKEN TERMINAL */}
        <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <h3 className="font-bold text-sm text-white font-mono uppercase tracking-wider">
                Autonomous Pump & Buyback Terminal
              </h3>
            </div>
            <span className="text-[11px] font-mono text-rose-400 font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
              <span>LIVE PUMP ENGINE</span>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-[#8a9bb4] uppercase">Target Token Mint</label>
              <input
                type="text"
                value={pumpTokenMint}
                onChange={(e) => setPumpTokenMint(e.target.value)}
                className="w-full bg-[#060a12] border border-[#1f2a3a] rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono text-[#8a9bb4] uppercase">Injection Amount (SOL)</label>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  step="0.01"
                  min="0.001"
                  value={pumpAmountSol}
                  onChange={(e) => setPumpAmountSol(parseFloat(e.target.value) || 0.01)}
                  className="w-full bg-[#060a12] border border-[#1f2a3a] rounded-xl px-3 py-2 text-xs text-emerald-400 font-mono font-bold focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Quick presets for SOL amount */}
          <div className="flex items-center gap-1.5 font-mono text-[11px]">
            <span className="text-[#6b7c96]">Quick Size:</span>
            {[0.01, 0.05, 0.1, 0.25, 0.5].map((amt) => (
              <button
                key={amt}
                type="button"
                onClick={() => setPumpAmountSol(amt)}
                className={`px-2.5 py-1 rounded-lg border font-bold transition-all ${
                  pumpAmountSol === amt
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                    : 'bg-[#111827] text-[#8a9bb4] border-[#1e2a3d] hover:text-white'
                }`}
              >
                {amt} SOL
              </button>
            ))}
          </div>

          {/* Execution Mode */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-[#8a9bb4] uppercase">Execution Mode</label>
            <div className="grid grid-cols-3 gap-2 font-mono text-xs">
              {[
                { id: 'WAVE_20', label: '20-Trade Wave', sub: 'Stealth retail' },
                { id: 'SINGLE', label: 'Instant Push', sub: 'Burst pump' },
                { id: 'RAYDIUM_BOOST', label: '90% SOL Pool', sub: 'Raydium depth' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPumpMode(m.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    pumpMode === m.id
                      ? 'bg-rose-500/10 border-rose-500/50 text-rose-300'
                      : 'bg-[#060a12] border-[#1f2a3a] text-[#8a9bb4] hover:text-white'
                  }`}
                >
                  <div className="font-bold text-white text-[11px]">{m.label}</div>
                  <div className="text-[10px] text-[#6b7c96]">{m.sub}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Execute Button */}
          <button
            type="button"
            onClick={handleExecuteAIPump}
            disabled={pumping}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-500 via-amber-500 to-[#ffd60a] hover:from-rose-400 hover:to-[#ffe74d] text-[#060a12] font-mono font-extrabold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-xl shadow-rose-950/40 active:scale-[0.98] transition-all"
          >
            <Flame className={`w-4 h-4 ${pumping ? 'animate-bounce' : ''}`} />
            <span>
              {pumping
                ? 'AI TASK FORCE EXECUTING PUMP...'
                : `EXECUTE AI-OPTIMIZED PUMP (${pumpAmountSol} SOL)`}
            </span>
          </button>

          {/* Last Pump Telemetry Result Card */}
          {lastPumpResult && (
            <div className="p-3.5 rounded-xl bg-[#060a12] border border-emerald-500/30 font-mono text-xs space-y-2">
              <div className="flex items-center justify-between text-emerald-400 font-bold">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Execution Verified</span>
                </span>
                <span>+{lastPumpResult.bondingPctIncrease}% Curve Push</span>
              </div>
              <div className="text-[11px] text-[#8a9bb4]">{lastPumpResult.rationale}</div>
              <div className="pt-2 border-t border-[#1a2538] flex items-center justify-between text-[10px] text-[#6b7c96]">
                <span>Tx Signature:</span>
                <span className="text-cyan-400 truncate max-w-44">{lastPumpResult.txSignature}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SECTION 3: TOKEN STRATEGY UPGRADES FOUNDRY ("EARN AS MUCH MONEY & UPGRADE GAINING TOKEN STRATEGIES") */}
      <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base font-bold text-white uppercase tracking-wider font-mono">
                Upgradeable Token Strategies Foundry
              </h2>
            </div>
            <p className="text-xs text-[#8a9bb4] font-mono mt-0.5">
              Unlock progressive quantitative strategies throughout the project to maximize SOL earnings and compound bonding curve volume.
            </p>
          </div>

          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono text-xs font-bold flex items-center gap-2">
            <Coins className="w-4 h-4" />
            <span>EARNING ACCELERATOR: ACTIVE</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {strategies.map((strat) => {
            const isUnlocked = strat.unlocked;
            const isAvailable = strat.status === 'AVAILABLE';
            const isLocked = strat.status === 'LOCKED';

            return (
              <div
                key={strat.id}
                className={`p-4 rounded-xl border flex flex-col justify-between transition-all ${
                  strat.status === 'ACTIVE'
                    ? 'bg-[#0d1624] border-emerald-500/50 shadow-md shadow-emerald-950/20'
                    : isAvailable
                    ? 'bg-[#0f172a] border-cyan-500/40 hover:border-cyan-400'
                    : 'bg-[#080d15] border-[#182335] opacity-60'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#172338] text-[#93a7c4]">
                      LEVEL {strat.level} · {strat.category}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                        strat.status === 'ACTIVE'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : isAvailable
                          ? 'bg-cyan-500/20 text-cyan-400 animate-pulse'
                          : 'bg-gray-800 text-gray-400'
                      }`}
                    >
                      {strat.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-sm text-white">{strat.name}</h3>
                  <p className="text-[11px] text-[#8a9bb4] leading-relaxed line-clamp-3">
                    {strat.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#182436] space-y-3 font-mono">
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="bg-[#060a12] p-2 rounded-lg border border-[#1a2538]">
                      <div className="text-[#6b7c96]">Expected Yield</div>
                      <div className="text-emerald-400 font-bold text-xs mt-0.5">
                        +{strat.expectedYieldSol} SOL
                      </div>
                    </div>

                    <div className="bg-[#060a12] p-2 rounded-lg border border-[#1a2538]">
                      <div className="text-[#6b7c96]">Multiplier</div>
                      <div className="text-[#ffd60a] font-bold text-xs mt-0.5">
                        {strat.boostMultiplier}x Boost
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-[#8a9bb4]">Recommended AI:</span>
                    <span className="text-cyan-400 font-bold">{strat.aiEngineRecommended}</span>
                  </div>

                  {/* Action button */}
                  {strat.status === 'ACTIVE' ? (
                    <div className="w-full py-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-center text-xs font-bold flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>STRATEGY DEPLOYED ({strat.actionCount} Actions)</span>
                    </div>
                  ) : isAvailable ? (
                    <button
                      type="button"
                      onClick={() => handleUpgradeStrategy(strat.id)}
                      className="w-full py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950/40 active:scale-95 transition-all"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>UPGRADE STRATEGY (Cost: {strat.costSol} SOL)</span>
                    </button>
                  ) : (
                    <div className="w-full py-2 rounded-lg bg-[#111827] text-gray-500 text-center text-xs font-bold cursor-not-allowed">
                      <span>LOCKED · UNLOCK PREVIOUS LEVEL FIRST</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 4: TASK FORCE SQUADRONS SYNCHRONIZED REPORTS */}
      {taskForceReports.length > 0 && (
        <div className="rounded-xl bg-[#0b1018] border border-[#1f2a3a] p-5 space-y-3 font-mono">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>Coordinated Task Force Squadron Reports</span>
            </h3>
            <span className="text-[11px] text-emerald-400 font-bold">All 4 Squadrons Reporting</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {taskForceReports.map((rep, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-[#060a12] border border-[#1a2538] space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{rep.squadron}</span>
                  <span className="text-[10px] text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/10">
                    {rep.status}
                  </span>
                </div>
                <div className="text-[11px] text-[#ffd60a]">Leader: {rep.leader}</div>
                <div className="text-[11px] text-[#8a9bb4]">{rep.result}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
