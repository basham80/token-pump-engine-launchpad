export interface TokenLiveState {
  symbol: string;
  name: string;
  mint: string;
  creatorWallet: string;
  priceSol: number;
  priceUsd: number;
  solPriceUsd: number;
  marketCapUsd: number;
  virtualSolReserves: number;
  virtualTokenReserves: number;
  bondingCurveProgressPct: number;
  graduationTargetSol: number;
  volume24hUsd: number;
  change24hPct: number;
  holdersCount: number;
  pumpFunUrl: string;
}

export interface FlywheelConfig {
  buyback_pct: number;
  stage_tap_pct: number;
  mrr_usd: number;
  mining_share_pct: number;
  governor_window_minutes: number;
  governor_cap_sol: number;
  min_injection_sol: number;
  graduation_target_sol: number;
  auto_cycle_enabled: boolean;
  auto_cycle_interval_sec: number;
  gcp_telemetry_enabled: boolean;
}

export interface FlywheelState {
  buyback_reserve_sol: number;
  total_injected_sol: number;
  total_injected_usd: number;
  total_tokens_burned: number;
  injections_count: number;
  current_window_injected_sol: number;
  window_start_time: number;
  window_rolls_count: number;
  delayed_injections_count: number;
  total_mining_sol: number;
  total_payment_sol: number;
  total_stage_tap_sol: number;
  last_injection_time?: number;
  last_injection_sol?: number;
}

export interface SyndicateWallet {
  id: string;
  label: string;
  address: string;
  solBalance: number;
  tokenBalance: number;
  role: 'PUMP_INJECTOR' | 'PROFIT_HARVESTER' | 'DIP_REBUYER' | 'TREASURY_PROXY';
  totalPumps: number;
  totalSolDeployed: number;
  status: 'IDLE' | 'PUMPING' | 'HARVESTING' | 'REBUYING';
  lastTxSignature: string;
}

export type CyclePhase = 'VOLUME_PUMP' | 'HARVEST_50_MAIN' | 'DIP_CREATED' | 'DIP_REBUY_35' | 'COMPOUND_IDLE';

export interface RebalanceCycleState {
  currentPhase: CyclePhase;
  cycleIteration: number;
  totalProfitWithdrawnSol: number; // 50% sold to main wallet
  totalReinvestedSol: number; // 35% sold + mining SOL pumped back
  lastHarvestSol: number;
  lastRebuySol: number;
  autoRebalanceEnabled: boolean;
  targetPumpVolumeSol: number;
  mainWalletAddress: string;
  phaseProgressPct: number;
  lastActionTimestamp: number;
}

export interface AuditContractSpec {
  programId: string;
  network: string;
  auditStatus: string;
  auditor: string;
  anchorCode: string;
  verifiedTimestamp: string;
  features: string[];
}

export interface LedgerEntry {
  id: string;
  timestamp: number;
  type: 'injection' | 'allocation' | 'delay' | 'window_roll' | 'stage_tap' | 'gcp_mining' | 'syndicate_pump' | 'harvest_50' | 'rebuy_35';
  amountSol: number;
  amountUsd: number;
  source: string;
  details: string;
  txSignature?: string;
  reserveAfter: number;
  truthClass?: 'REAL' | 'ESTIMATE' | 'SIMULATION' | 'UNVERIFIED';
}

export type AgentRole =
  | 'DISCOVERY'
  | 'MARKET_RESEARCH'
  | 'OPPORTUNITY_SCORING'
  | 'PRICING'
  | 'EXECUTION'
  | 'DATA_TRANSFORMATION'
  | 'ANALYTICS'
  | 'PRODUCT_BUILD'
  | 'DELIVERY'
  | 'VERIFICATION'
  | 'SETTLEMENT'
  | 'TREASURY'
  | 'COMPOUNDING'
  | 'OBSERVABILITY'
  | 'RISK'
  | 'PUMP'
  | 'MARKET_MAKING'
  | 'ARBITRAGE'
  | 'OPTIMIZATION'
  | 'CAPITAL_ALLOCATION'
  | 'AUTONOMOUS_ENGINEERING';

export type AgentState = 'IDLE' | 'DISCOVERING' | 'EVALUATING' | 'EXECUTING' | 'VERIFYING' | 'BLOCKED' | 'STOPPED' | 'FAILED';

export interface AgentDef {
  id: string;
  name: string;
  role: AgentRole;
  capabilities: string[];
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  budget: number;
  state: AgentState;
  lastAction?: string;
}

export interface OpportunityItem {
  id: string;
  title: string;
  desc: string;
  category: 'ZERO_CAPITAL' | 'M2M_PRODUCT' | 'DEFI_AUDIT' | 'ARBITRAGE';
  capitalRequired: number;
  expectedRevSol: number;
  probSuccess: number;
  evSol: number;
  risk: 'ZERO' | 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'DISCOVERED' | 'PENDING' | 'EXECUTING' | 'EXECUTED' | 'FAILED';
  ts: number;
  truthClass: 'REAL' | 'ESTIMATE' | 'SIMULATION';
}

export interface X402Product {
  productId: string;
  name: string;
  category: 'SECURITY_REPORT' | 'MARKET_DATA' | 'RISK_REPORT' | 'ANALYTICS';
  description: string;
  priceSol: number;
  isAvailable: boolean;
  features: string[];
}

export interface X402Challenge {
  challengeId: string;
  productId: string;
  product: X402Product;
  priceSol: number;
  recipient: string;
  expires: number;
  status: 'PENDING' | 'FULFILLED' | 'EXPIRED';
  txSignature?: string;
}

export interface CapitalProposal {
  id: string;
  title: string;
  desc: string;
  capitalSol: number;
  expectedRevSol: number;
  marginPct: number;
  risk: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'PROPOSED' | 'EXECUTING' | 'ACCEPTED' | 'REJECTED';
}

export interface LearningRecord {
  action: string;
  lesson: string;
  ts: number;
}

export interface EconomicTruth {
  real: { gross: number; cost: number; profit: number; events: number };
  estimate: { gross: number; net: number; events: number };
  simulation: { gross: number; cost: number; profit: number; events: number };
}

export interface TokenSnapshot {
  timestamp: number;
  priceUsd: number;
  marketCapUsd: number;
  cumulativeInjectedSol: number;
  reserveSol: number;
  hashrateKhs: number;
}

// Google Cloud Mining Fleet Types
export type GceMachineFamily = 'C2-Compute' | 'C3-NextGen' | 'T2D-AMDEpyc' | 'N2-General' | 'G2-NvidiaL4' | 'A2-NvidiaA100' | 'C3-SapphireRapids' | 'Local-Workstation' | 'N1-Standard' | 'Kaggle-GPU' | 'Kaggle-Cloud';
export type InstanceStatus = 'RUNNING' | 'PROVISIONING' | 'STOPPED' | 'PREEMPTED';
export type MiningAlgo = 'randomx' | 'kheavyhash' | 'autolykos2' | 'etchash' | 'fishhash' | 'pearl';

export interface GceMiningInstance {
  id: string;
  name: string;
  zone: string;
  machineType: string;
  family: GceMachineFamily;
  vCPUs: number;
  memoryGb: number;
  hasGpu: boolean;
  gpuType?: string;
  isSpot: boolean;
  algo: MiningAlgo;
  status: InstanceStatus;
  hashrate: number; // in unit (kH/s for RandomX, MH/s for GPU)
  hashrateUnit: string;
  cpuUsagePct: number;
  tempCelsius: number;
  costPerHourUsd: number;
  dailyYieldCoins: number;
  dailyYieldSol: number;
  dailyYieldUsd: number;
  netMarginPct: number;
  uptimeSeconds: number;
  lastPing: number;
  pool: string;
  command?: string;
  workerId?: string;
  // Live unMineable Stratum Hookup Telemetry
  unmineableHookedUp?: boolean;
  stratumStatus?: 'CONNECTED' | 'AUTHENTICATING' | 'DISCONNECTED' | 'OFFLINE' | 'ERROR';
  stratumJobId?: string;
  stratumPingMs?: number;
  stratumSharesAccepted?: number;
  stratumLastActive?: number;
}

export interface GcpMiningFleetSummary {
  totalInstances: number;
  runningInstances: number;
  totalRandomXKhs: number;
  totalkHeavyHashMhs: number;
  totalFishHashMhs?: number;
  totalPearlMhs?: number;
  totalPowerWatts: number;
  totalCostPerHourUsd: number;
  totalDailyYieldSol: number;
  totalDailyYieldUsd: number;
  netProfitDailyUsd: number;
  avgNetMarginPct: number;
  spotSavingsPct: number;
  projectId: string;
  defaultZone: string;
  solRecipient: string;
}

export interface GeminiMiningAnalysis {
  recommendation: string;
  optimalMachineType: string;
  optimalAlgo: MiningAlgo;
  expectedDailyRoiPct: number;
  spotRiskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  reasoning: string;
  governorTimingAdvice: string;
  tokenPumpImpactEstimate: string;
}

export interface WhatToMineAlgoRow {
  algo: MiningAlgo;
  label: string;
  hw: string;
  coin: string;
  unit: string;
  hashrate: number;
  coinsDay: number;
  usdDay: number;
  solDay: number;
  solMonth: number;
  perUnitUsdDay: number;
  pool: string;
  miner: string;
  command: string;
}

export interface WhatToMineEstimate {
  btcUsd: number;
  solUsd: number;
  poolFeePct: number;
  rows: WhatToMineAlgoRow[];
}

export interface UnmineableWorker {
  algo: string;
  name: string;
  online: boolean;
  reportedHs: number;
  calculatedHs: number;
  lastSeen: number;
}

export interface UnmineableLiveChartPoint {
  timestamp: number;
  hashrateHs: number;
}

export interface UnmineableWorkerDetail {
  name: string;
  algo: string;
  online: boolean;
  reportedHs: number;
  calculatedHs: number;
  lastSeen: number;
  uuid?: string;
  pool?: string;
}

export interface UnmineableLiveStats {
  address: string;
  coin: string;
  network: string;
  balanceSol: number;
  balanceUsd: number;
  paymentThresholdSol: number;
  thresholdProgressPct: number;
  online: boolean;
  workerName: string;
  reportedHashrateHs: number;
  calculatedHashrateHs: number;
  rawCommand: string;
  pool: string;
  algo: string;
  chart: UnmineableLiveChartPoint[];
  lastUpdated: number;
  allWorkers?: UnmineableWorkerDetail[];
  stratumBridge?: {
    connectedWorkers: number;
    totalWorkers: number;
    activePool: string;
    lastPingMs: number;
    totalSharesAccepted: number;
    status: 'ACTIVE' | 'CONNECTING' | 'IDLE';
  };
}

export interface UnmineableStatus {
  pool: string;
  payoutCoin: string;
  address: string;
  ok: boolean;
  pendingSol: number;
  pendingUsd: number;
  paymentThresholdSol: number;
  thresholdPct: number;
  poolFeePct: number;
  workers: UnmineableWorker[];
  workersOnline: number;
  payoutsTotalSol: number;
  allocatedTotalSol: number;
  sharePct: number;
}

export interface PaymentItem {
  id: string;
  tier: 'Starter' | 'Builder' | 'Scale';
  amountUsd: number;
  method: 'SOL' | 'CARD' | 'USDC';
  clientName: string;
  timestamp: number;
  buybackEarmarkedSol: number;
  txHash: string;
}

export interface CycleStageEvent {
  stageNumber: number;
  stageName: string;
  action: string;
  tapAmountSol: number;
  status: 'PENDING' | 'EXECUTED' | 'WAITING_GATE';
}

// -------------------------------------------------------------
// Raydium & IDX AutoBot DeFi & Token Creation Types
// -------------------------------------------------------------

export interface TokenMetadata {
  name: string;
  symbol: string;
  decimals: number;
  mint: string;
  address?: string;
  logo: string;
  description?: string;
  supply: number;
  userBalance: number;
  website?: string;
  twitter?: string;
  telegram?: string;
  freezeAuthorityRevoked?: boolean;
  mintAuthorityRevoked?: boolean;
  updateAuthorityRevoked?: boolean;
  hasRaydiumPool?: boolean;
  raydiumPoolId?: string;
  tokenStandard?: 'SPL' | 'Token-2022';
  transferFeeBasisPoints?: number;
  recipientAta?: string;
  airdroppedTo?: string;
  airdropPct?: number;
  txSignature?: string;
  explorerUrl?: string;
  tokenExplorerUrl?: string;
  recipientAtaUrl?: string;
  serializedTxBase64?: string;
  status?: string;
}

export interface RaydiumPool {
  id: string;
  poolId: string;
  poolType: 'AMM_V4' | 'CPMM';
  baseToken: TokenMetadata;
  quoteToken: {
    symbol: string;
    name: string;
    mint: string;
    decimals: number;
    logo: string;
  };
  baseReserve: number;
  quoteReserveSol: number;
  initialPriceSol: number;
  currentPriceSol: number;
  currentPriceUsd: number;
  liquidityUsd: number;
  lpMint: string;
  lpSupply: number;
  userLpBalance: number;
  lpLocked: boolean;
  lpBurned: boolean;
  lockDurationDays?: number;
  unlockTimestamp?: number;
  lockTxSignature?: string;
  burnTxSignature?: string;
  marketId: string;
  openBookMarketCreated: boolean;
  volume24hUsd: number;
  aprPct: number;
  feeTierPct: number;
  accumulatedFeesSol: number;
  createdAt: number;
  status: 'ACTIVE' | 'GRADUATED' | 'SEEDING';
  pumpFlywheelLinked: boolean;
  createTxSignature: string;
  solBackingPct?: number;
}

export interface VolumeBotTrade {
  id: string;
  timestamp: number;
  type: 'BUY' | 'SELL';
  walletLabel: string;
  walletAddress: string;
  amountSol: number;
  tokensAmount: number;
  priceSol: number;
  txSignature: string;
}

export interface VolumeBotConfig {
  enabled: boolean;
  mode: 'MICRO' | 'BUNDLER' | 'MULTI_WALLET' | 'SCHEDULED';
  targetVolume24hSol: number;
  minTradeSol: number;
  maxTradeSol: number;
  intervalSeconds: number;
  buySellRatioPct: number; // e.g. 55 = 55% buys, 45% sells
  slippagePct: number;
  totalVolumeGeneratedSol: number;
  totalTradesExecuted: number;
  activeWalletsCount: number;
  recentTrades: VolumeBotTrade[];
}

export interface HoldersMakerWallet {
  address: string;
  secretKeyBase58?: string;
  solGasBalance: number;
  tokenBalance: number;
  funded: boolean;
  distributed: boolean;
  txSignature?: string;
}

export interface HoldersMakerConfig {
  status: 'IDLE' | 'GENERATING' | 'DISTRIBUTING' | 'COMPLETED';
  targetHoldersCount: number;
  currentHoldersCount: number;
  tokenMint: string;
  tokenSymbol: string;
  amountPerWallet: number;
  solGasPerWallet: number;
  wallets: HoldersMakerWallet[];
  totalDistributedTokens: number;
  totalSolGasSpent: number;
}

export interface ReactionBoosterState {
  rocketsCount: number;
  firesCount: number;
  bullsCount: number;
  heartsCount: number;
  dexScreenerTrendingScore: number;
  pumpFunSentimentPct: number;
  autoBoostEnabled: boolean;
  lastBoostTimestamp: number;
}

export interface BulkSenderJob {
  id: string;
  tokenMint: string;
  tokenSymbol: string;
  recipientsCount: number;
  totalTokens: number;
  totalSolGas: number;
  status: 'IDLE' | 'PROCESSING' | 'COMPLETED';
  progressPct: number;
  successfulSends: number;
  failedSends: number;
  txSignatures: string[];
}

export interface LiquiditySimulationResult {
  baseAmount: number;
  quoteSolAmount: number;
  initialPriceSol: number;
  initialPriceUsd: number;
  initialMarketCapUsd: number;
  poolDepthUsd: number;
  priceImpactScenarios: Array<{
    buySol: number;
    newPriceUsd: number;
    priceImpactPct: number;
    tokensReceived: number;
  }>;
  impermanentLossScenarios: Array<{
    priceMultiplier: number;
    priceChangePct: number;
    ilPct: number;
    lpValueUsd: number;
    holdValueUsd: number;
  }>;
}

export interface PublicDexTrade {
  id: string;
  signature: string;
  timestamp: number;
  dex: 'Raydium' | 'Orca' | 'Meteora' | 'Jupiter' | 'Pump.fun';
  type: 'BUY' | 'SELL';
  baseSymbol: string;
  baseAmount: number;
  quoteSol: number;
  priceUsd: number;
  wallet: string;
  explorerUrl: string;
}

export interface WalletTokenAccount {
  mint: string;
  symbol: string;
  name: string;
  balance: number;
  decimals: number;
  usdValue?: number;
  logo?: string;
  recipientAta?: string;
  txSignature?: string;
  explorerUrl?: string;
  tokenExplorerUrl?: string;
  recipientAtaUrl?: string;
  airdropPct?: number;
  status?: string;
}

export interface WalletState {
  address: string;
  solBalance: number;
  solBalanceUsd?: number;
  formattedAddress: string;
  network: string;
  cluster?: 'mainnet-beta' | 'devnet';
  isRealWallet?: boolean;
  provider?: string;
  tokens: TokenMetadata[];
  tokenAccounts?: WalletTokenAccount[];
  recentSignatures?: Array<{ signature: string; slot: number; timestamp?: number; err?: any }>;
}

export interface StakingPool {
  id: string;
  name: string;
  symbol: string;
  mint: string;
  logo: string;
  badge?: string; // 'Most Popular', 'Newest Pool', 'Active Now'
  badgeType?: 'popular' | 'new' | 'active';
  priceUsd: number;
  change24hPct: number;
  aprPct: number;
  baseAprPct: number;
  lockDays: number; // 0 for flexible, or 40, 65, 80, 180, 365
  poolType: 'FLEXIBLE' | 'LOCKED' | 'LP' | 'TOKEN_2022';
  totalStakedTokens: number;
  totalStakedUsd: number;
  rewardTokenSymbol: string;
  rewardTokenMint: string;
  rewardTokenLogo: string;
  stakersCount: number;
  vaultPda: string;
  rewardVaultPda: string;
  isVerified: boolean;
  isFeatured?: boolean;
  minStakeAmount: number;
  userStakedAmount?: number;
  userClaimableRewards?: number;
  status: 'ACTIVE' | 'ENDED' | 'UPCOMING';
  description?: string;
  solscanUrl?: string;
}

export interface UserStakePosition {
  id: string;
  poolId: string;
  poolSymbol: string;
  poolName: string;
  tokenMint: string;
  tokenLogo: string;
  amountStaked: number;
  amountStakedUsd: number;
  stakedAt: number;
  unlockAt: number;
  lockDays: number;
  aprPct: number;
  accruedRewards: number;
  accruedRewardsUsd: number;
  rewardTokenSymbol: string;
  rewardTokenLogo: string;
  status: 'STAKED' | 'UNLOCKED' | 'CLAIMED';
  txSignature: string;
}

export interface TokenLockItem {
  id: string;
  tokenName: string;
  tokenSymbol: string;
  tokenMint: string;
  tokenLogo: string;
  amount: number;
  amountUsd: number;
  lockedAt: number;
  unlockAt: number;
  lockDays: number;
  ownerAddress: string;
  vaultPda: string;
  isLp: boolean;
  txSignature: string;
}

export type AIModelType = 'GEMINI_4_ARGON' | 'GEMINI_3_8_FLASH' | 'JEV_ELASTICITY' | 'LIQUID_AI_D1_3B' | 'QWEN_27B_TURBO';

export interface AIModelEngine {
  id: AIModelType;
  name: string;
  provider: 'Google DeepMind' | 'Google' | 'Jevons Engine' | 'Liquid AI' | 'Llama Serve (Local/GGUF)';
  tag: string;
  modelIdentifier: string;
  endpointUrl: string;
  status: 'ONLINE' | 'CONNECTED' | 'STANDBY' | 'READY';
  latencyMs: number;
  description: string;
  capabilities: string[];
  isDefault: boolean;
}

export interface StrategyUpgradeDef {
  id: string;
  name: string;
  level: number;
  unlocked: boolean;
  squadron: 'SQUADRON_A_PUMP' | 'SQUADRON_B_LIQUIDITY' | 'SQUADRON_C_COMPOUND' | 'SQUADRON_D_SENTINEL';
  category: 'BONDING_PUMP' | 'RAYDIUM_AMM' | 'DATA_BOUNTY' | 'VOLATILITY_SNIPE' | 'TURBO_CODE' | 'FLYWHEEL_COMPOUND';
  description: string;
  expectedYieldSol: number;
  boostMultiplier: number;
  costSol: number;
  status: 'ACTIVE' | 'AVAILABLE' | 'LOCKED';
  targetToken: string;
  aiEngineRecommended: AIModelType;
  actionCount: number;
}

export interface AIPumpExecutionResult {
  ok: boolean;
  modelUsed: AIModelType;
  modelName: string;
  tokenMint: string;
  tokenSymbol: string;
  solInjected: number;
  tokensAcquired: number;
  newPriceUsd: number;
  newMarketCapUsd: number;
  bondingPctIncrease: number;
  slippagePct: number;
  txSignature: string;
  rationale: string;
  squadronActions: string[];
  revenueEarnedSol: number;
}

export type NetworkHotWalletRole =
  | 'OPERATOR_CORE'
  | 'TREASURY_MASTER'
  | 'PROGRAM_AUTHORITY'
  | 'PUMP_INJECTOR'
  | 'DIP_REBUYER'
  | 'PROFIT_HARVESTER'
  | 'BURNER_MAKER'
  | 'CONNECTED_BROWSER'
  | 'CUSTOM';

export interface WalletTokenBalance {
  mint: string;
  symbol: string;
  name: string;
  amount: number;
  valueUsd: number;
}

export interface NetworkHotWallet {
  id: string;
  label: string;
  address: string;
  role: NetworkHotWalletRole;
  solBalance: number;
  solBalanceUsd: number;
  tokenBalances: WalletTokenBalance[];
  hasCustody: boolean;
  isHotWallet: boolean;
  status: 'ONLINE' | 'ACTIVE' | 'IDLE' | 'LOW_BALANCE';
  totalTxs: number;
  lastTxSignature?: string;
  secretKeyPreview?: string;
  cluster: 'mainnet-beta' | 'devnet';
  notes?: string;
}

export interface WalletTransactionRecord {
  id: string;
  timestamp: number;
  type: 'DEPOSIT' | 'WITHDRAW' | 'TRANSFER' | 'SWEEP' | 'DISTRIBUTE';
  asset: string;
  amount: number;
  amountUsd: number;
  sourceAddress: string;
  sourceLabel: string;
  destinationAddress: string;
  destinationLabel: string;
  status: 'CONFIRMED' | 'PENDING' | 'FAILED';
  txSignature: string;
  explorerUrl: string;
  note?: string;
}

export interface WalletSummaryStats {
  totalSol: number;
  totalUsd: number;
  totalWallets: number;
  hotWalletsCount: number;
  totalTokensTracked: number;
  dayDepositsSol: number;
  dayWithdrawsSol: number;
  dayTxsCount: number;
}

// -------------------------------------------------------------
// Live pool data (read from Solana mainnet + Raydium API, never stored or estimated)
// -------------------------------------------------------------

/**
 * LIVE             – pool account exists on-chain and Raydium's API returned live stats
 * ONCHAIN_NO_STATS – pool account exists and is owned by a Raydium program, but Raydium's API had no stats
 * NOT_FOUND        – Solana RPC confirmed there is no account at this address
 * NOT_A_POOL       – an account exists, but it is not owned by a Raydium pool program
 * INVALID_ID       – not a valid Solana address
 * UNVERIFIED       – neither Solana RPC nor Raydium's API could be reached, so nothing is claimed
 */
export type LivePoolStatus =
  | 'LIVE'
  | 'ONCHAIN_NO_STATS'
  | 'NOT_FOUND'
  | 'NOT_A_POOL'
  | 'INVALID_ID'
  | 'UNVERIFIED';

export type LivePoolKind = 'AMM_V4' | 'CPMM' | 'CLMM' | 'OTHER';

export interface LivePoolToken {
  mint: string;
  symbol: string;
  decimals: number;
  logo?: string;
}

export interface LivePoolInfo {
  poolId: string;
  status: LivePoolStatus;
  statusDetail: string;
  // Solana RPC account check (null = RPC unreachable)
  accountExists: boolean | null;
  ownerProgram: string | null;
  ownerProgramLabel: string | null;
  // Raydium API stats (null = unavailable)
  poolKind: LivePoolKind | null;
  mintA: LivePoolToken | null;
  mintB: LivePoolToken | null;
  reserveA: number | null;
  reserveB: number | null;
  /** Units of mintB per 1 mintA */
  price: number | null;
  tvlUsd: number | null;
  feeRate: number | null;
  volume24hUsd: number | null;
  /** Trading fees paid in the last 24h across the whole pool (all LPs + protocol) */
  fees24hUsd: number | null;
  lpMint: string | null;
  lpSupply: number | null;
  lpBurnPct: number | null;
  // Connected wallet's position (null = not checked / not applicable)
  wallet: string | null;
  walletLpBalance: number | null;
  walletLpCheck: 'ALL_TOKEN_ACCOUNTS' | 'ASSOCIATED_ACCOUNT_ONLY' | 'NOT_CHECKED';
  walletSharePct: number | null;
  walletValueUsd: number | null;
  walletAmountA: number | null;
  walletAmountB: number | null;
  sources: string[];
  fetchedAt: number;
  errors: string[];
}

export interface LivePoolsResponse {
  ok: boolean;
  wallet: string | null;
  pools: LivePoolInfo[];
  fetchedAt: number;
  errors: string[];
}

